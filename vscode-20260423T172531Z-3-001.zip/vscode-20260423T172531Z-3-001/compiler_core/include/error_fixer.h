#ifndef ERROR_FIXER_H
#define ERROR_FIXER_H

#include "parser.h"

typedef struct {
    char* error_message;
    char* wrong_code;
    char* correct_code;
    char* explanation_en;
    char* explanation_hi;
    int line;
} ErrorFix;

ErrorFix* suggest_fix(char* error_msg, char* code_line, int line);
void free_error_fix(ErrorFix* fix);

#endif