#ifndef PARSER_H
#define PARSER_H

#include "token.h"

// AST Node Types
typedef enum {
    NODE_PROGRAM,
    NODE_FUNCTION,
    NODE_BLOCK,
    NODE_VAR_DECL,
    NODE_ARRAY_DECL,
    NODE_ARRAY_ACCESS,
    NODE_ASSIGN,
    NODE_IF_STMT,
    NODE_RETURN_STMT,
    NODE_BINARY_OP,
    NODE_UNARY_OP,
    NODE_INTEGER,
    NODE_FLOAT_LIT,
    NODE_CHAR_LIT,
    NODE_STRING,
    NODE_IDENTIFIER,
    NODE_FUNCTION_CALL
} NodeType;

// AST Node Structure
typedef struct ASTNode {
    NodeType type;
    char* value;
    struct ASTNode** children;
    int child_count;
    int line;
    int column;
} ASTNode;

// Parser Structure
typedef struct {
    Token** tokens;
    int token_count;
    int position;
    char** errors;
    int error_count;
    int error_capacity;
} Parser;

// Function declarations
Parser* create_parser(Token** tokens, int token_count);
void free_parser(Parser* parser);
ASTNode* parse(Parser* parser);
void add_parser_error(Parser* parser, const char* message, int line, int column);
ASTNode* create_ast_node(NodeType type, const char* value, int line, int column);
void add_child(ASTNode* parent, ASTNode* child);
void print_ast(ASTNode* node, int level);
void free_ast(ASTNode* node);

// Core parsing functions
ASTNode* parse_program(Parser* parser);
ASTNode* parse_function(Parser* parser);
ASTNode* parse_block(Parser* parser);
ASTNode* parse_statement(Parser* parser);

// Declaration parsing
ASTNode* parse_var_decl(Parser* parser);
ASTNode* parse_assignment(Parser* parser);

// Statement parsing
ASTNode* parse_if_statement(Parser* parser);
ASTNode* parse_return_statement(Parser* parser);
ASTNode* parse_function_call(Parser* parser);

// Expression parsing
ASTNode* parse_expression(Parser* parser);
ASTNode* parse_comparison(Parser* parser);
ASTNode* parse_addition(Parser* parser);
ASTNode* parse_multiplication(Parser* parser);
ASTNode* parse_primary(Parser* parser);

// Helper functions
Token* current_token(Parser* parser);
Token* peek_token(Parser* parser, int offset);
void advance_parser(Parser* parser);
int match(Parser* parser, TokenType type);
int expect(Parser* parser, TokenType type, const char* error_msg);

#endif