#ifndef PREPROCESSOR_H
#define PREPROCESSOR_H

#include "lexer.h"

// Preprocessor directive types
typedef enum {
    DIR_NONE,
    DIR_INCLUDE,
    DIR_DEFINE,
    DIR_UNDEF,
    DIR_IFDEF,
    DIR_IFNDEF,
    DIR_ELSE,
    DIR_ENDIF
} PreprocessorDirective;

// Macro definition
typedef struct Macro {
    char* name;
    char* value;
    struct Macro* next;
} Macro;

// Preprocessor structure
typedef struct {
    Macro* macros;
    char** includes;
    int include_count;
    char** errors;
    int error_count;
} Preprocessor;

// Function declarations
Preprocessor* create_preprocessor();
void free_preprocessor(Preprocessor* pp);
char* preprocess(Preprocessor* pp, const char* source);
void add_macro(Preprocessor* pp, const char* name, const char* value);
char* expand_macros(Preprocessor* pp, const char* line);
void add_include_path(Preprocessor* pp, const char* path);

#endif