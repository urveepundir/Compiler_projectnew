// File: include/semantic.h
#ifndef SEMANTIC_H
#define SEMANTIC_H

#include "parser.h"

// Symbol Table Entry
typedef struct Symbol {
    char* name;
    char* type;
    int line_declared;
    int is_initialized;
    int is_array;        // ← ADDED: 1 if array, 0 if not
    int array_size;      // ← ADDED: size of array (for bounds checking)
    struct Symbol* next;
} Symbol;

// Symbol Table
typedef struct {
    Symbol** buckets;
    int size;
    int count;
} SymbolTable;

// Semantic Analyzer
typedef struct {
    SymbolTable* table;
    char** errors;
    int error_count;
    int error_capacity;
    char* current_function;
    int in_loop;
    int in_switch;
} SemanticAnalyzer;

// Function declarations
SemanticAnalyzer* create_semantic_analyzer();
void free_semantic_analyzer(SemanticAnalyzer* sa);
void analyze_ast(SemanticAnalyzer* sa, ASTNode* node);
void add_semantic_error(SemanticAnalyzer* sa, const char* message, int line, int column);

// Symbol table functions
void add_symbol(SemanticAnalyzer* sa, const char* name, const char* type, int line, int is_initialized);
void add_array_symbol(SemanticAnalyzer* sa, const char* name, const char* type, int line, int size);
Symbol* lookup_symbol(SemanticAnalyzer* sa, const char* name);
Symbol* lookup_symbol_current_scope(SemanticAnalyzer* sa, const char* name);

// Type checking
const char* get_expression_type(SemanticAnalyzer* sa, ASTNode* node);
int check_type_compatibility(const char* type1, const char* type2);

#endif