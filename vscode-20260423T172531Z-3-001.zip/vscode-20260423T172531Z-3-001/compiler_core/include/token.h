#ifndef TOKEN_H
#define TOKEN_H

// Token types for C language subset
typedef enum {
    // Keywords
    TOKEN_INT,
    TOKEN_FLOAT,
    TOKEN_CHAR,
    TOKEN_IF,
    TOKEN_ELSE,
    TOKEN_WHILE,
    TOKEN_FOR,
    TOKEN_RETURN,
    TOKEN_VOID,
    
    // Operators
    TOKEN_PLUS,
    TOKEN_MINUS,
    TOKEN_MUL,
    TOKEN_DIV,
    TOKEN_ASSIGN,
    TOKEN_EQ,
    TOKEN_NEQ,
    TOKEN_LT,
    TOKEN_GT,
    TOKEN_LTE,
    TOKEN_GTE,
    TOKEN_AMP,
    TOKEN_AND,
    TOKEN_OR,
    TOKEN_NOT,
    
    // Delimiters
    TOKEN_SEMICOLON,
    TOKEN_COMMA,
    TOKEN_LPAREN,
    TOKEN_RPAREN,
    TOKEN_LBRACE,
    TOKEN_RBRACE,
    TOKEN_LBRACKET,
    TOKEN_RBRACKET,
    
    // Literals
    TOKEN_IDENTIFIER,
    TOKEN_INTEGER,
    TOKEN_FLOAT_LIT,
    TOKEN_CHAR_LIT,
    TOKEN_STRING,
    
    // Special
    TOKEN_EOF,
    TOKEN_ERROR,
    TOKEN_UNKNOWN
} TokenType;

typedef struct {
    TokenType type;
    char* value;
    int line;
    int column;
} Token;

// Function declarations
Token* create_token(TokenType type, const char* value, int line, int column);
void free_token(Token* token);
const char* token_type_to_string(TokenType type);
void print_token(Token* token);

#endif