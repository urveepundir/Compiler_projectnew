#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "include/lexer.h"
#include "include/parser.h"
#include "include/semantic.h"
#include "include/preprocessor.h"

static void print_json_string(const char* value) {
    const unsigned char* p = (const unsigned char*)(value ? value : "");
    putchar('"');
    while (*p) {
        switch (*p) {
            case '\\':
                fputs("\\\\", stdout);
                break;
            case '"':
                fputs("\\\"", stdout);
                break;
            case '\n':
                fputs("\\n", stdout);
                break;
            case '\r':
                fputs("\\r", stdout);
                break;
            case '\t':
                fputs("\\t", stdout);
                break;
            default:
                putchar(*p);
                break;
        }
        p++;
    }
    putchar('"');
}

int main(int argc, char* argv[]) {
    // Debug: Compiler started (stderr)
    fprintf(stderr, "=== Compiler Started ===\n");
    
    char buffer[65536];
    size_t bytes = fread(buffer, 1, sizeof(buffer) - 1, stdin);
    buffer[bytes] = '\0';
    
    // Debug: Input read (stderr)
    fprintf(stderr, "Input read: %lu bytes\n", (unsigned long)bytes);
    fprintf(stderr, "Input: %s\n", buffer);
    
    // Preprocessing (stderr)
    fprintf(stderr, "Creating preprocessor...\n");
    Preprocessor* pp = create_preprocessor();
    char* preprocessed_code = preprocess(pp, buffer);
    fprintf(stderr, "Preprocessed: %s\n", preprocessed_code);
    
    // Lexical Analysis (stderr)
    fprintf(stderr, "Creating lexer...\n");
    Lexer* lexer = create_lexer(preprocessed_code);
    tokenize(lexer);
    fprintf(stderr, "Lexer complete. Tokens: %d, Lexical Errors: %d\n", lexer->token_count, lexer->error_count);
    
    // Syntax Analysis (stderr)
    fprintf(stderr, "Creating parser...\n");
    Parser* parser = create_parser(lexer->tokens, lexer->token_count);
    ASTNode* ast = parse(parser);
    fprintf(stderr, "Parser complete. Errors: %d\n", parser->error_count);
    
    // Semantic Analysis (stderr)
    fprintf(stderr, "Creating semantic analyzer...\n");
    SemanticAnalyzer* sem = create_semantic_analyzer();
    if (ast) {
        analyze_ast(sem, ast);
    }
    fprintf(stderr, "Semantic complete. Errors: %d\n", sem->error_count);
    
    
    
    // ===== JSON OUTPUT (ONLY ON STDOUT) =====
    fprintf(stderr, "Generating JSON...\n");
    
    // Start JSON
    printf("{\n");
    
    // ----- TOKENS -----
    printf("  \"tokens\": [\n");
    int token_count = 0;
    for (int i = 0; i < lexer->token_count; i++) {
        Token* t = lexer->tokens[i];
        if (t->type != TOKEN_EOF) {
            if (token_count > 0) {
                printf(",\n");
            }
            printf("    {\"type\":");
            print_json_string(token_type_to_string(t->type));
            printf(",\"value\":");
            print_json_string(t->value);
            printf(",\"line\":%d,\"col\":%d}",
                   t->line,
                   t->column);
            token_count++;
        }
    }
    printf("\n  ],\n");
    
    // ----- LEXICAL ERRORS -----
    printf("  \"lex_errors\": [\n");
    for (int i = 0; i < lexer->error_count; i++) {
        if (i > 0) {
            printf(",\n");
        }
        printf("    %s", lexer->errors[i]);
    }
    printf("\n  ],\n");
    
    // ----- SYNTAX ERRORS -----
    printf("  \"syntax_errors\": [\n");
    for (int i = 0; i < parser->error_count; i++) {
        if (i > 0) {
            printf(",\n");
        }
        printf("    %s", parser->errors[i]);
    }
    printf("\n  ],\n");
    
    // ----- SEMANTIC ERRORS -----
    printf("  \"semantic_errors\": [\n");
    for (int i = 0; i < sem->error_count; i++) {
        if (i > 0) {
            printf(",\n");
        }
        printf("    %s", sem->errors[i]);
    }
    printf("\n  ],\n");
    
    // ----- AST STATUS -----
    printf("  \"ast\": ");
    if (ast) {
        if (parser->error_count == 0 && sem->error_count == 0) {
            print_json_string("Parsing successful");
        } else {
            char ast_status[128];
            snprintf(ast_status, sizeof(ast_status),
                     "Parsing had %d syntax errors, %d semantic errors",
                     parser->error_count, sem->error_count);
            print_json_string(ast_status);
        }
    } else {
        print_json_string("No AST generated");
    }
    printf("\n");
    
    // End JSON
    printf("}\n");
    
    // Debug: JSON complete (stderr)
    fprintf(stderr, "JSON generation complete\n");
    
    // Cleanup
    if (ast) free_ast(ast);
    free_parser(parser);
    free_semantic_analyzer(sem);
    free_lexer(lexer);
    free_preprocessor(pp);
    free(preprocessed_code);
   
    
    fprintf(stderr, "=== Compiler Finished ===\n");
    
    return 0;
}
