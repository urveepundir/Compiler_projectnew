#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/error_fixer.h"

ErrorFix* suggest_fix(char* error_msg, char* code_line, int line) {
    ErrorFix* fix = (ErrorFix*)malloc(sizeof(ErrorFix));
    if (!fix) return NULL;
    
    fix->line = line;
    fix->error_message = strdup(error_msg);
    fix->wrong_code = strdup(code_line);
    fix->correct_code = NULL;
    fix->explanation_en = NULL;
    fix->explanation_hi = NULL;
    
    // Missing Semicolon Fix
    if (strstr(error_msg, "Expected ';'") || strstr(code_line, "int ") && !strstr(code_line, ";")) {
        char* corrected = (char*)malloc(strlen(code_line) + 2);
        sprintf(corrected, "%s;", code_line);
        fix->correct_code = corrected;
        fix->explanation_en = "Every statement in C must end with a semicolon (;)";

    }
    
    // Missing Parenthesis Fix
    else if (strstr(error_msg, "Expected ')'") || strstr(code_line, "printf(\"")) {
        char* corrected = (char*)malloc(strlen(code_line) + 2);
        sprintf(corrected, "%s);", code_line);
        fix->correct_code = corrected;
        fix->explanation_en = "Function calls need closing parenthesis )";

    }
    
    // Undeclared Variable Fix
    else if (strstr(error_msg, "undeclared")) {
        char var_name[50] = {0};
        // Extract variable name from error
        sscanf(error_msg, "'%[^']'", var_name);
        char* corrected = (char*)malloc(strlen(code_line) + 20);
        sprintf(corrected, "int %s;", var_name);
        fix->correct_code = corrected;
        fix->explanation_en = "Variable must be declared before use";
        
    }
    
    // Wrong Operator Fix (= vs ==)
    else if (strstr(error_msg, "if") && strstr(code_line, "=") && !strstr(code_line, "==")) {
        char* corrected = str_replace(code_line, "=", "==");
        fix->correct_code = corrected;
        fix->explanation_en = "Use == for comparison, not =";
    }
    
    // Missing Brace Fix
    else if (strstr(error_msg, "Expected '}'")) {
        char* corrected = (char*)malloc(strlen(code_line) + 10);
        sprintf(corrected, "%s\n}", code_line);
        fix->correct_code = corrected;
        fix->explanation_en = "Missing closing brace }";
        
    }
    
    return fix;
}

void free_error_fix(ErrorFix* fix) {
    if (fix) {
        if (fix->error_message) free(fix->error_message);
        if (fix->wrong_code) free(fix->wrong_code);
        if (fix->correct_code) free(fix->correct_code);
        if (fix->explanation_en) free((void*)fix->explanation_en);
        if (fix->explanation_hi) free((void*)fix->explanation_hi);
        free(fix);
    }
}

// Helper function
char* str_replace(char* str, char* old, char* new) {
    // Simple replace - for demo
    char* result = malloc(strlen(str) + strlen(new) + 1);
    char* pos = strstr(str, old);
    if (pos) {
        int index = pos - str;
        strncpy(result, str, index);
        result[index] = '\0';
        strcat(result, new);
        strcat(result, pos + strlen(old));
    }
    return result;
}