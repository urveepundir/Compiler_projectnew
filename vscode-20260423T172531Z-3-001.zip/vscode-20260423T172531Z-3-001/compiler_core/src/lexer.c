#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "../include/lexer.h"


Lexer* create_lexer(const char* source) {
    Lexer* lexer = (Lexer*)malloc(sizeof(Lexer));
    if (!lexer) return NULL;
    
    lexer->source = source ? strdup(source) : strdup("");
    lexer->position = 0;
    lexer->line = 1;
    lexer->column = 1;
    
   
    lexer->token_capacity = 100;
    lexer->token_count = 0;
    lexer->tokens = (Token**)malloc(sizeof(Token*) * lexer->token_capacity);
    
    
    lexer->error_capacity = 50;
    lexer->error_count = 0;
    lexer->errors = (char**)malloc(sizeof(char*) * lexer->error_capacity);
    
    return lexer;
}

void free_lexer(Lexer* lexer) {
    if (lexer) {
        if (lexer->source) free(lexer->source);
        
        // Free all tokens
        for (int i = 0; i < lexer->token_count; i++) {
            free_token(lexer->tokens[i]);
        }
        if (lexer->tokens) free(lexer->tokens);
        
        // Free all errors
        for (int i = 0; i < lexer->error_count; i++) {
            if (lexer->errors[i]) free(lexer->errors[i]);
        }
        if (lexer->errors) free(lexer->errors);
        
        free(lexer);
    }
}

char current_char(Lexer* lexer) {
    if (lexer->position < (int)strlen(lexer->source)) {
        return lexer->source[lexer->position];
    }
    return '\0';
}

char peek_char(Lexer* lexer) {
    if (lexer->position + 1 < (int)strlen(lexer->source)) {
        return lexer->source[lexer->position + 1];
    }
    return '\0';
}

void advance(Lexer* lexer) {
    if (lexer->position < (int)strlen(lexer->source)) {
        if (current_char(lexer) == '\n') {
            lexer->line++;
            lexer->column = 1;
        } else {
            lexer->column++;
        }
        lexer->position++;
    }
}

void add_token(Lexer* lexer, TokenType type, const char* value) {
    if (lexer->token_count >= lexer->token_capacity) {
        lexer->token_capacity *= 2;
        lexer->tokens = (Token**)realloc(lexer->tokens, sizeof(Token*) * lexer->token_capacity);
    }
    
    lexer->tokens[lexer->token_count++] = create_token(type, value, lexer->line, lexer->column - strlen(value));
}

void add_error(Lexer* lexer, int line, int column, const char* message, const char* suggestion) {
    if (lexer->error_count >= lexer->error_capacity) {
        lexer->error_capacity *= 2;
        lexer->errors = (char**)realloc(lexer->errors, sizeof(char*) * lexer->error_capacity);
    }
    
    char error_msg[512];
    snprintf(error_msg, sizeof(error_msg), 
             "{\"line\":%d,\"column\":%d,\"message\":\"%s\",\"suggestion\":\"%s\"}",
             line, column, message, suggestion);
    
    lexer->errors[lexer->error_count++] = strdup(error_msg);
    
    // Debug print
    fprintf(stderr, "LEXICAL ERROR: %s at line %d\n", message, line);
}

void skip_whitespace(Lexer* lexer) {
    while (lexer->position < (int)strlen(lexer->source) && isspace(current_char(lexer))) {
        advance(lexer);
    }
}

void skip_comment(Lexer* lexer) {
    // Skip // style comments
    if (current_char(lexer) == '/' && peek_char(lexer) == '/') {
        while (lexer->position < (int)strlen(lexer->source) && current_char(lexer) != '\n') {
            advance(lexer);
        }
    }
    // Skip /* */ style comments
    else if (current_char(lexer) == '/' && peek_char(lexer) == '*') {
        advance(lexer); // Skip /
        advance(lexer); // Skip *
        
        while (lexer->position < (int)strlen(lexer->source)) {
            if (current_char(lexer) == '*' && peek_char(lexer) == '/') {
                advance(lexer); // Skip *
                advance(lexer); // Skip /
                break;
            }
            advance(lexer);
        }
    }
}

void read_identifier(Lexer* lexer) {
    int start_pos = lexer->position;
    
    while (lexer->position < (int)strlen(lexer->source) && 
           (isalnum(current_char(lexer)) || current_char(lexer) == '_')) {
        advance(lexer);
    }
    
    int len = lexer->position - start_pos;
    char* value = (char*)malloc(len + 1);
    strncpy(value, lexer->source + start_pos, len);
    value[len] = '\0';
    
    // Check for keywords
    TokenType type = TOKEN_IDENTIFIER;
    if (strcmp(value, "int") == 0) type = TOKEN_INT;
    else if (strcmp(value, "float") == 0) type = TOKEN_FLOAT;
    else if (strcmp(value, "char") == 0) type = TOKEN_CHAR;
    else if (strcmp(value, "if") == 0) type = TOKEN_IF;
    else if (strcmp(value, "else") == 0) type = TOKEN_ELSE;
    else if (strcmp(value, "while") == 0) type = TOKEN_WHILE;
    else if (strcmp(value, "for") == 0) type = TOKEN_FOR;
    else if (strcmp(value, "return") == 0) type = TOKEN_RETURN;
    else if (strcmp(value, "void") == 0) type = TOKEN_VOID;
    
    add_token(lexer, type, value);
    free(value);
}

void read_number(Lexer* lexer) {
    int start_pos = lexer->position;
    int is_float = 0;
    
    // Read integer part
    while (lexer->position < (int)strlen(lexer->source) && isdigit(current_char(lexer))) {
        advance(lexer);
    }
    
    // Check for decimal point
    if (current_char(lexer) == '.' && isdigit(peek_char(lexer))) {
        is_float = 1;
        advance(lexer); // Skip .
        
        // Read fractional part
        while (lexer->position < (int)strlen(lexer->source) && isdigit(current_char(lexer))) {
            advance(lexer);
        }
    }
    
    int len = lexer->position - start_pos;
    char* value = (char*)malloc(len + 1);
    strncpy(value, lexer->source + start_pos, len);
    value[len] = '\0';
    
    add_token(lexer, is_float ? TOKEN_FLOAT_LIT : TOKEN_INTEGER, value);
    free(value);
}

void read_string(Lexer* lexer) {
    int start_pos = lexer->position;
    int start_col = lexer->column;
    advance(lexer); // Skip opening quote
    
    while (lexer->position < (int)strlen(lexer->source) && current_char(lexer) != '"') {
        if (current_char(lexer) == '\\') advance(lexer); // Skip escape
        advance(lexer);
    }
    
    if (current_char(lexer) == '"') {
        advance(lexer); // Skip closing quote
        int len = lexer->position - start_pos;
        char* value = (char*)malloc(len + 1);
        strncpy(value, lexer->source + start_pos, len);
        value[len] = '\0';
        add_token(lexer, TOKEN_STRING, value);
        free(value);
    } else {
        // Unterminated string error
        add_error(lexer, lexer->line, start_col, 
                  "Unterminated string literal", 
                  "Add closing \" at the end of the string");
        add_token(lexer, TOKEN_ERROR, "\"");
    }
}

void read_character(Lexer* lexer) {
    int start_pos = lexer->position;
    int start_col = lexer->column;
    advance(lexer); // Skip opening quote
    
    if (current_char(lexer) == '\\') { // Escape sequence
        advance(lexer);
    }
    
    if (lexer->position < (int)strlen(lexer->source)) {
        advance(lexer);
    }
    
    if (current_char(lexer) == '\'') {
        advance(lexer); // Skip closing quote
        int len = lexer->position - start_pos;
        char* value = (char*)malloc(len + 1);
        strncpy(value, lexer->source + start_pos, len);
        value[len] = '\0';
        add_token(lexer, TOKEN_CHAR_LIT, value);
        free(value);
    } else {
        // Unterminated character error
        add_error(lexer, lexer->line, start_col, 
                  "Unterminated character literal", 
                  "Add closing ' at the end of the character");
        add_token(lexer, TOKEN_ERROR, "'");
    }
}

void read_operator(Lexer* lexer) {
    int start_col = lexer->column;
    char c = current_char(lexer);
    
    // Single character operators
    switch(c) {
        case ';': 
            // Check for double semicolon BEFORE advancing
            if (peek_char(lexer) == ';') {
                add_error(lexer, lexer->line, start_col + 1, 
                          "Empty statement (double semicolon)", 
                          "Remove extra semicolon");
            }
            advance(lexer); 
            add_token(lexer, TOKEN_SEMICOLON, ";");
            return;
        case ',': advance(lexer); add_token(lexer, TOKEN_COMMA, ","); return;
        case '(': advance(lexer); add_token(lexer, TOKEN_LPAREN, "("); return;
        case ')': advance(lexer); add_token(lexer, TOKEN_RPAREN, ")"); return;
        case '{': advance(lexer); add_token(lexer, TOKEN_LBRACE, "{"); return;
        case '}': advance(lexer); add_token(lexer, TOKEN_RBRACE, "}"); return;
        case '[': advance(lexer); add_token(lexer, TOKEN_LBRACKET, "["); return;
        case ']': advance(lexer); add_token(lexer, TOKEN_RBRACKET, "]"); return;
        case '+': advance(lexer); add_token(lexer, TOKEN_PLUS, "+"); return;
        case '-': advance(lexer); add_token(lexer, TOKEN_MINUS, "-"); return;
        case '*': advance(lexer); add_token(lexer, TOKEN_MUL, "*"); return;
        case '/': advance(lexer); add_token(lexer, TOKEN_DIV, "/"); return;
        
        // Two character operators
        case '=':
            advance(lexer);
            if (current_char(lexer) == '=') {
                advance(lexer);
                add_token(lexer, TOKEN_EQ, "==");
            } else {
                add_token(lexer, TOKEN_ASSIGN, "=");
            }
            return;
            
        case '!':
            advance(lexer);
            if (current_char(lexer) == '=') {
                advance(lexer);
                add_token(lexer, TOKEN_NEQ, "!=");
            } else {
                add_token(lexer, TOKEN_NOT, "!");
            }
            return;
            
        case '<':
            advance(lexer);
            if (current_char(lexer) == '=') {
                advance(lexer);
                add_token(lexer, TOKEN_LTE, "<=");
            } else {
                add_token(lexer, TOKEN_LT, "<");
            }
            return;
            
        case '>':
            advance(lexer);
            if (current_char(lexer) == '=') {
                advance(lexer);
                add_token(lexer, TOKEN_GTE, ">=");
            } else {
                add_token(lexer, TOKEN_GT, ">");
            }
            return;
            
        case '&':
            advance(lexer);
            if (current_char(lexer) == '&') {
                advance(lexer);
                add_token(lexer, TOKEN_AND, "&&");
            } else {
                add_token(lexer, TOKEN_AMP, "&");
            }
            return;
            
        case '|':
            advance(lexer);
            if (current_char(lexer) == '|') {
                advance(lexer);
                add_token(lexer, TOKEN_OR, "||");
            } else {
                char unknown[2];
                unknown[0] = '|';
                unknown[1] = '\0';
                add_token(lexer, TOKEN_UNKNOWN, unknown);
                add_error(lexer, lexer->line, start_col, 
                         "Invalid '|' operator", 
                         "Did you mean '||' (logical OR)?");
            }
            return;
            
        default:
        {
            char unknown[2];
            unknown[0] = c;
            unknown[1] = '\0';
            add_token(lexer, TOKEN_UNKNOWN, unknown);
            add_error(lexer, lexer->line, start_col, 
                     "Unknown character", 
                     "This character is not valid in C");
            advance(lexer);
        }
        return;
    }
}

void tokenize(Lexer* lexer) {
    while (lexer->position < (int)strlen(lexer->source)) {
        // Skip whitespace
        if (isspace(current_char(lexer))) {
            skip_whitespace(lexer);
            continue;
        }
        
        // Skip comments
        if (current_char(lexer) == '/') {
            if (peek_char(lexer) == '/' || peek_char(lexer) == '*') {
                skip_comment(lexer);
                continue;
            }
        }
        
        // Read identifiers and keywords
        if (isalpha(current_char(lexer)) || current_char(lexer) == '_') {
            read_identifier(lexer);
            continue;
        }
        
        // Read numbers
        if (isdigit(current_char(lexer))) {
            read_number(lexer);
            continue;
        }
        
        // Read strings
        if (current_char(lexer) == '"') {
            read_string(lexer);
            continue;
        }
        
        // Read characters
        if (current_char(lexer) == '\'') {
            read_character(lexer);
            continue;
        }
        
        // Read operators and delimiters
        read_operator(lexer);
    }
    
    // Add EOF token
    add_token(lexer, TOKEN_EOF, "EOF");
}
