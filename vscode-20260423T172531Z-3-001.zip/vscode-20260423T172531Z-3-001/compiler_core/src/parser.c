#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/parser.h"

Parser* create_parser(Token** tokens, int token_count) {
    Parser* parser = (Parser*)malloc(sizeof(Parser));
    if (!parser) return NULL;
    
    parser->tokens = tokens;
    parser->token_count = token_count;
    parser->position = 0;
    
    parser->error_capacity = 50;
    parser->error_count = 0;
    parser->errors = (char**)malloc(sizeof(char*) * parser->error_capacity);
    
    return parser;
}

void free_parser(Parser* parser) {
    if (parser) {
        for (int i = 0; i < parser->error_count; i++) {
            if (parser->errors[i]) free(parser->errors[i]);
        }
        if (parser->errors) free(parser->errors);
        free(parser);
    }
}

Token* current_token(Parser* parser) {
    if (parser->position < parser->token_count) {
        return parser->tokens[parser->position];
    }
    return NULL;
}

Token* peek_token(Parser* parser, int offset) {
    if (parser->position + offset < parser->token_count) {
        return parser->tokens[parser->position + offset];
    }
    return NULL;
}

void advance_parser(Parser* parser) {
    if (parser->position < parser->token_count) {
        parser->position++;
    }
}

int match(Parser* parser, TokenType type) {
    Token* token = current_token(parser);
    if (token && token->type == type) {
        advance_parser(parser);
        return 1;
    }
    return 0;
}

int expect(Parser* parser, TokenType type, const char* error_msg) {
    Token* token = current_token(parser);
    if (token && token->type == type) {
        advance_parser(parser);
        return 1;
    }
    
    add_parser_error(parser, error_msg, token ? token->line : 0, token ? token->column : 0);
    return 0;
}

void add_parser_error(Parser* parser, const char* message, int line, int column) {
    if (parser->error_count >= parser->error_capacity) {
        parser->error_capacity *= 2;
        parser->errors = (char**)realloc(parser->errors, sizeof(char*) * parser->error_capacity);
    }
    
    char error_msg[512];
    snprintf(error_msg, sizeof(error_msg), 
             "{\"line\":%d,\"column\":%d,\"message\":\"%s\",\"type\":\"syntax\"}",
             line, column, message);
    
    parser->errors[parser->error_count++] = strdup(error_msg);
}

ASTNode* create_ast_node(NodeType type, const char* value, int line, int column) {
    ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
    if (!node) return NULL;
    
    node->type = type;
    node->value = value ? strdup(value) : NULL;
    node->line = line;
    node->column = column;
    node->children = NULL;
    node->child_count = 0;
    
    return node;
}

void add_child(ASTNode* parent, ASTNode* child) {
    if (!parent || !child) return;
    
    parent->child_count++;
    parent->children = (ASTNode**)realloc(parent->children, sizeof(ASTNode*) * parent->child_count);
    parent->children[parent->child_count - 1] = child;
}

void print_ast(ASTNode* node, int level) {
    if (!node) return;
    
    for (int i = 0; i < level; i++) printf("  ");
    
    switch(node->type) {
        case NODE_PROGRAM: printf("PROGRAM\n"); break;
        case NODE_FUNCTION: printf("FUNCTION: %s\n", node->value ? node->value : "main"); break;
        case NODE_BLOCK: printf("BLOCK\n"); break;
        case NODE_VAR_DECL: printf("VAR_DECL: %s\n", node->value ? node->value : ""); break;
        case NODE_ARRAY_DECL: printf("ARRAY_DECL: %s\n", node->value ? node->value : ""); break;
        case NODE_ARRAY_ACCESS: printf("ARRAY_ACCESS: %s\n", node->value ? node->value : ""); break;
        case NODE_ASSIGN: printf("ASSIGN\n"); break;
        case NODE_IF_STMT: printf("IF_STMT\n"); break;
        case NODE_RETURN_STMT: printf("RETURN\n"); break;
        case NODE_BINARY_OP: printf("BINARY_OP: %s\n", node->value ? node->value : ""); break;
        case NODE_INTEGER: printf("INTEGER: %s\n", node->value ? node->value : ""); break;
        case NODE_FLOAT_LIT: printf("FLOAT: %s\n", node->value ? node->value : ""); break;
        case NODE_CHAR_LIT: printf("CHAR: %s\n", node->value ? node->value : ""); break;
        case NODE_STRING: printf("STRING: %s\n", node->value ? node->value : ""); break;
        case NODE_IDENTIFIER: printf("IDENTIFIER: %s\n", node->value ? node->value : ""); break;
        case NODE_FUNCTION_CALL: printf("FUNCTION_CALL: %s\n", node->value ? node->value : ""); break;
        default: printf("NODE\n"); break;
    }
    
    for (int i = 0; i < node->child_count; i++) {
        print_ast(node->children[i], level + 1);
    }
}

void free_ast(ASTNode* node) {
    if (!node) return;
    
    for (int i = 0; i < node->child_count; i++) {
        free_ast(node->children[i]);
    }
    
    if (node->children) free(node->children);
    if (node->value) free(node->value);
    free(node);
}

// Parsing functions
ASTNode* parse_program(Parser* parser) {
    ASTNode* program = create_ast_node(NODE_PROGRAM, NULL, 0, 0);
    
    while (current_token(parser) && current_token(parser)->type != TOKEN_EOF) {
        ASTNode* func = parse_function(parser);
        if (func) add_child(program, func);
    }
    
    return program;
}

ASTNode* parse_function(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    
    if (token->type != TOKEN_INT && token->type != TOKEN_FLOAT && 
        token->type != TOKEN_CHAR && token->type != TOKEN_VOID) {
        add_parser_error(parser, "Expected return type", token->line, token->column);
        return NULL;
    }
    
    advance_parser(parser);
    
    token = current_token(parser);
    if (!token || token->type != TOKEN_IDENTIFIER) {
        add_parser_error(parser, "Expected function name", 
                        token ? token->line : 0, token ? token->column : 0);
        return NULL;
    }
    
    char func_name[50];
    strcpy(func_name, token->value);
    advance_parser(parser);
    
    if (!expect(parser, TOKEN_LPAREN, "Expected '(' after function name")) {
        return NULL;
    }
    
    while (current_token(parser) && current_token(parser)->type != TOKEN_RPAREN) {
        advance_parser(parser);
    }
    
    if (!expect(parser, TOKEN_RPAREN, "Expected ')' after parameters")) {
        return NULL;
    }
    
    ASTNode* body = parse_block(parser);
    if (!body) {
        add_parser_error(parser, "Expected function body", 
                        token ? token->line : 0, token ? token->column : 0);
        return NULL;
    }
    
    ASTNode* func = create_ast_node(NODE_FUNCTION, func_name, token->line, token->column);
    add_child(func, body);
    
    return func;
}

ASTNode* parse_block(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    
    if (token->type != TOKEN_LBRACE) {
        add_parser_error(parser, "Expected '{' to start block", token->line, token->column);
        return NULL;
    }
    
    advance_parser(parser);
    
    ASTNode* block = create_ast_node(NODE_BLOCK, NULL, token->line, token->column);
    
    while (current_token(parser) && current_token(parser)->type != TOKEN_RBRACE) {
        ASTNode* stmt = parse_statement(parser);
        if (stmt) {
            add_child(block, stmt);
        } else {
            advance_parser(parser);
        }
    }
    
    if (!expect(parser, TOKEN_RBRACE, "Expected '}' to end block")) {
    }
    
    return block;
}

ASTNode* parse_statement(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    
    switch(token->type) {
        case TOKEN_INT:
        case TOKEN_FLOAT:
        case TOKEN_CHAR:
            return parse_var_decl(parser);
            
        case TOKEN_IF:
            return parse_if_statement(parser);
            
        case TOKEN_RETURN:
            return parse_return_statement(parser);
            
        case TOKEN_IDENTIFIER:
            if (peek_token(parser, 1) && peek_token(parser, 1)->type == TOKEN_LPAREN) {
                return parse_function_call(parser);
            }
            else if (peek_token(parser, 1) && peek_token(parser, 1)->type == TOKEN_ASSIGN) {
                return parse_assignment(parser);
            }
            else if (peek_token(parser, 1) && peek_token(parser, 1)->type == TOKEN_LBRACKET) {
                return parse_assignment(parser);
            }
            else {
                advance_parser(parser);
                if (current_token(parser) && current_token(parser)->type == TOKEN_SEMICOLON) {
                    advance_parser(parser);
                }
                return NULL;
            }
            
        case TOKEN_LBRACE:
            return parse_block(parser);
            
        default:
            add_parser_error(parser, "Unexpected token", token->line, token->column);
            advance_parser(parser);
            return NULL;
    }
}

ASTNode* parse_var_decl(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    
    char type_name[20];
    strcpy(type_name, token->value);
    advance_parser(parser);
    
    token = current_token(parser);
    if (!token || token->type != TOKEN_IDENTIFIER) {
        add_parser_error(parser, "Expected variable name", 
                        token ? token->line : 0, token ? token->column : 0);
        return NULL;
    }
    
    char var_name[50];
    strcpy(var_name, token->value);
    advance_parser(parser);
    
    int is_array = 0;
    int array_size = 0;
    
    if (current_token(parser) && current_token(parser)->type == TOKEN_LBRACKET) {
        is_array = 1;
        advance_parser(parser);
        
        token = current_token(parser);
        if (token && token->type == TOKEN_INTEGER) {
            array_size = atoi(token->value);
            advance_parser(parser);
        } else {
            add_parser_error(parser, "Expected array size", 
                            token ? token->line : 0, token ? token->column : 0);
        }
        
        if (!expect(parser, TOKEN_RBRACKET, "Expected ']' after array size")) {
            return NULL;
        }
    }
    
    ASTNode* var_decl = create_ast_node(
        is_array ? NODE_ARRAY_DECL : NODE_VAR_DECL, 
        var_name, 
        token->line, 
        token->column
    );
    
    if (is_array) {
        char size_str[10];
        sprintf(size_str, "%d", array_size);
        ASTNode* size_node = create_ast_node(NODE_INTEGER, size_str, token->line, token->column);
        add_child(var_decl, size_node);
    }
    
    if (current_token(parser) && current_token(parser)->type == TOKEN_ASSIGN) {
        advance_parser(parser);
        
        ASTNode* init = parse_expression(parser);
        if (init) add_child(var_decl, init);
    }
    
    if (!expect(parser, TOKEN_SEMICOLON, "Expected ';' after variable declaration")) {
        free_ast(var_decl);
        return NULL;
    }
    
    return var_decl;
}

ASTNode* parse_array_access(Parser* parser, const char* array_name, int line, int column) {
    fprintf(stderr, "DEBUG: parse_array_access called for %s at line %d\n", array_name, line);
    
    // array_name already has the identifier name
    advance_parser(parser); // Skip [
    
    ASTNode* index = parse_expression(parser);
    if (!index) {
        add_parser_error(parser, "Expected array index", line, column);
        return NULL;
    }
    
    if (!expect(parser, TOKEN_RBRACKET, "Expected ']' after array index")) {
        free_ast(index);
        return NULL;
    }
    
    // Create node with the array name
    ASTNode* access = create_ast_node(NODE_ARRAY_ACCESS, array_name, line, column);
    add_child(access, index);
    
    fprintf(stderr, "DEBUG: Created ARRAY_ACCESS node for %s at line %d, value=%s\n", 
            array_name, line, access->value);
    
    return access;
}

ASTNode* parse_assignment(Parser* parser) {
    Token* token = current_token(parser);
    if (!token || token->type != TOKEN_IDENTIFIER) return NULL;
    
    char* var_name = strdup(token->value);
    advance_parser(parser);
    
    ASTNode* left = NULL;
    
    if (current_token(parser) && current_token(parser)->type == TOKEN_LBRACKET) {
        left = parse_array_access(parser, var_name, token->line, token->column);
    } else {
        left = create_ast_node(NODE_IDENTIFIER, var_name, token->line, token->column);
    }
    free(var_name);
    
    if (!left) return NULL;
    
    if (!expect(parser, TOKEN_ASSIGN, "Expected '=' in assignment")) {
        free_ast(left);
        return NULL;
    }
    
    ASTNode* right = parse_expression(parser);
    if (!right) {
        free_ast(left);
        return NULL;
    }
    
    if (!expect(parser, TOKEN_SEMICOLON, "Expected ';' after assignment")) {
        free_ast(left);
        free_ast(right);
        return NULL;
    }
    
    ASTNode* assign = create_ast_node(NODE_ASSIGN, NULL, token->line, token->column);
    add_child(assign, left);
    add_child(assign, right);
    
    return assign;
}

ASTNode* parse_function_call(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    
    char* func_name = strdup(token->value);
    advance_parser(parser);
    
    if (!expect(parser, TOKEN_LPAREN, "Expected '(' after function name")) {
        free(func_name);
        return NULL;
    }
    
    while (current_token(parser) && current_token(parser)->type != TOKEN_RPAREN) {
        ASTNode* arg = parse_expression(parser);
        if (arg) free_ast(arg);
        
        if (current_token(parser) && current_token(parser)->type == TOKEN_COMMA) {
            advance_parser(parser);
        }
    }
    
    if (!expect(parser, TOKEN_RPAREN, "Expected ')' after arguments")) {
        free(func_name);
        return NULL;
    }
    
    if (!expect(parser, TOKEN_SEMICOLON, "Expected ';' after function call")) {
        free(func_name);
        return NULL;
    }
    
    ASTNode* call = create_ast_node(NODE_FUNCTION_CALL, func_name, token->line, token->column);
    free(func_name);
    return call;
}

ASTNode* parse_if_statement(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    
    advance_parser(parser);
    
    if (!expect(parser, TOKEN_LPAREN, "Expected '(' after if")) {
        return NULL;
    }
    
    ASTNode* condition = parse_expression(parser);
    if (!condition) {
        return NULL;
    }
    
    if (!expect(parser, TOKEN_RPAREN, "Expected ')' after condition")) {
        free_ast(condition);
        return NULL;
    }
    
    ASTNode* then_stmt = parse_statement(parser);
    if (!then_stmt) {
        free_ast(condition);
        return NULL;
    }
    
    ASTNode* if_stmt = create_ast_node(NODE_IF_STMT, NULL, token->line, token->column);
    add_child(if_stmt, condition);
    add_child(if_stmt, then_stmt);
    
    if (current_token(parser) && current_token(parser)->type == TOKEN_ELSE) {
        advance_parser(parser);
        ASTNode* else_stmt = parse_statement(parser);
        if (else_stmt) add_child(if_stmt, else_stmt);
    }
    
    return if_stmt;
}

ASTNode* parse_return_statement(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    
    advance_parser(parser);
    
    ASTNode* expr = NULL;
    
    if (current_token(parser) && current_token(parser)->type != TOKEN_SEMICOLON) {
        expr = parse_expression(parser);
    }
    
    if (!expect(parser, TOKEN_SEMICOLON, "Expected ';' after return")) {
        if (expr) free_ast(expr);
        return NULL;
    }
    
    ASTNode* ret_stmt = create_ast_node(NODE_RETURN_STMT, NULL, token->line, token->column);
    if (expr) add_child(ret_stmt, expr);
    
    return ret_stmt;
}

ASTNode* parse_expression(Parser* parser) {
    return parse_comparison(parser);
}

ASTNode* parse_comparison(Parser* parser) {
    ASTNode* left = parse_addition(parser);
    if (!left) return NULL;
    
    Token* token = current_token(parser);
    if (token && (token->type == TOKEN_GT || token->type == TOKEN_LT ||
                  token->type == TOKEN_EQ || token->type == TOKEN_NEQ ||
                  token->type == TOKEN_GTE || token->type == TOKEN_LTE ||
                  token->type == TOKEN_ASSIGN)) {
        
        char op[3];
        strcpy(op, token->value);
        advance_parser(parser);
        
        ASTNode* right = parse_addition(parser);
        if (!right) {
            free_ast(left);
            return NULL;
        }
        
        ASTNode* binop = create_ast_node(NODE_BINARY_OP, op, token->line, token->column);
        add_child(binop, left);
        add_child(binop, right);
        return binop;
    }
    
    return left;
}

ASTNode* parse_addition(Parser* parser) {
    ASTNode* left = parse_multiplication(parser);
    if (!left) return NULL;
    
    while (1) {
        Token* token = current_token(parser);
        if (token && (token->type == TOKEN_PLUS || token->type == TOKEN_MINUS)) {
            char op[2];
            strcpy(op, token->value);
            advance_parser(parser);
            
            ASTNode* right = parse_multiplication(parser);
            if (!right) {
                free_ast(left);
                return NULL;
            }
            
            ASTNode* binop = create_ast_node(NODE_BINARY_OP, op, token->line, token->column);
            add_child(binop, left);
            add_child(binop, right);
            left = binop;
        } else {
            break;
        }
    }
    
    return left;
}

ASTNode* parse_multiplication(Parser* parser) {
    ASTNode* left = parse_primary(parser);
    if (!left) return NULL;
    
    while (1) {
        Token* token = current_token(parser);
        if (token && (token->type == TOKEN_MUL || token->type == TOKEN_DIV)) {
            char op[2];
            strcpy(op, token->value);
            advance_parser(parser);
            
            ASTNode* right = parse_primary(parser);
            if (!right) {
                free_ast(left);
                return NULL;
            }
            
            ASTNode* binop = create_ast_node(NODE_BINARY_OP, op, token->line, token->column);
            add_child(binop, left);
            add_child(binop, right);
            left = binop;
        } else {
            break;
        }
    }
    
    return left;
}

ASTNode* parse_primary(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    
    ASTNode* node = NULL;
    
    if (token->type == TOKEN_INTEGER) {
        node = create_ast_node(NODE_INTEGER, token->value, token->line, token->column);
        advance_parser(parser);
    }
    else if (token->type == TOKEN_FLOAT_LIT) {
        node = create_ast_node(NODE_FLOAT_LIT, token->value, token->line, token->column);
        advance_parser(parser);
    }
    else if (token->type == TOKEN_CHAR_LIT) {
        node = create_ast_node(NODE_CHAR_LIT, token->value, token->line, token->column);
        advance_parser(parser);
    }
    else if (token->type == TOKEN_IDENTIFIER) {
        char* name = strdup(token->value);
        advance_parser(parser);
        
        if (current_token(parser) && current_token(parser)->type == TOKEN_LBRACKET) {
            node = parse_array_access(parser, name, token->line, token->column);
        } else {
            node = create_ast_node(NODE_IDENTIFIER, name, token->line, token->column);
        }
        free(name);
    }
    else if (token->type == TOKEN_STRING) {
        node = create_ast_node(NODE_STRING, token->value, token->line, token->column);
        advance_parser(parser);
    }
    else if (token->type == TOKEN_MINUS) {
        advance_parser(parser);
        ASTNode* expr = parse_primary(parser);
        if (expr) {
            if (expr->type == NODE_INTEGER) {
                int val = -atoi(expr->value);
                char neg_value[32];
                snprintf(neg_value, sizeof(neg_value), "%d", val);
                node = create_ast_node(NODE_INTEGER, neg_value, token->line, token->column);
                free_ast(expr);
            } else {
                node = create_ast_node(NODE_BINARY_OP, "-", token->line, token->column);
                add_child(node, create_ast_node(NODE_INTEGER, "0", token->line, token->column));
                add_child(node, expr);
            }
        }
    }
    else if (token->type == TOKEN_AMP) {
        advance_parser(parser);
        ASTNode* expr = parse_primary(parser);
        if (expr) {
            node = create_ast_node(NODE_UNARY_OP, "&", token->line, token->column);
            add_child(node, expr);
        }
    }
    else if (token->type == TOKEN_LPAREN) {
        advance_parser(parser);
        node = parse_expression(parser);
        if (!expect(parser, TOKEN_RPAREN, "Expected ')' after expression")) {
            if (node) free_ast(node);
            return NULL;
        }
    }
    else {
        add_parser_error(parser, "Expected expression", token->line, token->column);
        advance_parser(parser);
        return NULL;
    }
    
    return node;
}

ASTNode* parse(Parser* parser) {
    return parse_program(parser);
}