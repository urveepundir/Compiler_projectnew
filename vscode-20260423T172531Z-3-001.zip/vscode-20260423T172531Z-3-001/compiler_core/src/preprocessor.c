#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "../include/preprocessor.h"

Preprocessor* create_preprocessor() {
    Preprocessor* pp = (Preprocessor*)malloc(sizeof(Preprocessor));
    if (!pp) return NULL;
    
    pp->macros = NULL;
    pp->includes = NULL;
    pp->include_count = 0;
    pp->errors = NULL;
    pp->error_count = 0;
    
    return pp;
}

void free_preprocessor(Preprocessor* pp) {
    if (!pp) return;
    
    // Free macros
    Macro* m = pp->macros;
    while (m) {
        Macro* next = m->next;
        if (m->name) free(m->name);
        if (m->value) free(m->value);
        free(m);
        m = next;
    }
    
    // Free includes
    for (int i = 0; i < pp->include_count; i++) {
        if (pp->includes[i]) free(pp->includes[i]);
    }
    if (pp->includes) free(pp->includes);
    
    // Free errors
    for (int i = 0; i < pp->error_count; i++) {
        if (pp->errors[i]) free(pp->errors[i]);
    }
    if (pp->errors) free(pp->errors);
    
    free(pp);
}

void add_macro(Preprocessor* pp, const char* name, const char* value) {
    Macro* macro = (Macro*)malloc(sizeof(Macro));
    macro->name = strdup(name);
    macro->value = value ? strdup(value) : strdup("");
    macro->next = pp->macros;
    pp->macros = macro;
}

char* expand_macros(Preprocessor* pp, const char* line) {
    char* result = strdup(line);
    Macro* m = pp->macros;
    
    while (m) {
        char* pos = strstr(result, m->name);
        if (pos && strlen(m->value) > 0) {
            char* new_result = (char*)malloc(strlen(result) + strlen(m->value) + 1);
            *pos = '\0';
            sprintf(new_result, "%s%s%s", result, m->value, pos + strlen(m->name));
            free(result);
            result = new_result;
        }
        m = m->next;
    }
    
    return result;
}

char* preprocess(Preprocessor* pp, const char* source) {
    if (!source) return NULL;
    
    // First pass: collect macros and remove comments
    char* result = (char*)malloc(strlen(source) + 1);
    char* dest = result;
    const char* src = source;
    
    while (*src) {
        // Skip comments
        if (*src == '/' && *(src+1) == '/') {
            while (*src && *src != '\n') src++;
            if (*src == '\n') *dest++ = *src++;
        }
        else if (*src == '/' && *(src+1) == '*') {
            src += 2;
            while (*src && !(*src == '*' && *(src+1) == '/')) src++;
            if (*src) src += 2;
        }
        // Handle preprocessor directives
        else if (*src == '#') {
            const char* start = src;
            while (*src && *src != '\n') src++;
            
            char directive[256];
            int len = src - start;
            if (len < 256) {
                strncpy(directive, start, len);
                directive[len] = '\0';
                
                if (strstr(directive, "#define")) {
                    char* name = strchr(directive, ' ') + 1;
                    char* value = strchr(name, ' ');
                    if (value) {
                        *value++ = '\0';
                        add_macro(pp, name, value);
                    } else {
                        add_macro(pp, name, "");
                    }
                }
                else if (strstr(directive, "#include")) {
                    // Just remember include, don't add to output
                    char* filename = strchr(directive, '<');
                    if (!filename) filename = strchr(directive, '"');
                    if (filename) {
                        filename++;
                        char* end = strchr(filename, '>');
                        if (!end) end = strchr(filename, '"');
                        if (end) {
                            *end = '\0';
                            pp->includes = realloc(pp->includes, sizeof(char*) * (pp->include_count + 1));
                            pp->includes[pp->include_count++] = strdup(filename);
                        }
                    }
                }
            }
            
            if (*src == '\n') *dest++ = *src++;
        }
        else {
            *dest++ = *src++;
        }
    }
    *dest = '\0';
    
    // Second pass: expand macros
    char* expanded = expand_macros(pp, result);
    free(result);
    
    return expanded;
}