#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/semantic.h"

// Hash function for symbol table
unsigned int hash(const char* str, int table_size) {
    unsigned int hash = 0;
    while (*str) {
        hash = hash * 31 + *str++;
    }
    return hash % table_size;
}

// Create semantic analyzer
SemanticAnalyzer* create_semantic_analyzer() {
    SemanticAnalyzer* sa = (SemanticAnalyzer*)malloc(sizeof(SemanticAnalyzer));
    if (!sa) return NULL;
    
    sa->table = (SymbolTable*)malloc(sizeof(SymbolTable));
    sa->table->size = 211;
    sa->table->count = 0;
    sa->table->buckets = (Symbol**)calloc(sa->table->size, sizeof(Symbol*));
    
    sa->error_capacity = 50;
    sa->error_count = 0;
    sa->errors = (char**)malloc(sizeof(char*) * sa->error_capacity);
    
    sa->current_function = NULL;
    sa->in_loop = 0;
    sa->in_switch = 0;
    
    return sa;
}

void free_semantic_analyzer(SemanticAnalyzer* sa) {
    if (!sa) return;
    
    if (sa->table) {
        for (int i = 0; i < sa->table->size; i++) {
            Symbol* sym = sa->table->buckets[i];
            while (sym) {
                Symbol* next = sym->next;
                if (sym->name) free(sym->name);
                if (sym->type) free(sym->type);
                free(sym);
                sym = next;
            }
        }
        free(sa->table->buckets);
        free(sa->table);
    }
    
    for (int i = 0; i < sa->error_count; i++) {
        if (sa->errors[i]) free(sa->errors[i]);
    }
    free(sa->errors);
    
    if (sa->current_function) free(sa->current_function);
    free(sa);
}

void add_semantic_error(SemanticAnalyzer* sa, const char* message, int line, int column) {
    if (sa->error_count >= sa->error_capacity) {
        sa->error_capacity *= 2;
        sa->errors = (char**)realloc(sa->errors, sizeof(char*) * sa->error_capacity);
    }
    
    char error_msg[512];
    snprintf(error_msg, sizeof(error_msg), 
             "{\"line\":%d,\"column\":%d,\"message\":\"%s\",\"type\":\"semantic\"}",
             line, column, message);
    
    sa->errors[sa->error_count++] = strdup(error_msg);
    
    fprintf(stderr, "SEMANTIC ERROR: %s at line %d\n", message, line);
}

void add_symbol(SemanticAnalyzer* sa, const char* name, const char* type, int line, int is_initialized) {
    if (!sa || !sa->table || !name) return;
    
    Symbol* existing = lookup_symbol(sa, name);
    if (existing) {
        char error_msg[256];
        snprintf(error_msg, sizeof(error_msg), "Redeclaration of '%s'", name);
        add_semantic_error(sa, error_msg, line, 0);
        return;
    }
    
    Symbol* sym = (Symbol*)malloc(sizeof(Symbol));
    if (!sym) return;
    
    sym->name = strdup(name);
    sym->type = strdup(type);
    sym->line_declared = line;
    sym->is_initialized = is_initialized;
    sym->is_array = 0;
    sym->array_size = 0;
    sym->next = NULL;
    
    unsigned int index = hash(name, sa->table->size);
    sym->next = sa->table->buckets[index];
    sa->table->buckets[index] = sym;
    sa->table->count++;
}

void add_array_symbol(SemanticAnalyzer* sa, const char* name, const char* type, int line, int size) {
    if (!sa || !sa->table || !name) return;
    
    Symbol* existing = lookup_symbol(sa, name);
    if (existing) {
        char error_msg[256];
        snprintf(error_msg, sizeof(error_msg), "Redeclaration of array '%s'", name);
        add_semantic_error(sa, error_msg, line, 0);
        return;
    }
    
    Symbol* sym = (Symbol*)malloc(sizeof(Symbol));
    if (!sym) return;
    
    sym->name = strdup(name);
    sym->type = strdup(type);
    sym->line_declared = line;
    sym->is_initialized = 1;
    sym->is_array = 1;
    sym->array_size = size;
    sym->next = NULL;
    
    unsigned int index = hash(name, sa->table->size);
    sym->next = sa->table->buckets[index];
    sa->table->buckets[index] = sym;
    sa->table->count++;
    
    fprintf(stderr, "ARRAY SYMBOL ADDED: %s[%d] at line %d\n", name, size, line);
}

Symbol* lookup_symbol(SemanticAnalyzer* sa, const char* name) {
    if (!sa || !sa->table || !name) return NULL;
    
    unsigned int index = hash(name, sa->table->size);
    Symbol* sym = sa->table->buckets[index];
    
    while (sym) {
        if (strcmp(sym->name, name) == 0) {
            return sym;
        }
        sym = sym->next;
    }
    
    return NULL;
}

Symbol* lookup_symbol_current_scope(SemanticAnalyzer* sa, const char* name) {
    return lookup_symbol(sa, name);
}

const char* get_expression_type(SemanticAnalyzer* sa, ASTNode* node) {
    if (!node) return "unknown";
    
    switch (node->type) {
        case NODE_INTEGER:
            return "int";
        case NODE_FLOAT_LIT:
            return "float";
        case NODE_IDENTIFIER: {
            Symbol* sym = lookup_symbol(sa, node->value);
            return sym ? sym->type : "unknown";
        }
        case NODE_ARRAY_ACCESS: {
            Symbol* sym = lookup_symbol(sa, node->value);
            return sym ? sym->type : "unknown";
        }
        case NODE_BINARY_OP: {
            if (node->child_count < 2) return "unknown";
            const char* left = get_expression_type(sa, node->children[0]);
            const char* right = get_expression_type(sa, node->children[1]);
            if (strcmp(left, "float") == 0 || strcmp(right, "float") == 0) return "float";
            return "int";
        }
        case NODE_UNARY_OP: {
            if (node->child_count < 1) return "unknown";
            return get_expression_type(sa, node->children[0]);
        }
        default:
            return "unknown";
    }
}

int check_type_compatibility(const char* type1, const char* type2) {
    if (strcmp(type1, "unknown") == 0 || strcmp(type2, "unknown") == 0) return 1;
    if (strcmp(type1, type2) == 0) return 1;
    if (strcmp(type1, "float") == 0 && strcmp(type2, "int") == 0) return 1;
    if (strcmp(type1, "int") == 0 && strcmp(type2, "float") == 0) return 1;
    return 0;
}

void analyze_ast(SemanticAnalyzer* sa, ASTNode* node) {
    if (!node) return;
    
    switch (node->type) {
        case NODE_PROGRAM:
            for (int i = 0; i < node->child_count; i++) {
                analyze_ast(sa, node->children[i]);
            }
            break;
            
        case NODE_FUNCTION:
            if (sa->current_function) free(sa->current_function);
            sa->current_function = node->value ? strdup(node->value) : strdup("main");
            for (int i = 0; i < node->child_count; i++) {
                analyze_ast(sa, node->children[i]);
            }
            break;
            
        case NODE_BLOCK:
            for (int i = 0; i < node->child_count; i++) {
                analyze_ast(sa, node->children[i]);
            }
            break;
            
        case NODE_VAR_DECL: {
            if (!node->value) break;
            const char* var_type = "int";
            int is_initialized = (node->child_count > 0);
            add_symbol(sa, node->value, var_type, node->line, is_initialized);
            if (is_initialized) {
                analyze_ast(sa, node->children[0]);
                const char* init_type = get_expression_type(sa, node->children[0]);
                if (!check_type_compatibility(var_type, init_type)) {
                    char msg[256];
                    snprintf(msg, sizeof(msg), "Type mismatch: cannot initialize '%s' with '%s'", var_type, init_type);
                    add_semantic_error(sa, msg, node->line, node->column);
                }
            }
            break;
        }
        
        case NODE_ARRAY_DECL: {
            if (!node->value) break;
            int array_size = 0;
            if (node->child_count > 0 && node->children[0]->type == NODE_INTEGER) {
                array_size = atoi(node->children[0]->value);
            }
            add_array_symbol(sa, node->value, "int", node->line, array_size);
            if (node->child_count > 1) {
                analyze_ast(sa, node->children[1]);
            }
            break;
        }
        
        case NODE_ARRAY_ACCESS: {
            if (!node->value) break;
            
            Symbol* sym = lookup_symbol(sa, node->value);
            if (!sym) {
                char msg[256];
                snprintf(msg, sizeof(msg), "Array '%s' undeclared", node->value);
                add_semantic_error(sa, msg, node->line, node->column);
                break;
            }
            
            if (!sym->is_array) {
                char msg[256];
                snprintf(msg, sizeof(msg), "'%s' is not an array", node->value);
                add_semantic_error(sa, msg, node->line, node->column);
                break;
            }
            
            if (node->child_count > 0 && node->children[0] != NULL) {
                analyze_ast(sa, node->children[0]);
            }
            break;
        }
        
        case NODE_ASSIGN: {
            if (node->child_count < 2) break;
            
            if (node->children[0]->type != NODE_IDENTIFIER && 
                node->children[0]->type != NODE_ARRAY_ACCESS) {
                add_semantic_error(sa, "Left side of assignment must be a variable", node->line, node->column);
                break;
            }
            
            const char* var_name = NULL;
            if (node->children[0]->type == NODE_IDENTIFIER) {
                var_name = node->children[0]->value;
            } else if (node->children[0]->type == NODE_ARRAY_ACCESS) {
                var_name = node->children[0]->value;
            }
            
            if (!var_name) break;
            
            Symbol* sym = lookup_symbol(sa, var_name);
            if (!sym) {
                char msg[256];
                snprintf(msg, sizeof(msg), "'%s' undeclared", var_name);
                add_semantic_error(sa, msg, node->line, node->column);
                break;
            }

            if (node->children[0]->type == NODE_ARRAY_ACCESS) {
                if (!sym->is_array) {
                    char msg[256];
                    snprintf(msg, sizeof(msg), "'%s' is not an array", var_name);
                    add_semantic_error(sa, msg, node->line, node->column);
                    break;
                }

                if (node->children[0]->child_count > 0 && node->children[0]->children[0] != NULL) {
                    analyze_ast(sa, node->children[0]->children[0]);
                }
            }
            
            // Mark as initialized BEFORE analyzing right side
            sym->is_initialized = 1;
            
            analyze_ast(sa, node->children[1]);
            const char* right_type = get_expression_type(sa, node->children[1]);
            
            if (!check_type_compatibility(sym->type, right_type)) {
                char msg[256];
                snprintf(msg, sizeof(msg), "Type mismatch: assigning '%s' to '%s'", right_type, sym->type);
                add_semantic_error(sa, msg, node->line, node->column);
            }
            
            break;
        }
        
        case NODE_IF_STMT: {
            if (node->child_count < 2) break;
            
            ASTNode* condition = node->children[0];
            if (condition && condition->type == NODE_BINARY_OP) {
                const char* op = condition->value;
                if (op && strcmp(op, "=") == 0) {
                    add_semantic_error(sa, "Did you mean '==' instead of '='? Use comparison operator in if condition", 
                                      node->line, node->column);
                }
            }
            
            analyze_ast(sa, node->children[0]);
            const char* cond_type = get_expression_type(sa, node->children[0]);
            if (strcmp(cond_type, "int") != 0 && strcmp(cond_type, "unknown") != 0) {
                add_semantic_error(sa, "If condition must be integer expression", node->line, node->column);
            }
            
            analyze_ast(sa, node->children[1]);
            if (node->child_count > 2) analyze_ast(sa, node->children[2]);
            break;
        }
        
        case NODE_RETURN_STMT: {
            if (node->child_count > 0) {
                analyze_ast(sa, node->children[0]);
                const char* ret_type = get_expression_type(sa, node->children[0]);
                if (strcmp(ret_type, "int") != 0 && strcmp(ret_type, "unknown") != 0) {
                    add_semantic_error(sa, "Return type mismatch (expected int)", node->line, node->column);
                }
            }
            break;
        }
        
        case NODE_BINARY_OP: {
            // Check for division by zero
            if (node->value && strcmp(node->value, "/") == 0) {
                if (node->child_count >= 2 && node->children[1] != NULL) {
                    ASTNode* right = node->children[1];
                    analyze_ast(sa, right);
                    
                    if (right->type == NODE_INTEGER && atoi(right->value) == 0) {
                        add_semantic_error(sa, "Division by zero", node->line, node->column);
                        fprintf(stderr, "DIVISION BY ZERO DETECTED at line %d\n", node->line);
                    }
                }
            }
            
            for (int i = 0; i < node->child_count; i++) {
                analyze_ast(sa, node->children[i]);
            }
            break;
        }
        
        case NODE_INTEGER:
        case NODE_FLOAT_LIT:
        case NODE_STRING:
            break;
            
        case NODE_IDENTIFIER: {
            if (!node->value) break;
            
            Symbol* sym = lookup_symbol(sa, node->value);
            if (!sym) {
                char msg[256];
                snprintf(msg, sizeof(msg), "'%s' undeclared", node->value);
                add_semantic_error(sa, msg, node->line, node->column);
            } else if (!sym->is_initialized) {
                // Variable is used but not initialized
                char msg[256];
                snprintf(msg, sizeof(msg), "'%s' may be uninitialized", node->value);
                add_semantic_error(sa, msg, node->line, node->column);
                fprintf(stderr, "UNINITIALIZED VARIABLE: %s at line %d\n", node->value, node->line);
            }
            break;
        }
        
        case NODE_FUNCTION_CALL:
            break;
            
        default:
            break;
    }
}
