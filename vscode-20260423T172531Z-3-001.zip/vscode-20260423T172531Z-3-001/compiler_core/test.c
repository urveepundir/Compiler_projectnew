int main() {
    int value = 10;
    value = 1;
    return 0;
}