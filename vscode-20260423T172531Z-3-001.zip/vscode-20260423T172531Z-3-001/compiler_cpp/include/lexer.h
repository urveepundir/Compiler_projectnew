#ifndef CPP_LEXER_H
#define CPP_LEXER_H

#include "token.h"

typedef struct {
    char* source;
    int position;
    int line;
    int column;
    Token** tokens;
    int token_count;
    int token_capacity;
    char** errors;
    int error_count;
    int error_capacity;
} Lexer;

Lexer* create_lexer(const char* source);
void free_lexer(Lexer* lexer);
void tokenize(Lexer* lexer);
void add_token(Lexer* lexer, TokenType type, const char* value);
void add_error(Lexer* lexer, int line, int column, const char* message, const char* suggestion);

char current_char(Lexer* lexer);
char peek_char(Lexer* lexer);
void advance(Lexer* lexer);
void skip_whitespace(Lexer* lexer);
void skip_comment(Lexer* lexer);
void read_identifier(Lexer* lexer);
void read_number(Lexer* lexer);
void read_string(Lexer* lexer);
void read_character(Lexer* lexer);
void read_operator(Lexer* lexer);

#endif
