#ifndef CPP_PARSER_H
#define CPP_PARSER_H

#include "token.h"

typedef enum {
    NODE_PROGRAM,
    NODE_FUNCTION,
    NODE_BLOCK,
    NODE_VAR_DECL,
    NODE_ARRAY_DECL,
    NODE_ARRAY_ACCESS,
    NODE_ASSIGN,
    NODE_IF_STMT,
    NODE_RETURN_STMT,
    NODE_BINARY_OP,
    NODE_INTEGER,
    NODE_FLOAT_LIT,
    NODE_CHAR_LIT,
    NODE_STRING,
    NODE_BOOL_LIT,
    NODE_IDENTIFIER,
    NODE_FUNCTION_CALL
} NodeType;

typedef struct ASTNode {
    NodeType type;
    char* value;
    char* data_type;
    struct ASTNode** children;
    int child_count;
    int line;
    int column;
} ASTNode;

typedef struct {
    Token** tokens;
    int token_count;
    int position;
    char** errors;
    int error_count;
    int error_capacity;
} Parser;

Parser* create_parser(Token** tokens, int token_count);
void free_parser(Parser* parser);
ASTNode* parse(Parser* parser);
void add_parser_error(Parser* parser, const char* message, int line, int column);
ASTNode* create_ast_node(NodeType type, const char* value, const char* data_type, int line, int column);
void add_child(ASTNode* parent, ASTNode* child);
void print_ast(ASTNode* node, int level);
void free_ast(ASTNode* node);

ASTNode* parse_program(Parser* parser);
ASTNode* parse_function(Parser* parser);
ASTNode* parse_block(Parser* parser);
ASTNode* parse_statement(Parser* parser);
ASTNode* parse_var_decl(Parser* parser);
ASTNode* parse_assignment(Parser* parser);
ASTNode* parse_if_statement(Parser* parser);
ASTNode* parse_return_statement(Parser* parser);
ASTNode* parse_function_call_statement(Parser* parser);
ASTNode* parse_expression(Parser* parser);
ASTNode* parse_comparison(Parser* parser);
ASTNode* parse_addition(Parser* parser);
ASTNode* parse_multiplication(Parser* parser);
ASTNode* parse_primary(Parser* parser);

Token* current_token(Parser* parser);
Token* peek_token(Parser* parser, int offset);
void advance_parser(Parser* parser);
int match(Parser* parser, TokenType type);
int expect(Parser* parser, TokenType type, const char* error_msg);

#endif
