#ifndef CPP_PREPROCESSOR_H
#define CPP_PREPROCESSOR_H

typedef struct Macro {
    char* name;
    char* value;
    struct Macro* next;
} Macro;

typedef struct {
    Macro* macros;
    char** includes;
    int include_count;
    char** errors;
    int error_count;
} Preprocessor;

Preprocessor* create_preprocessor();
void free_preprocessor(Preprocessor* pp);
char* preprocess(Preprocessor* pp, const char* source);
void add_macro(Preprocessor* pp, const char* name, const char* value);
char* expand_macros(Preprocessor* pp, const char* line);

#endif
