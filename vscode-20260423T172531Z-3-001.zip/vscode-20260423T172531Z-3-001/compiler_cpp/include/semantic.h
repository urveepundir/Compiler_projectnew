#ifndef CPP_SEMANTIC_H
#define CPP_SEMANTIC_H

#include "parser.h"

typedef struct Symbol {
    char* name;
    char* type;
    int line_declared;
    int is_initialized;
    int is_array;
    int array_size;
    struct Symbol* next;
} Symbol;

typedef struct {
    Symbol** buckets;
    int size;
    int count;
} SymbolTable;

typedef struct {
    SymbolTable* table;
    char** errors;
    int error_count;
    int error_capacity;
    char* current_function;
    char* current_function_type;
} SemanticAnalyzer;

SemanticAnalyzer* create_semantic_analyzer();
void free_semantic_analyzer(SemanticAnalyzer* sa);
void analyze_ast(SemanticAnalyzer* sa, ASTNode* node);
void add_semantic_error(SemanticAnalyzer* sa, const char* message, int line, int column);
void add_symbol(SemanticAnalyzer* sa, const char* name, const char* type, int line, int is_initialized);
void add_array_symbol(SemanticAnalyzer* sa, const char* name, const char* type, int line, int size);
Symbol* lookup_symbol(SemanticAnalyzer* sa, const char* name);
const char* get_expression_type(SemanticAnalyzer* sa, ASTNode* node);
int check_type_compatibility(const char* expected, const char* actual);

#endif
