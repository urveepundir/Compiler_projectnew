#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "include/lexer.h"
#include "include/parser.h"
#include "include/semantic.h"
#include "include/preprocessor.h"

static void print_json_string(const char* value) {
    const unsigned char* p = (const unsigned char*)(value ? value : "");
    putchar('"');
    while (*p) {
        switch (*p) {
            case '\\': fputs("\\\\", stdout); break;
            case '"': fputs("\\\"", stdout); break;
            case '\n': fputs("\\n", stdout); break;
            case '\r': fputs("\\r", stdout); break;
            case '\t': fputs("\\t", stdout); break;
            default: putchar(*p); break;
        }
        p++;
    }
    putchar('"');
}

int main() {
    char buffer[65536];
    size_t bytes = fread(buffer, 1, sizeof(buffer) - 1, stdin);
    buffer[bytes] = '\0';

    Preprocessor* pp = create_preprocessor();
    char* preprocessed_code = preprocess(pp, buffer);
    Lexer* lexer = create_lexer(preprocessed_code);
    tokenize(lexer);
    Parser* parser = create_parser(lexer->tokens, lexer->token_count);
    ASTNode* ast = parse(parser);
    SemanticAnalyzer* semantic = create_semantic_analyzer();
    if (ast) analyze_ast(semantic, ast);

    printf("{\n");

    printf("  \"tokens\": [\n");
    int visible_tokens = 0;
    for (int i = 0; i < lexer->token_count; i++) {
        Token* token = lexer->tokens[i];
        if (token->type == TOKEN_EOF) continue;
        if (visible_tokens > 0) printf(",\n");
        printf("    {\"type\":");
        print_json_string(token_type_to_string(token->type));
        printf(",\"value\":");
        print_json_string(token->value);
        printf(",\"line\":%d,\"col\":%d}", token->line, token->column);
        visible_tokens++;
    }
    printf("\n  ],\n");

    printf("  \"lex_errors\": [\n");
    for (int i = 0; i < lexer->error_count; i++) {
        if (i > 0) printf(",\n");
        printf("    %s", lexer->errors[i]);
    }
    printf("\n  ],\n");

    printf("  \"syntax_errors\": [\n");
    for (int i = 0; i < parser->error_count; i++) {
        if (i > 0) printf(",\n");
        printf("    %s", parser->errors[i]);
    }
    printf("\n  ],\n");

    printf("  \"semantic_errors\": [\n");
    for (int i = 0; i < semantic->error_count; i++) {
        if (i > 0) printf(",\n");
        printf("    %s", semantic->errors[i]);
    }
    printf("\n  ],\n");

    printf("  \"ast\": ");
    if (ast) {
        if (parser->error_count == 0 && semantic->error_count == 0) {
            print_json_string("Parsing successful");
        } else {
            char status[128];
            snprintf(status, sizeof(status),
                     "Parsing had %d syntax errors, %d semantic errors",
                     parser->error_count, semantic->error_count);
            print_json_string(status);
        }
    } else {
        print_json_string("No AST generated");
    }
    printf("\n}\n");

    if (ast) free_ast(ast);
    free_semantic_analyzer(semantic);
    free_parser(parser);
    free_lexer(lexer);
    free_preprocessor(pp);
    free(preprocessed_code);
    return 0;
}
