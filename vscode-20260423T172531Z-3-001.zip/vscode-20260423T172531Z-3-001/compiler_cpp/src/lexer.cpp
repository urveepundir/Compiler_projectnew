#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "../include/lexer.h"

static int is_identifier_char(char c) {
    return isalnum((unsigned char)c) || c == '_';
}

Lexer* create_lexer(const char* source) {
    Lexer* lexer = (Lexer*)malloc(sizeof(Lexer));
    if (!lexer) return NULL;

    lexer->source = source ? strdup(source) : strdup("");
    lexer->position = 0;
    lexer->line = 1;
    lexer->column = 1;
    lexer->token_capacity = 100;
    lexer->token_count = 0;
    lexer->tokens = (Token**)malloc(sizeof(Token*) * lexer->token_capacity);
    lexer->error_capacity = 50;
    lexer->error_count = 0;
    lexer->errors = (char**)malloc(sizeof(char*) * lexer->error_capacity);
    return lexer;
}

void free_lexer(Lexer* lexer) {
    if (!lexer) return;
    if (lexer->source) free(lexer->source);
    for (int i = 0; i < lexer->token_count; i++) {
        free_token(lexer->tokens[i]);
    }
    for (int i = 0; i < lexer->error_count; i++) {
        if (lexer->errors[i]) free(lexer->errors[i]);
    }
    if (lexer->tokens) free(lexer->tokens);
    if (lexer->errors) free(lexer->errors);
    free(lexer);
}

char current_char(Lexer* lexer) {
    if (lexer->position < (int)strlen(lexer->source)) {
        return lexer->source[lexer->position];
    }
    return '\0';
}

char peek_char(Lexer* lexer) {
    if (lexer->position + 1 < (int)strlen(lexer->source)) {
        return lexer->source[lexer->position + 1];
    }
    return '\0';
}

void advance(Lexer* lexer) {
    if (lexer->position < (int)strlen(lexer->source)) {
        if (current_char(lexer) == '\n') {
            lexer->line++;
            lexer->column = 1;
        } else {
            lexer->column++;
        }
        lexer->position++;
    }
}

void add_token(Lexer* lexer, TokenType type, const char* value) {
    if (lexer->token_count >= lexer->token_capacity) {
        lexer->token_capacity *= 2;
        lexer->tokens = (Token**)realloc(lexer->tokens, sizeof(Token*) * lexer->token_capacity);
    }

    lexer->tokens[lexer->token_count++] =
        create_token(type, value, lexer->line, lexer->column - (int)strlen(value));
}

void add_error(Lexer* lexer, int line, int column, const char* message, const char* suggestion) {
    if (lexer->error_count >= lexer->error_capacity) {
        lexer->error_capacity *= 2;
        lexer->errors = (char**)realloc(lexer->errors, sizeof(char*) * lexer->error_capacity);
    }

    char error_msg[512];
    snprintf(error_msg, sizeof(error_msg),
             "{\"line\":%d,\"column\":%d,\"message\":\"%s\",\"suggestion\":\"%s\"}",
             line, column, message, suggestion);

    lexer->errors[lexer->error_count++] = strdup(error_msg);
}

void skip_whitespace(Lexer* lexer) {
    while (isspace((unsigned char)current_char(lexer))) {
        advance(lexer);
    }
}

void skip_comment(Lexer* lexer) {
    if (current_char(lexer) == '/' && peek_char(lexer) == '/') {
        while (current_char(lexer) && current_char(lexer) != '\n') {
            advance(lexer);
        }
        return;
    }

    if (current_char(lexer) == '/' && peek_char(lexer) == '*') {
        advance(lexer);
        advance(lexer);
        while (current_char(lexer)) {
            if (current_char(lexer) == '*' && peek_char(lexer) == '/') {
                advance(lexer);
                advance(lexer);
                break;
            }
            advance(lexer);
        }
    }
}

void read_identifier(Lexer* lexer) {
    int start_pos = lexer->position;
    while (is_identifier_char(current_char(lexer))) {
        advance(lexer);
    }

    int len = lexer->position - start_pos;
    char* value = (char*)malloc(len + 1);
    strncpy(value, lexer->source + start_pos, len);
    value[len] = '\0';

    TokenType type = TOKEN_IDENTIFIER;
    if (strcmp(value, "int") == 0) type = TOKEN_INT;
    else if (strcmp(value, "float") == 0) type = TOKEN_FLOAT;
    else if (strcmp(value, "char") == 0) type = TOKEN_CHAR;
    else if (strcmp(value, "double") == 0) type = TOKEN_DOUBLE;
    else if (strcmp(value, "bool") == 0) type = TOKEN_BOOL;
    else if (strcmp(value, "string") == 0) type = TOKEN_STRING_KW;
    else if (strcmp(value, "if") == 0) type = TOKEN_IF;
    else if (strcmp(value, "else") == 0) type = TOKEN_ELSE;
    else if (strcmp(value, "while") == 0) type = TOKEN_WHILE;
    else if (strcmp(value, "for") == 0) type = TOKEN_FOR;
    else if (strcmp(value, "return") == 0) type = TOKEN_RETURN;
    else if (strcmp(value, "void") == 0) type = TOKEN_VOID;
    else if (strcmp(value, "true") == 0) type = TOKEN_TRUE;
    else if (strcmp(value, "false") == 0) type = TOKEN_FALSE;

    add_token(lexer, type, value);
    free(value);
}

void read_number(Lexer* lexer) {
    int start_pos = lexer->position;
    int is_float = 0;

    while (isdigit((unsigned char)current_char(lexer))) {
        advance(lexer);
    }

    if (current_char(lexer) == '.' && isdigit((unsigned char)peek_char(lexer))) {
        is_float = 1;
        advance(lexer);
        while (isdigit((unsigned char)current_char(lexer))) {
            advance(lexer);
        }
    }

    int len = lexer->position - start_pos;
    char* value = (char*)malloc(len + 1);
    strncpy(value, lexer->source + start_pos, len);
    value[len] = '\0';

    add_token(lexer, is_float ? TOKEN_FLOAT_LIT : TOKEN_INTEGER, value);
    free(value);
}

void read_string(Lexer* lexer) {
    int start_pos = lexer->position;
    int start_col = lexer->column;
    advance(lexer);

    while (current_char(lexer) && current_char(lexer) != '"') {
        if (current_char(lexer) == '\\' && peek_char(lexer)) {
            advance(lexer);
        }
        advance(lexer);
    }

    if (current_char(lexer) == '"') {
        advance(lexer);
        int len = lexer->position - start_pos;
        char* value = (char*)malloc(len + 1);
        strncpy(value, lexer->source + start_pos, len);
        value[len] = '\0';
        add_token(lexer, TOKEN_STRING, value);
        free(value);
        return;
    }

    add_error(lexer, lexer->line, start_col,
              "Unterminated string literal",
              "Add a closing double quote to finish the string");
    add_token(lexer, TOKEN_ERROR, "\"");
}

void read_character(Lexer* lexer) {
    int start_pos = lexer->position;
    int start_col = lexer->column;
    advance(lexer);

    if (current_char(lexer) == '\\' && peek_char(lexer)) {
        advance(lexer);
    }
    if (current_char(lexer)) {
        advance(lexer);
    }

    if (current_char(lexer) == '\'') {
        advance(lexer);
        int len = lexer->position - start_pos;
        char* value = (char*)malloc(len + 1);
        strncpy(value, lexer->source + start_pos, len);
        value[len] = '\0';
        add_token(lexer, TOKEN_CHAR_LIT, value);
        free(value);
        return;
    }

    add_error(lexer, lexer->line, start_col,
              "Unterminated character literal",
              "Add a closing single quote to finish the character literal");
    add_token(lexer, TOKEN_ERROR, "'");
}

void read_operator(Lexer* lexer) {
    int start_col = lexer->column;
    char c = current_char(lexer);

    switch (c) {
        case ';':
            if (peek_char(lexer) == ';') {
                add_error(lexer, lexer->line, start_col + 1,
                          "Empty statement (double semicolon)",
                          "Remove the extra semicolon");
            }
            advance(lexer);
            add_token(lexer, TOKEN_SEMICOLON, ";");
            return;
        case ',':
            advance(lexer);
            add_token(lexer, TOKEN_COMMA, ",");
            return;
        case '(':
            advance(lexer);
            add_token(lexer, TOKEN_LPAREN, "(");
            return;
        case ')':
            advance(lexer);
            add_token(lexer, TOKEN_RPAREN, ")");
            return;
        case '{':
            advance(lexer);
            add_token(lexer, TOKEN_LBRACE, "{");
            return;
        case '}':
            advance(lexer);
            add_token(lexer, TOKEN_RBRACE, "}");
            return;
        case '[':
            advance(lexer);
            add_token(lexer, TOKEN_LBRACKET, "[");
            return;
        case ']':
            advance(lexer);
            add_token(lexer, TOKEN_RBRACKET, "]");
            return;
        case '+':
            advance(lexer);
            add_token(lexer, TOKEN_PLUS, "+");
            return;
        case '-':
            advance(lexer);
            add_token(lexer, TOKEN_MINUS, "-");
            return;
        case '*':
            advance(lexer);
            add_token(lexer, TOKEN_MUL, "*");
            return;
        case '/':
            advance(lexer);
            add_token(lexer, TOKEN_DIV, "/");
            return;
        case '%':
            advance(lexer);
            add_token(lexer, TOKEN_MOD, "%");
            return;
        case '=':
            advance(lexer);
            if (current_char(lexer) == '=') {
                advance(lexer);
                add_token(lexer, TOKEN_EQ, "==");
            } else {
                add_token(lexer, TOKEN_ASSIGN, "=");
            }
            return;
        case '!':
            advance(lexer);
            if (current_char(lexer) == '=') {
                advance(lexer);
                add_token(lexer, TOKEN_NEQ, "!=");
            } else {
                add_token(lexer, TOKEN_NOT, "!");
            }
            return;
        case '<':
            advance(lexer);
            if (current_char(lexer) == '=') {
                advance(lexer);
                add_token(lexer, TOKEN_LTE, "<=");
            } else {
                add_token(lexer, TOKEN_LT, "<");
            }
            return;
        case '>':
            advance(lexer);
            if (current_char(lexer) == '=') {
                advance(lexer);
                add_token(lexer, TOKEN_GTE, ">=");
            } else {
                add_token(lexer, TOKEN_GT, ">");
            }
            return;
        case '&':
            advance(lexer);
            if (current_char(lexer) == '&') {
                advance(lexer);
                add_token(lexer, TOKEN_AND, "&&");
            } else {
                add_token(lexer, TOKEN_UNKNOWN, "&");
                add_error(lexer, lexer->line, start_col,
                          "Invalid '&' operator",
                          "Use && for logical AND");
            }
            return;
        case '|':
            advance(lexer);
            if (current_char(lexer) == '|') {
                advance(lexer);
                add_token(lexer, TOKEN_OR, "||");
            } else {
                add_token(lexer, TOKEN_UNKNOWN, "|");
                add_error(lexer, lexer->line, start_col,
                          "Invalid '|' operator",
                          "Use || for logical OR");
            }
            return;
        default: {
            char unknown[2];
            unknown[0] = c;
            unknown[1] = '\0';
            add_token(lexer, TOKEN_UNKNOWN, unknown);
            add_error(lexer, lexer->line, start_col,
                      "Unknown character",
                      "This character is not valid in the supported C++ subset");
            advance(lexer);
            return;
        }
    }
}

void tokenize(Lexer* lexer) {
    while (lexer->position < (int)strlen(lexer->source)) {
        if (isspace((unsigned char)current_char(lexer))) {
            skip_whitespace(lexer);
            continue;
        }

        if (current_char(lexer) == '/' &&
            (peek_char(lexer) == '/' || peek_char(lexer) == '*')) {
            skip_comment(lexer);
            continue;
        }

        if (isalpha((unsigned char)current_char(lexer)) || current_char(lexer) == '_') {
            read_identifier(lexer);
            continue;
        }

        if (isdigit((unsigned char)current_char(lexer))) {
            read_number(lexer);
            continue;
        }

        if (current_char(lexer) == '"') {
            read_string(lexer);
            continue;
        }

        if (current_char(lexer) == '\'') {
            read_character(lexer);
            continue;
        }

        read_operator(lexer);
    }

    add_token(lexer, TOKEN_EOF, "EOF");
}
