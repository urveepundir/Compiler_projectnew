#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/parser.h"

static int is_type_token(TokenType type) {
    return type == TOKEN_INT || type == TOKEN_FLOAT || type == TOKEN_CHAR ||
           type == TOKEN_DOUBLE || type == TOKEN_BOOL || type == TOKEN_STRING_KW ||
           type == TOKEN_VOID;
}

static ASTNode* parse_call(Parser* parser, int require_semicolon);
static ASTNode* parse_array_access(Parser* parser, const char* array_name, int line, int column);

Parser* create_parser(Token** tokens, int token_count) {
    Parser* parser = (Parser*)malloc(sizeof(Parser));
    if (!parser) return NULL;
    parser->tokens = tokens;
    parser->token_count = token_count;
    parser->position = 0;
    parser->error_capacity = 50;
    parser->error_count = 0;
    parser->errors = (char**)malloc(sizeof(char*) * parser->error_capacity);
    return parser;
}

void free_parser(Parser* parser) {
    if (!parser) return;
    for (int i = 0; i < parser->error_count; i++) {
        if (parser->errors[i]) free(parser->errors[i]);
    }
    if (parser->errors) free(parser->errors);
    free(parser);
}

Token* current_token(Parser* parser) {
    if (parser->position < parser->token_count) return parser->tokens[parser->position];
    return NULL;
}

Token* peek_token(Parser* parser, int offset) {
    if (parser->position + offset < parser->token_count) {
        return parser->tokens[parser->position + offset];
    }
    return NULL;
}

void advance_parser(Parser* parser) {
    if (parser->position < parser->token_count) parser->position++;
}

int match(Parser* parser, TokenType type) {
    Token* token = current_token(parser);
    if (token && token->type == type) {
        advance_parser(parser);
        return 1;
    }
    return 0;
}

int expect(Parser* parser, TokenType type, const char* error_msg) {
    Token* token = current_token(parser);
    if (token && token->type == type) {
        advance_parser(parser);
        return 1;
    }
    add_parser_error(parser, error_msg, token ? token->line : 0, token ? token->column : 0);
    return 0;
}

void add_parser_error(Parser* parser, const char* message, int line, int column) {
    if (parser->error_count >= parser->error_capacity) {
        parser->error_capacity *= 2;
        parser->errors = (char**)realloc(parser->errors, sizeof(char*) * parser->error_capacity);
    }
    char error_msg[512];
    snprintf(error_msg, sizeof(error_msg),
             "{\"line\":%d,\"column\":%d,\"message\":\"%s\",\"type\":\"syntax\"}",
             line, column, message);
    parser->errors[parser->error_count++] = strdup(error_msg);
}

ASTNode* create_ast_node(NodeType type, const char* value, const char* data_type, int line, int column) {
    ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
    if (!node) return NULL;
    node->type = type;
    node->value = value ? strdup(value) : NULL;
    node->data_type = data_type ? strdup(data_type) : NULL;
    node->children = NULL;
    node->child_count = 0;
    node->line = line;
    node->column = column;
    return node;
}

void add_child(ASTNode* parent, ASTNode* child) {
    if (!parent || !child) return;
    parent->child_count++;
    parent->children = (ASTNode**)realloc(parent->children, sizeof(ASTNode*) * parent->child_count);
    parent->children[parent->child_count - 1] = child;
}

void print_ast(ASTNode* node, int level) {
    if (!node) return;
    for (int i = 0; i < level; i++) printf("  ");
    printf("NODE(%d", node->type);
    if (node->value) printf(", %s", node->value);
    if (node->data_type) printf(", type=%s", node->data_type);
    printf(")\n");
    for (int i = 0; i < node->child_count; i++) print_ast(node->children[i], level + 1);
}

void free_ast(ASTNode* node) {
    if (!node) return;
    for (int i = 0; i < node->child_count; i++) free_ast(node->children[i]);
    if (node->children) free(node->children);
    if (node->value) free(node->value);
    if (node->data_type) free(node->data_type);
    free(node);
}

ASTNode* parse_program(Parser* parser) {
    ASTNode* program = create_ast_node(NODE_PROGRAM, NULL, NULL, 0, 0);
    while (current_token(parser) && current_token(parser)->type != TOKEN_EOF) {
        ASTNode* function = parse_function(parser);
        if (function) add_child(program, function);
        else if (current_token(parser) && current_token(parser)->type != TOKEN_EOF) {
            add_parser_error(parser, "Expected function definition", current_token(parser)->line, current_token(parser)->column);
            advance_parser(parser);
        }
    }
    return program;
}

ASTNode* parse_function(Parser* parser) {
    Token* token = current_token(parser);
    if (!token || !is_type_token(token->type)) return NULL;

    char return_type[32];
    strcpy(return_type, token->value);
    advance_parser(parser);

    token = current_token(parser);
    if (!token || token->type != TOKEN_IDENTIFIER) {
        add_parser_error(parser, "Expected function name", token ? token->line : 0, token ? token->column : 0);
        return NULL;
    }

    char function_name[128];
    strcpy(function_name, token->value);
    int function_line = token->line;
    int function_column = token->column;
    advance_parser(parser);

    if (!expect(parser, TOKEN_LPAREN, "Expected '(' after function name")) return NULL;

    ASTNode* function = create_ast_node(NODE_FUNCTION, function_name, return_type, function_line, function_column);

    while (current_token(parser) && current_token(parser)->type != TOKEN_RPAREN) {
        Token* param_type = current_token(parser);
        if (!param_type || !is_type_token(param_type->type) || param_type->type == TOKEN_VOID) {
            add_parser_error(parser, "Expected parameter type", param_type ? param_type->line : 0, param_type ? param_type->column : 0);
            free_ast(function);
            return NULL;
        }

        char type_name[32];
        strcpy(type_name, param_type->value);
        advance_parser(parser);

        Token* param_name = current_token(parser);
        if (!param_name || param_name->type != TOKEN_IDENTIFIER) {
            add_parser_error(parser, "Expected parameter name", param_name ? param_name->line : 0, param_name ? param_name->column : 0);
            free_ast(function);
            return NULL;
        }

        add_child(function, create_ast_node(NODE_VAR_DECL, param_name->value, type_name, param_name->line, param_name->column));
        advance_parser(parser);
        if (!match(parser, TOKEN_COMMA)) break;
    }

    if (!expect(parser, TOKEN_RPAREN, "Expected ')' after parameters")) {
        free_ast(function);
        return NULL;
    }

    ASTNode* body = parse_block(parser);
    if (!body) {
        add_parser_error(parser, "Expected function body", function_line, function_column);
        free_ast(function);
        return NULL;
    }

    add_child(function, body);
    return function;
}

ASTNode* parse_block(Parser* parser) {
    Token* token = current_token(parser);
    if (!token || token->type != TOKEN_LBRACE) {
        add_parser_error(parser, "Expected '{' to start block", token ? token->line : 0, token ? token->column : 0);
        return NULL;
    }

    advance_parser(parser);
    ASTNode* block = create_ast_node(NODE_BLOCK, NULL, NULL, token->line, token->column);

    while (current_token(parser) && current_token(parser)->type != TOKEN_RBRACE) {
        ASTNode* statement = parse_statement(parser);
        if (statement) add_child(block, statement);
        else if (current_token(parser) && current_token(parser)->type != TOKEN_RBRACE) advance_parser(parser);
    }

    if (!expect(parser, TOKEN_RBRACE, "Expected '}' to end block")) {
        free_ast(block);
        return NULL;
    }

    return block;
}

ASTNode* parse_statement(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;

    switch (token->type) {
        case TOKEN_INT:
        case TOKEN_FLOAT:
        case TOKEN_CHAR:
        case TOKEN_DOUBLE:
        case TOKEN_BOOL:
        case TOKEN_STRING_KW:
            return parse_var_decl(parser);
        case TOKEN_IF:
            return parse_if_statement(parser);
        case TOKEN_RETURN:
            return parse_return_statement(parser);
        case TOKEN_IDENTIFIER:
            if (peek_token(parser, 1) && peek_token(parser, 1)->type == TOKEN_LPAREN) return parse_function_call_statement(parser);
            if (peek_token(parser, 1) && (peek_token(parser, 1)->type == TOKEN_ASSIGN || peek_token(parser, 1)->type == TOKEN_LBRACKET)) return parse_assignment(parser);
            add_parser_error(parser, "Unexpected identifier statement", token->line, token->column);
            return NULL;
        case TOKEN_LBRACE:
            return parse_block(parser);
        default:
            add_parser_error(parser, "Unexpected token", token->line, token->column);
            return NULL;
    }
}

ASTNode* parse_var_decl(Parser* parser) {
    Token* token = current_token(parser);
    if (!token || !is_type_token(token->type) || token->type == TOKEN_VOID) return NULL;

    char type_name[32];
    strcpy(type_name, token->value);
    advance_parser(parser);

    token = current_token(parser);
    if (!token || token->type != TOKEN_IDENTIFIER) {
        add_parser_error(parser, "Expected variable name", token ? token->line : 0, token ? token->column : 0);
        return NULL;
    }

    char variable_name[128];
    strcpy(variable_name, token->value);
    int line = token->line;
    int column = token->column;
    advance_parser(parser);

    int is_array = 0;
    int array_size = 0;
    if (current_token(parser) && current_token(parser)->type == TOKEN_LBRACKET) {
        is_array = 1;
        advance_parser(parser);
        token = current_token(parser);
        if (token && token->type == TOKEN_INTEGER) {
            array_size = atoi(token->value);
            advance_parser(parser);
        } else {
            add_parser_error(parser, "Expected array size", token ? token->line : 0, token ? token->column : 0);
        }
        if (!expect(parser, TOKEN_RBRACKET, "Expected ']' after array size")) return NULL;
    }

    ASTNode* declaration = create_ast_node(is_array ? NODE_ARRAY_DECL : NODE_VAR_DECL, variable_name, type_name, line, column);
    if (is_array) {
        char size_str[16];
        snprintf(size_str, sizeof(size_str), "%d", array_size);
        add_child(declaration, create_ast_node(NODE_INTEGER, size_str, "int", line, column));
    }

    if (current_token(parser) && current_token(parser)->type == TOKEN_ASSIGN) {
        advance_parser(parser);
        ASTNode* initializer = parse_expression(parser);
        if (!initializer) {
            add_parser_error(parser, "Expected initializer expression", line, column);
            free_ast(declaration);
            return NULL;
        }
        add_child(declaration, initializer);
    }

    if (!expect(parser, TOKEN_SEMICOLON, "Expected ';' after variable declaration")) {
        free_ast(declaration);
        return NULL;
    }

    return declaration;
}

static ASTNode* parse_array_access(Parser* parser, const char* array_name, int line, int column) {
    if (!expect(parser, TOKEN_LBRACKET, "Expected '[' for array access")) return NULL;
    ASTNode* index = parse_expression(parser);
    if (!index) {
        add_parser_error(parser, "Expected array index", line, column);
        return NULL;
    }
    if (!expect(parser, TOKEN_RBRACKET, "Expected ']' after array index")) {
        free_ast(index);
        return NULL;
    }
    ASTNode* access = create_ast_node(NODE_ARRAY_ACCESS, array_name, NULL, line, column);
    add_child(access, index);
    return access;
}

ASTNode* parse_assignment(Parser* parser) {
    Token* token = current_token(parser);
    if (!token || token->type != TOKEN_IDENTIFIER) return NULL;

    char name[128];
    strcpy(name, token->value);
    int line = token->line;
    int column = token->column;
    advance_parser(parser);

    ASTNode* left = NULL;
    if (current_token(parser) && current_token(parser)->type == TOKEN_LBRACKET) left = parse_array_access(parser, name, line, column);
    else left = create_ast_node(NODE_IDENTIFIER, name, NULL, line, column);
    if (!left) return NULL;

    if (!expect(parser, TOKEN_ASSIGN, "Expected '=' in assignment")) {
        free_ast(left);
        return NULL;
    }

    ASTNode* right = parse_expression(parser);
    if (!right) {
        free_ast(left);
        return NULL;
    }

    if (!expect(parser, TOKEN_SEMICOLON, "Expected ';' after assignment")) {
        free_ast(left);
        free_ast(right);
        return NULL;
    }

    ASTNode* assignment = create_ast_node(NODE_ASSIGN, NULL, NULL, line, column);
    add_child(assignment, left);
    add_child(assignment, right);
    return assignment;
}

static ASTNode* parse_call(Parser* parser, int require_semicolon) {
    Token* token = current_token(parser);
    if (!token || token->type != TOKEN_IDENTIFIER) return NULL;

    char function_name[128];
    strcpy(function_name, token->value);
    int line = token->line;
    int column = token->column;
    advance_parser(parser);

    if (!expect(parser, TOKEN_LPAREN, "Expected '(' after function name")) return NULL;

    ASTNode* call = create_ast_node(NODE_FUNCTION_CALL, function_name, NULL, line, column);
    while (current_token(parser) && current_token(parser)->type != TOKEN_RPAREN) {
        ASTNode* arg = parse_expression(parser);
        if (!arg) {
            free_ast(call);
            return NULL;
        }
        add_child(call, arg);
        if (!match(parser, TOKEN_COMMA)) break;
    }

    if (!expect(parser, TOKEN_RPAREN, "Expected ')' after arguments")) {
        free_ast(call);
        return NULL;
    }

    if (require_semicolon && !expect(parser, TOKEN_SEMICOLON, "Expected ';' after function call")) {
        free_ast(call);
        return NULL;
    }

    return call;
}

ASTNode* parse_function_call_statement(Parser* parser) {
    return parse_call(parser, 1);
}

ASTNode* parse_if_statement(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    advance_parser(parser);

    if (!expect(parser, TOKEN_LPAREN, "Expected '(' after if")) return NULL;
    ASTNode* condition = parse_expression(parser);
    if (!condition) return NULL;
    if (!expect(parser, TOKEN_RPAREN, "Expected ')' after condition")) {
        free_ast(condition);
        return NULL;
    }

    ASTNode* then_branch = parse_statement(parser);
    if (!then_branch) {
        free_ast(condition);
        return NULL;
    }

    ASTNode* if_node = create_ast_node(NODE_IF_STMT, NULL, NULL, token->line, token->column);
    add_child(if_node, condition);
    add_child(if_node, then_branch);

    if (current_token(parser) && current_token(parser)->type == TOKEN_ELSE) {
        advance_parser(parser);
        ASTNode* else_branch = parse_statement(parser);
        if (else_branch) add_child(if_node, else_branch);
    }

    return if_node;
}

ASTNode* parse_return_statement(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;
    advance_parser(parser);

    ASTNode* expr = NULL;
    if (current_token(parser) && current_token(parser)->type != TOKEN_SEMICOLON) expr = parse_expression(parser);

    if (!expect(parser, TOKEN_SEMICOLON, "Expected ';' after return")) {
        if (expr) free_ast(expr);
        return NULL;
    }

    ASTNode* statement = create_ast_node(NODE_RETURN_STMT, NULL, NULL, token->line, token->column);
    if (expr) add_child(statement, expr);
    return statement;
}

ASTNode* parse_expression(Parser* parser) {
    return parse_comparison(parser);
}

ASTNode* parse_comparison(Parser* parser) {
    ASTNode* left = parse_addition(parser);
    if (!left) return NULL;

    Token* token = current_token(parser);
    if (token && (token->type == TOKEN_GT || token->type == TOKEN_LT || token->type == TOKEN_EQ ||
                  token->type == TOKEN_NEQ || token->type == TOKEN_GTE || token->type == TOKEN_LTE ||
                  token->type == TOKEN_ASSIGN)) {
        char op[3];
        strcpy(op, token->value);
        int line = token->line;
        int column = token->column;
        advance_parser(parser);

        ASTNode* right = parse_addition(parser);
        if (!right) {
            free_ast(left);
            return NULL;
        }

        ASTNode* binop = create_ast_node(NODE_BINARY_OP, op, NULL, line, column);
        add_child(binop, left);
        add_child(binop, right);
        return binop;
    }

    return left;
}

ASTNode* parse_addition(Parser* parser) {
    ASTNode* left = parse_multiplication(parser);
    if (!left) return NULL;

    while (1) {
        Token* token = current_token(parser);
        if (!token || (token->type != TOKEN_PLUS && token->type != TOKEN_MINUS)) break;

        char op[2];
        strcpy(op, token->value);
        int line = token->line;
        int column = token->column;
        advance_parser(parser);

        ASTNode* right = parse_multiplication(parser);
        if (!right) {
            free_ast(left);
            return NULL;
        }

        ASTNode* binop = create_ast_node(NODE_BINARY_OP, op, NULL, line, column);
        add_child(binop, left);
        add_child(binop, right);
        left = binop;
    }

    return left;
}

ASTNode* parse_multiplication(Parser* parser) {
    ASTNode* left = parse_primary(parser);
    if (!left) return NULL;

    while (1) {
        Token* token = current_token(parser);
        if (!token || (token->type != TOKEN_MUL && token->type != TOKEN_DIV && token->type != TOKEN_MOD)) break;

        char op[2];
        strcpy(op, token->value);
        int line = token->line;
        int column = token->column;
        advance_parser(parser);

        ASTNode* right = parse_primary(parser);
        if (!right) {
            free_ast(left);
            return NULL;
        }

        ASTNode* binop = create_ast_node(NODE_BINARY_OP, op, NULL, line, column);
        add_child(binop, left);
        add_child(binop, right);
        left = binop;
    }

    return left;
}

ASTNode* parse_primary(Parser* parser) {
    Token* token = current_token(parser);
    if (!token) return NULL;

    if (token->type == TOKEN_INTEGER) {
        ASTNode* node = create_ast_node(NODE_INTEGER, token->value, "int", token->line, token->column);
        advance_parser(parser);
        return node;
    }
    if (token->type == TOKEN_FLOAT_LIT) {
        ASTNode* node = create_ast_node(NODE_FLOAT_LIT, token->value, "double", token->line, token->column);
        advance_parser(parser);
        return node;
    }
    if (token->type == TOKEN_CHAR_LIT) {
        ASTNode* node = create_ast_node(NODE_CHAR_LIT, token->value, "char", token->line, token->column);
        advance_parser(parser);
        return node;
    }
    if (token->type == TOKEN_STRING) {
        ASTNode* node = create_ast_node(NODE_STRING, token->value, "string", token->line, token->column);
        advance_parser(parser);
        return node;
    }
    if (token->type == TOKEN_TRUE || token->type == TOKEN_FALSE) {
        ASTNode* node = create_ast_node(NODE_BOOL_LIT, token->value, "bool", token->line, token->column);
        advance_parser(parser);
        return node;
    }
    if (token->type == TOKEN_IDENTIFIER) {
        if (peek_token(parser, 1) && peek_token(parser, 1)->type == TOKEN_LPAREN) return parse_call(parser, 0);

        char name[128];
        strcpy(name, token->value);
        int line = token->line;
        int column = token->column;
        advance_parser(parser);

        if (current_token(parser) && current_token(parser)->type == TOKEN_LBRACKET) return parse_array_access(parser, name, line, column);
        return create_ast_node(NODE_IDENTIFIER, name, NULL, line, column);
    }
    if (token->type == TOKEN_MINUS) {
        advance_parser(parser);
        ASTNode* expr = parse_primary(parser);
        if (!expr) return NULL;
        ASTNode* node = create_ast_node(NODE_BINARY_OP, "-", NULL, token->line, token->column);
        add_child(node, create_ast_node(NODE_INTEGER, "0", "int", token->line, token->column));
        add_child(node, expr);
        return node;
    }
    if (token->type == TOKEN_LPAREN) {
        advance_parser(parser);
        ASTNode* expr = parse_expression(parser);
        if (!expect(parser, TOKEN_RPAREN, "Expected ')' after expression")) {
            if (expr) free_ast(expr);
            return NULL;
        }
        return expr;
    }

    add_parser_error(parser, "Expected expression", token->line, token->column);
    return NULL;
}

ASTNode* parse(Parser* parser) {
    return parse_program(parser);
}
