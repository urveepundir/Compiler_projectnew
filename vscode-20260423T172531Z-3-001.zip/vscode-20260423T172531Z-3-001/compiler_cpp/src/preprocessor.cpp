#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "../include/preprocessor.h"

static void append_text(char** buffer, size_t* length, size_t* capacity, const char* text) {
    size_t text_len = strlen(text);
    if (*length + text_len + 1 > *capacity) {
        while (*length + text_len + 1 > *capacity) *capacity *= 2;
        *buffer = (char*)realloc(*buffer, *capacity);
    }
    memcpy(*buffer + *length, text, text_len);
    *length += text_len;
    (*buffer)[*length] = '\0';
}

static char* trim_copy(const char* line) {
    while (*line && isspace((unsigned char)*line)) line++;
    size_t len = strlen(line);
    while (len > 0 && isspace((unsigned char)line[len - 1])) len--;
    char* trimmed = (char*)malloc(len + 1);
    strncpy(trimmed, line, len);
    trimmed[len] = '\0';
    return trimmed;
}

static char* replace_all(const char* source, const char* target, const char* replacement) {
    size_t source_len = strlen(source);
    size_t capacity = source_len + 1;
    char* result = (char*)malloc(capacity);
    size_t length = 0;
    result[0] = '\0';

    const char* cursor = source;
    size_t target_len = strlen(target);
    while (*cursor) {
        const char* match = strstr(cursor, target);
        if (!match) {
            append_text(&result, &length, &capacity, cursor);
            break;
        }

        size_t chunk_len = (size_t)(match - cursor);
        char* chunk = (char*)malloc(chunk_len + 1);
        strncpy(chunk, cursor, chunk_len);
        chunk[chunk_len] = '\0';
        append_text(&result, &length, &capacity, chunk);
        append_text(&result, &length, &capacity, replacement);
        free(chunk);
        cursor = match + target_len;
    }

    return result;
}

static char* normalize_stream_line(const char* line) {
    const char* cout_pos = strstr(line, "cout");
    const char* cin_pos = strstr(line, "cin");
    const char* base = NULL;
    const char* op = NULL;
    const char* name = NULL;

    if (cout_pos && strstr(cout_pos, "<<")) {
        base = cout_pos;
        op = "<<";
        name = "cout";
    } else if (cin_pos && strstr(cin_pos, ">>")) {
        base = cin_pos;
        op = ">>";
        name = "cin";
    } else {
        return strdup(line);
    }

    if (base != line && !isspace((unsigned char)base[-1])) return strdup(line);

    size_t indent_len = (size_t)(base - line);
    char* indent = (char*)malloc(indent_len + 1);
    strncpy(indent, line, indent_len);
    indent[indent_len] = '\0';

    const char* cursor = base + strlen(name);
    while (*cursor && isspace((unsigned char)*cursor)) cursor++;
    if (strncmp(cursor, op, 2) != 0) {
        free(indent);
        return strdup(line);
    }
    cursor += 2;

    size_t capacity = strlen(line) + 16;
    char* normalized = (char*)malloc(capacity);
    size_t length = 0;
    normalized[0] = '\0';

    append_text(&normalized, &length, &capacity, indent);
    append_text(&normalized, &length, &capacity, name);
    append_text(&normalized, &length, &capacity, "(");

    int first_arg = 1;
    int depth = 0;
    int in_string = 0;
    int in_char = 0;
    int escaped = 0;
    const char* segment_start = cursor;
    const char* suffix_start = NULL;

    while (*cursor) {
        if (!in_string && !in_char && *cursor == ';' && depth == 0) {
            size_t segment_len = (size_t)(cursor - segment_start);
            char* segment = (char*)malloc(segment_len + 1);
            strncpy(segment, segment_start, segment_len);
            segment[segment_len] = '\0';
            char* trimmed = trim_copy(segment);
            if (trimmed[0] != '\0') {
                if (!first_arg) append_text(&normalized, &length, &capacity, ", ");
                append_text(&normalized, &length, &capacity, trimmed);
                first_arg = 0;
            }
            free(trimmed);
            free(segment);
            suffix_start = cursor + 1;
            break;
        }

        if (escaped) escaped = 0;
        else if (*cursor == '\\') escaped = 1;
        else if (!in_char && *cursor == '"') in_string = !in_string;
        else if (!in_string && *cursor == '\'') in_char = !in_char;
        else if (!in_string && !in_char) {
            if (*cursor == '(' || *cursor == '[' || *cursor == '{') depth++;
            if (*cursor == ')' || *cursor == ']' || *cursor == '}') depth--;
            if (depth == 0 && strncmp(cursor, op, 2) == 0) {
                size_t segment_len = (size_t)(cursor - segment_start);
                char* segment = (char*)malloc(segment_len + 1);
                strncpy(segment, segment_start, segment_len);
                segment[segment_len] = '\0';
                char* trimmed = trim_copy(segment);
                if (trimmed[0] != '\0') {
                    if (!first_arg) append_text(&normalized, &length, &capacity, ", ");
                    append_text(&normalized, &length, &capacity, trimmed);
                    first_arg = 0;
                }
                free(trimmed);
                free(segment);
                cursor += 2;
                segment_start = cursor;
                while (*segment_start && isspace((unsigned char)*segment_start)) segment_start++;
                cursor = segment_start;
                continue;
            }
        }
        cursor++;
    }

    append_text(&normalized, &length, &capacity, ");");
    if (suffix_start && *suffix_start) append_text(&normalized, &length, &capacity, suffix_start);
    free(indent);
    return normalized;
}

Preprocessor* create_preprocessor() {
    Preprocessor* pp = (Preprocessor*)malloc(sizeof(Preprocessor));
    if (!pp) return NULL;
    pp->macros = NULL;
    pp->includes = NULL;
    pp->include_count = 0;
    pp->errors = NULL;
    pp->error_count = 0;
    return pp;
}

void free_preprocessor(Preprocessor* pp) {
    if (!pp) return;

    Macro* macro = pp->macros;
    while (macro) {
        Macro* next = macro->next;
        if (macro->name) free(macro->name);
        if (macro->value) free(macro->value);
        free(macro);
        macro = next;
    }

    for (int i = 0; i < pp->include_count; i++) {
        if (pp->includes[i]) free(pp->includes[i]);
    }
    if (pp->includes) free(pp->includes);

    if (pp->errors) {
        for (int i = 0; i < pp->error_count; i++) {
            if (pp->errors[i]) free(pp->errors[i]);
        }
        free(pp->errors);
    }

    free(pp);
}

void add_macro(Preprocessor* pp, const char* name, const char* value) {
    Macro* macro = (Macro*)malloc(sizeof(Macro));
    macro->name = strdup(name);
    macro->value = value ? strdup(value) : strdup("");
    macro->next = pp->macros;
    pp->macros = macro;
}

char* expand_macros(Preprocessor* pp, const char* line) {
    char* result = strdup(line);
    Macro* macro = pp->macros;
    while (macro) {
        char* next = replace_all(result, macro->name, macro->value);
        free(result);
        result = next;
        macro = macro->next;
    }
    return result;
}

char* preprocess(Preprocessor* pp, const char* source) {
    if (!source) return NULL;

    size_t capacity = strlen(source) + 1;
    char* raw = (char*)malloc(capacity);
    size_t length = 0;
    raw[0] = '\0';

    const char* src = source;
    while (*src) {
        if (*src == '/' && *(src + 1) == '/') {
            while (*src && *src != '\n') src++;
            if (*src == '\n') {
                append_text(&raw, &length, &capacity, "\n");
                src++;
            }
            continue;
        }

        if (*src == '/' && *(src + 1) == '*') {
            src += 2;
            while (*src && !(*src == '*' && *(src + 1) == '/')) src++;
            if (*src) src += 2;
            continue;
        }

        if (*src == '#') {
            const char* start = src;
            while (*src && *src != '\n') src++;
            size_t directive_len = (size_t)(src - start);
            char* directive = (char*)malloc(directive_len + 1);
            strncpy(directive, start, directive_len);
            directive[directive_len] = '\0';

            if (strstr(directive, "#define")) {
                char* name = strchr(directive, ' ');
                if (name) {
                    name++;
                    char* value = strchr(name, ' ');
                    if (value) {
                        *value++ = '\0';
                        add_macro(pp, name, value);
                    } else {
                        add_macro(pp, name, "");
                    }
                }
            } else if (strstr(directive, "#include")) {
                char* filename = strchr(directive, '<');
                if (!filename) filename = strchr(directive, '"');
                if (filename) {
                    filename++;
                    char* end = strchr(filename, '>');
                    if (!end) end = strchr(filename, '"');
                    if (end) {
                        *end = '\0';
                        pp->includes = (char**)realloc(pp->includes, sizeof(char*) * (pp->include_count + 1));
                        pp->includes[pp->include_count++] = strdup(filename);
                    }
                }
            }

            free(directive);
            if (*src == '\n') {
                append_text(&raw, &length, &capacity, "\n");
                src++;
            }
            continue;
        }

        char ch[2];
        ch[0] = *src;
        ch[1] = '\0';
        append_text(&raw, &length, &capacity, ch);
        src++;
    }

    char* expanded = expand_macros(pp, raw);
    free(raw);
    char* without_std = replace_all(expanded, "std::", "");
    free(expanded);

    size_t final_capacity = strlen(without_std) + 32;
    char* final_output = (char*)malloc(final_capacity);
    size_t final_length = 0;
    final_output[0] = '\0';

    const char* cursor = without_std;
    while (*cursor) {
        const char* line_end = strchr(cursor, '\n');
        size_t line_len = line_end ? (size_t)(line_end - cursor) : strlen(cursor);
        char* line = (char*)malloc(line_len + 1);
        strncpy(line, cursor, line_len);
        line[line_len] = '\0';

        char* trimmed = trim_copy(line);
        if (strncmp(trimmed, "using namespace ", 16) != 0) {
            char* normalized = normalize_stream_line(line);
            append_text(&final_output, &final_length, &final_capacity, normalized);
            if (line_end) append_text(&final_output, &final_length, &final_capacity, "\n");
            free(normalized);
        } else if (line_end) {
            append_text(&final_output, &final_length, &final_capacity, "\n");
        }

        free(trimmed);
        free(line);
        if (!line_end) break;
        cursor = line_end + 1;
    }

    free(without_std);
    return final_output;
}
