#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/semantic.h"

static unsigned int hash_name(const char* str, int table_size) {
    unsigned int hash = 0;
    while (*str) hash = hash * 31 + (unsigned char)(*str++);
    return hash % table_size;
}

static int is_numeric_type(const char* type) {
    return strcmp(type, "int") == 0 || strcmp(type, "float") == 0 ||
           strcmp(type, "double") == 0 || strcmp(type, "char") == 0 ||
           strcmp(type, "bool") == 0;
}

SemanticAnalyzer* create_semantic_analyzer() {
    SemanticAnalyzer* sa = (SemanticAnalyzer*)malloc(sizeof(SemanticAnalyzer));
    if (!sa) return NULL;
    sa->table = (SymbolTable*)malloc(sizeof(SymbolTable));
    sa->table->size = 211;
    sa->table->count = 0;
    sa->table->buckets = (Symbol**)calloc(sa->table->size, sizeof(Symbol*));
    sa->error_capacity = 50;
    sa->error_count = 0;
    sa->errors = (char**)malloc(sizeof(char*) * sa->error_capacity);
    sa->current_function = NULL;
    sa->current_function_type = NULL;
    return sa;
}

void free_semantic_analyzer(SemanticAnalyzer* sa) {
    if (!sa) return;

    if (sa->table) {
        for (int i = 0; i < sa->table->size; i++) {
            Symbol* sym = sa->table->buckets[i];
            while (sym) {
                Symbol* next = sym->next;
                if (sym->name) free(sym->name);
                if (sym->type) free(sym->type);
                free(sym);
                sym = next;
            }
        }
        free(sa->table->buckets);
        free(sa->table);
    }

    for (int i = 0; i < sa->error_count; i++) {
        if (sa->errors[i]) free(sa->errors[i]);
    }
    free(sa->errors);

    if (sa->current_function) free(sa->current_function);
    if (sa->current_function_type) free(sa->current_function_type);
    free(sa);
}

void add_semantic_error(SemanticAnalyzer* sa, const char* message, int line, int column) {
    if (sa->error_count >= sa->error_capacity) {
        sa->error_capacity *= 2;
        sa->errors = (char**)realloc(sa->errors, sizeof(char*) * sa->error_capacity);
    }

    char error_msg[512];
    snprintf(error_msg, sizeof(error_msg),
             "{\"line\":%d,\"column\":%d,\"message\":\"%s\",\"type\":\"semantic\"}",
             line, column, message);
    sa->errors[sa->error_count++] = strdup(error_msg);
}

void add_symbol(SemanticAnalyzer* sa, const char* name, const char* type, int line, int is_initialized) {
    if (!sa || !name || !type) return;
    Symbol* existing = lookup_symbol(sa, name);
    if (existing) {
        char message[256];
        snprintf(message, sizeof(message), "Redeclaration of '%s'", name);
        add_semantic_error(sa, message, line, 0);
        return;
    }

    Symbol* sym = (Symbol*)malloc(sizeof(Symbol));
    sym->name = strdup(name);
    sym->type = strdup(type);
    sym->line_declared = line;
    sym->is_initialized = is_initialized;
    sym->is_array = 0;
    sym->array_size = 0;
    sym->next = NULL;

    unsigned int index = hash_name(name, sa->table->size);
    sym->next = sa->table->buckets[index];
    sa->table->buckets[index] = sym;
    sa->table->count++;
}

void add_array_symbol(SemanticAnalyzer* sa, const char* name, const char* type, int line, int size) {
    if (!sa || !name || !type) return;
    Symbol* existing = lookup_symbol(sa, name);
    if (existing) {
        char message[256];
        snprintf(message, sizeof(message), "Redeclaration of array '%s'", name);
        add_semantic_error(sa, message, line, 0);
        return;
    }

    Symbol* sym = (Symbol*)malloc(sizeof(Symbol));
    sym->name = strdup(name);
    sym->type = strdup(type);
    sym->line_declared = line;
    sym->is_initialized = 1;
    sym->is_array = 1;
    sym->array_size = size;
    sym->next = NULL;

    unsigned int index = hash_name(name, sa->table->size);
    sym->next = sa->table->buckets[index];
    sa->table->buckets[index] = sym;
    sa->table->count++;
}

Symbol* lookup_symbol(SemanticAnalyzer* sa, const char* name) {
    if (!sa || !name) return NULL;
    unsigned int index = hash_name(name, sa->table->size);
    Symbol* sym = sa->table->buckets[index];
    while (sym) {
        if (strcmp(sym->name, name) == 0) return sym;
        sym = sym->next;
    }
    return NULL;
}

const char* get_expression_type(SemanticAnalyzer* sa, ASTNode* node) {
    if (!node) return "unknown";

    switch (node->type) {
        case NODE_INTEGER:
            return "int";
        case NODE_FLOAT_LIT:
            return "double";
        case NODE_CHAR_LIT:
            return "char";
        case NODE_STRING:
            return "string";
        case NODE_BOOL_LIT:
            return "bool";
        case NODE_IDENTIFIER:
        case NODE_ARRAY_ACCESS: {
            Symbol* sym = lookup_symbol(sa, node->value);
            return sym ? sym->type : "unknown";
        }
        case NODE_FUNCTION_CALL:
            if (node->value && strcmp(node->value, "cin") == 0) return "void";
            if (node->value && strcmp(node->value, "cout") == 0) return "void";
            return "unknown";
        case NODE_BINARY_OP:
            if (!node->value || node->child_count < 2) return "unknown";
            if (strcmp(node->value, "==") == 0 || strcmp(node->value, "!=") == 0 ||
                strcmp(node->value, "<") == 0 || strcmp(node->value, "<=") == 0 ||
                strcmp(node->value, ">") == 0 || strcmp(node->value, ">=") == 0) {
                return "bool";
            }
            if (strcmp(node->value, "=") == 0) return get_expression_type(sa, node->children[1]);
            {
                const char* left = get_expression_type(sa, node->children[0]);
                const char* right = get_expression_type(sa, node->children[1]);
                if (strcmp(left, "string") == 0 || strcmp(right, "string") == 0) return "string";
                if (strcmp(left, "double") == 0 || strcmp(right, "double") == 0 ||
                    strcmp(left, "float") == 0 || strcmp(right, "float") == 0) return "double";
                return "int";
            }
        default:
            return "unknown";
    }
}

int check_type_compatibility(const char* expected, const char* actual) {
    if (!expected || !actual) return 0;
    if (strcmp(expected, "unknown") == 0 || strcmp(actual, "unknown") == 0) return 1;
    if (strcmp(expected, actual) == 0) return 1;
    if (is_numeric_type(expected) && is_numeric_type(actual)) return 1;
    return 0;
}

void analyze_ast(SemanticAnalyzer* sa, ASTNode* node) {
    if (!sa || !node) return;

    switch (node->type) {
        case NODE_PROGRAM:
        case NODE_BLOCK:
            for (int i = 0; i < node->child_count; i++) analyze_ast(sa, node->children[i]);
            break;

        case NODE_FUNCTION:
            if (sa->current_function) free(sa->current_function);
            if (sa->current_function_type) free(sa->current_function_type);
            sa->current_function = node->value ? strdup(node->value) : strdup("main");
            sa->current_function_type = node->data_type ? strdup(node->data_type) : strdup("void");
            for (int i = 0; i < node->child_count; i++) analyze_ast(sa, node->children[i]);
            break;

        case NODE_VAR_DECL: {
            const char* var_type = node->data_type ? node->data_type : "int";
            int is_initialized = node->child_count > 0;
            add_symbol(sa, node->value, var_type, node->line, is_initialized);
            if (is_initialized) {
                analyze_ast(sa, node->children[0]);
                const char* init_type = get_expression_type(sa, node->children[0]);
                if (!check_type_compatibility(var_type, init_type)) {
                    char message[256];
                    snprintf(message, sizeof(message), "Type mismatch: cannot initialize '%s' with '%s'", var_type, init_type);
                    add_semantic_error(sa, message, node->line, node->column);
                }
            }
            break;
        }

        case NODE_ARRAY_DECL: {
            const char* array_type = node->data_type ? node->data_type : "int";
            int size = 0;
            int initializer_index = 1;
            if (node->child_count > 0 && node->children[0]->type == NODE_INTEGER) size = atoi(node->children[0]->value);
            else initializer_index = 0;

            add_array_symbol(sa, node->value, array_type, node->line, size);
            if (size <= 0) add_semantic_error(sa, "Array size should be greater than zero", node->line, node->column);
            if (node->child_count > initializer_index) analyze_ast(sa, node->children[initializer_index]);
            break;
        }

        case NODE_ARRAY_ACCESS: {
            Symbol* sym = lookup_symbol(sa, node->value);
            if (!sym) {
                char message[256];
                snprintf(message, sizeof(message), "Array '%s' undeclared", node->value);
                add_semantic_error(sa, message, node->line, node->column);
                break;
            }
            if (!sym->is_array) {
                char message[256];
                snprintf(message, sizeof(message), "'%s' is not an array", node->value);
                add_semantic_error(sa, message, node->line, node->column);
                break;
            }
            if (node->child_count > 0) {
                analyze_ast(sa, node->children[0]);
                const char* index_type = get_expression_type(sa, node->children[0]);
                if (!check_type_compatibility("int", index_type)) {
                    add_semantic_error(sa, "Array index must be an integer expression", node->line, node->column);
                }
                if (node->children[0]->type == NODE_INTEGER) {
                    int index = atoi(node->children[0]->value);
                    if (index < 0 || (sym->array_size > 0 && index >= sym->array_size)) {
                        add_semantic_error(sa, "Array index is out of bounds", node->line, node->column);
                    }
                }
            }
            break;
        }

        case NODE_ASSIGN: {
            if (node->child_count < 2) break;
            ASTNode* left = node->children[0];
            ASTNode* right = node->children[1];
            const char* var_name = left->value;
            if (!var_name) break;

            Symbol* sym = lookup_symbol(sa, var_name);
            if (!sym) {
                char message[256];
                snprintf(message, sizeof(message), "'%s' undeclared", var_name);
                add_semantic_error(sa, message, node->line, node->column);
                break;
            }

            if (left->type == NODE_ARRAY_ACCESS) analyze_ast(sa, left);
            analyze_ast(sa, right);
            const char* right_type = get_expression_type(sa, right);
            if (!check_type_compatibility(sym->type, right_type)) {
                char message[256];
                snprintf(message, sizeof(message), "Type mismatch: assigning '%s' to '%s'", right_type, sym->type);
                add_semantic_error(sa, message, node->line, node->column);
            }
            sym->is_initialized = 1;
            break;
        }

        case NODE_IF_STMT:
            if (node->child_count > 0) {
                ASTNode* condition = node->children[0];
                if (condition->type == NODE_BINARY_OP && condition->value && strcmp(condition->value, "=") == 0) {
                    add_semantic_error(sa, "Did you mean '==' instead of '=' in the if condition?", node->line, node->column);
                }
                analyze_ast(sa, condition);
                {
                    const char* cond_type = get_expression_type(sa, condition);
                    if (strcmp(cond_type, "bool") != 0 && strcmp(cond_type, "int") != 0 &&
                        strcmp(cond_type, "char") != 0 && strcmp(cond_type, "unknown") != 0) {
                        add_semantic_error(sa, "If condition must be a boolean or numeric expression", node->line, node->column);
                    }
                }
            }
            for (int i = 1; i < node->child_count; i++) analyze_ast(sa, node->children[i]);
            break;

        case NODE_RETURN_STMT:
            if (node->child_count == 0) {
                if (sa->current_function_type && strcmp(sa->current_function_type, "void") != 0) {
                    add_semantic_error(sa, "Missing return value", node->line, node->column);
                }
                break;
            }
            analyze_ast(sa, node->children[0]);
            if (sa->current_function_type) {
                const char* return_type = get_expression_type(sa, node->children[0]);
                if (!check_type_compatibility(sa->current_function_type, return_type)) {
                    char message[256];
                    snprintf(message, sizeof(message), "Return type mismatch (expected %s, got %s)", sa->current_function_type, return_type);
                    add_semantic_error(sa, message, node->line, node->column);
                }
            }
            break;

        case NODE_BINARY_OP:
            for (int i = 0; i < node->child_count; i++) analyze_ast(sa, node->children[i]);
            if (node->value && strcmp(node->value, "/") == 0 && node->child_count >= 2) {
                ASTNode* right = node->children[1];
                if (right->type == NODE_INTEGER && atoi(right->value) == 0) {
                    add_semantic_error(sa, "Division by zero", node->line, node->column);
                }
            }
            break;

        case NODE_IDENTIFIER: {
            if (node->value && strcmp(node->value, "endl") == 0) break;
            Symbol* sym = lookup_symbol(sa, node->value);
            if (!sym) {
                char message[256];
                snprintf(message, sizeof(message), "'%s' undeclared", node->value);
                add_semantic_error(sa, message, node->line, node->column);
            } else if (!sym->is_initialized) {
                char message[256];
                snprintf(message, sizeof(message), "'%s' may be uninitialized", node->value);
                add_semantic_error(sa, message, node->line, node->column);
            }
            break;
        }

        case NODE_FUNCTION_CALL:
            if (node->value && strcmp(node->value, "cin") == 0) {
                for (int i = 0; i < node->child_count; i++) {
                    ASTNode* arg = node->children[i];
                    if (arg->type != NODE_IDENTIFIER && arg->type != NODE_ARRAY_ACCESS) {
                        add_semantic_error(sa, "cin expects variables as input targets", arg->line, arg->column);
                        continue;
                    }
                    if (arg->type == NODE_ARRAY_ACCESS) analyze_ast(sa, arg);
                    Symbol* sym = lookup_symbol(sa, arg->value);
                    if (!sym) {
                        char message[256];
                        snprintf(message, sizeof(message), "'%s' undeclared", arg->value);
                        add_semantic_error(sa, message, arg->line, arg->column);
                    } else {
                        sym->is_initialized = 1;
                    }
                }
            } else {
                for (int i = 0; i < node->child_count; i++) analyze_ast(sa, node->children[i]);
            }
            break;

        case NODE_INTEGER:
        case NODE_FLOAT_LIT:
        case NODE_CHAR_LIT:
        case NODE_STRING:
        case NODE_BOOL_LIT:
            break;
    }
}
