#include <iostream>
#include <string>
using namespace std;

int main() {
    int x = 5;
    string name = "Compiler";
    cout << name << x << endl;
    return 0;
}
