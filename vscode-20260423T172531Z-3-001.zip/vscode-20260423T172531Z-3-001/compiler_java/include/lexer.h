#ifndef JAVA_LEXER_H
#define JAVA_LEXER_H

#include <string>
#include <vector>

#include "token.h"

struct LexerResult {
    std::vector<Token> tokens;
    std::vector<CompilerError> errors;
};

LexerResult tokenize_java(const std::string& source);

#endif
