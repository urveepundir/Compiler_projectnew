#ifndef JAVA_PARSER_H
#define JAVA_PARSER_H

#include <string>
#include <vector>

#include "token.h"

struct ParserResult {
    std::vector<CompilerError> errors;
    std::string ast_status;
};

ParserResult analyze_syntax(const std::string& source, const std::vector<Token>& tokens);

#endif
