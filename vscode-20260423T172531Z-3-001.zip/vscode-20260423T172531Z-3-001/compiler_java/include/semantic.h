#ifndef JAVA_SEMANTIC_H
#define JAVA_SEMANTIC_H

#include <string>
#include <vector>

#include "token.h"

struct SemanticResult {
    std::vector<CompilerError> errors;
};

SemanticResult analyze_semantics(const std::string& source);

#endif
