#ifndef JAVA_TOKEN_H
#define JAVA_TOKEN_H

#include <string>

enum TokenType {
    TOKEN_KEYWORD,
    TOKEN_IDENTIFIER,
    TOKEN_NUMBER_LITERAL,
    TOKEN_STRING_LITERAL,
    TOKEN_CHAR_LITERAL,
    TOKEN_OPERATOR,
    TOKEN_DELIMITER,
    TOKEN_EOF
};

struct Token {
    TokenType type;
    std::string value;
    int line;
    int column;
};

struct CompilerError {
    int line;
    int column;
    std::string message;
};

const char* token_type_to_string(TokenType type);

#endif
