#include <iostream>
#include <iterator>
#include <string>
#include <vector>

#include "include/lexer.h"
#include "include/parser.h"
#include "include/semantic.h"
#include "include/token.h"

namespace {
std::string escape_json(const std::string& value) {
    std::string escaped;
    escaped.reserve(value.size());

    for (std::size_t index = 0; index < value.size(); ++index) {
        unsigned char ch = static_cast<unsigned char>(value[index]);
        switch (ch) {
            case '\\':
                escaped += "\\\\";
                break;
            case '"':
                escaped += "\\\"";
                break;
            case '\n':
                escaped += "\\n";
                break;
            case '\r':
                escaped += "\\r";
                break;
            case '\t':
                escaped += "\\t";
                break;
            default:
                escaped.push_back(static_cast<char>(ch));
                break;
        }
    }

    return escaped;
}

void print_error_list(const std::vector<CompilerError>& errors, const std::string& name) {
    std::cout << "  \"" << name << "\": [\n";
    for (std::size_t index = 0; index < errors.size(); ++index) {
        const CompilerError& error = errors[index];
        std::cout << "    {\"line\":" << error.line
                  << ",\"message\":\"" << escape_json(error.message) << "\"";
        if (error.column > 0) {
            std::cout << ",\"col\":" << error.column;
        }
        std::cout << "}";
        if (index + 1 < errors.size()) {
            std::cout << ",";
        }
        std::cout << "\n";
    }
    std::cout << "  ]";
}
}

int main() {
    std::string source(
        std::istreambuf_iterator<char>(std::cin),
        std::istreambuf_iterator<char>()
    );

    LexerResult lexer = tokenize_java(source);
    ParserResult parser = analyze_syntax(source, lexer.tokens);
    SemanticResult semantic = analyze_semantics(source);

    std::cout << "{\n";

    std::cout << "  \"tokens\": [\n";
    for (std::size_t index = 0; index < lexer.tokens.size(); ++index) {
        const Token& token = lexer.tokens[index];
        std::cout << "    {\"type\":\"" << escape_json(token_type_to_string(token.type))
                  << "\",\"value\":\"" << escape_json(token.value)
                  << "\",\"line\":" << token.line
                  << ",\"col\":" << token.column << "}";
        if (index + 1 < lexer.tokens.size()) {
            std::cout << ",";
        }
        std::cout << "\n";
    }
    std::cout << "  ],\n";

    print_error_list(lexer.errors, "lex_errors");
    std::cout << ",\n";
    print_error_list(parser.errors, "syntax_errors");
    std::cout << ",\n";
    print_error_list(semantic.errors, "semantic_errors");
    std::cout << ",\n";
    std::cout << "  \"ast\": \"" << escape_json(parser.ast_status) << "\"\n";
    std::cout << "}\n";

    return 0;
}
