#include "../include/lexer.h"

#include <cctype>
#include <unordered_set>
#include <vector>

namespace {
const std::unordered_set<std::string> JAVA_KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char",
    "class", "const", "continue", "default", "do", "double", "else", "enum",
    "extends", "final", "finally", "float", "for", "goto", "if", "implements",
    "import", "instanceof", "int", "interface", "long", "native", "new",
    "package", "private", "protected", "public", "return", "short", "static",
    "strictfp", "super", "switch", "synchronized", "this", "throw", "throws",
    "transient", "try", "void", "volatile", "while", "true", "false", "null",
    "record", "sealed", "permits", "non-sealed", "var"
};

const std::vector<std::string> MULTI_CHAR_OPERATORS = {
    ">>>=", ">>>", "<<=", ">>=", "==", "!=", "<=", ">=", "&&", "||",
    "++", "--", "+=", "-=", "*=", "/=", "%=", "<<", ">>", "::", "->"
};

bool is_identifier_start(char ch) {
    return std::isalpha(static_cast<unsigned char>(ch)) || ch == '_' || ch == '$';
}

bool is_identifier_part(char ch) {
    return std::isalnum(static_cast<unsigned char>(ch)) || ch == '_' || ch == '$';
}

bool is_single_char_operator(char ch) {
    const std::string operators = "=+-*/%<>!&|^~?:";
    return operators.find(ch) != std::string::npos;
}

bool is_delimiter(char ch) {
    const std::string delimiters = "(){}[],.;";
    return delimiters.find(ch) != std::string::npos;
}

void add_token(std::vector<Token>& tokens, TokenType type, const std::string& value, int line, int column) {
    tokens.push_back({type, value, line, column});
}

void add_error(std::vector<CompilerError>& errors, int line, int column, const std::string& message) {
    errors.push_back({line, column, message});
}
}

LexerResult tokenize_java(const std::string& source) {
    LexerResult result;
    std::size_t index = 0;
    int line = 1;
    int column = 1;

    while (index < source.size()) {
        char ch = source[index];
        char next = index + 1 < source.size() ? source[index + 1] : '\0';

        if (ch == '\n') {
            line++;
            column = 1;
            index++;
            continue;
        }

        if (std::isspace(static_cast<unsigned char>(ch))) {
            column++;
            index++;
            continue;
        }

        if (ch == '/' && next == '/') {
            while (index < source.size() && source[index] != '\n') {
                index++;
                column++;
            }
            continue;
        }

        if (ch == '/' && next == '*') {
            int start_line = line;
            int start_column = column;
            index += 2;
            column += 2;
            bool closed = false;

            while (index < source.size()) {
                if (source[index] == '\n') {
                    line++;
                    column = 1;
                    index++;
                    continue;
                }
                if (source[index] == '*' && index + 1 < source.size() && source[index + 1] == '/') {
                    index += 2;
                    column += 2;
                    closed = true;
                    break;
                }
                index++;
                column++;
            }

            if (!closed) {
                add_error(result.errors, start_line, start_column, "Unterminated block comment.");
            }
            continue;
        }

        if (ch == '"') {
            int start_line = line;
            int start_column = column;
            std::string value;
            value.push_back(ch);
            index++;
            column++;
            bool escaped = false;
            bool closed = false;

            while (index < source.size()) {
                char current = source[index];
                value.push_back(current);
                index++;

                if (current == '\n') {
                    line++;
                    column = 1;
                    add_error(result.errors, start_line, start_column, "Unterminated string literal.");
                    break;
                }

                column++;
                if (escaped) {
                    escaped = false;
                    continue;
                }
                if (current == '\\') {
                    escaped = true;
                    continue;
                }
                if (current == '"') {
                    closed = true;
                    add_token(result.tokens, TOKEN_STRING_LITERAL, value, start_line, start_column);
                    break;
                }
            }

            if (!closed && (value.empty() || value.back() != '\n')) {
                add_error(result.errors, start_line, start_column, "Unterminated string literal.");
            }
            continue;
        }

        if (ch == '\'') {
            int start_line = line;
            int start_column = column;
            std::string value;
            value.push_back(ch);
            index++;
            column++;
            bool escaped = false;
            bool closed = false;

            while (index < source.size()) {
                char current = source[index];
                value.push_back(current);
                index++;

                if (current == '\n') {
                    line++;
                    column = 1;
                    add_error(result.errors, start_line, start_column, "Unterminated character literal.");
                    break;
                }

                column++;
                if (escaped) {
                    escaped = false;
                    continue;
                }
                if (current == '\\') {
                    escaped = true;
                    continue;
                }
                if (current == '\'') {
                    closed = true;
                    add_token(result.tokens, TOKEN_CHAR_LITERAL, value, start_line, start_column);
                    break;
                }
            }

            if (!closed && (value.empty() || value.back() != '\n')) {
                add_error(result.errors, start_line, start_column, "Unterminated character literal.");
            }
            continue;
        }

        if (is_identifier_start(ch)) {
            int start_line = line;
            int start_column = column;
            std::size_t start = index;
            while (index < source.size() && is_identifier_part(source[index])) {
                index++;
                column++;
            }
            std::string value = source.substr(start, index - start);
            TokenType type = JAVA_KEYWORDS.count(value) ? TOKEN_KEYWORD : TOKEN_IDENTIFIER;
            add_token(result.tokens, type, value, start_line, start_column);
            continue;
        }

        if (std::isdigit(static_cast<unsigned char>(ch))) {
            int start_line = line;
            int start_column = column;
            std::size_t start = index;
            bool has_dot = false;

            while (index < source.size()) {
                char current = source[index];
                if (std::isdigit(static_cast<unsigned char>(current))) {
                    index++;
                    column++;
                    continue;
                }
                if (current == '.' && !has_dot) {
                    has_dot = true;
                    index++;
                    column++;
                    continue;
                }
                if (current == 'f' || current == 'F' || current == 'd' || current == 'D' ||
                    current == 'l' || current == 'L') {
                    index++;
                    column++;
                }
                break;
            }

            add_token(result.tokens, TOKEN_NUMBER_LITERAL, source.substr(start, index - start), start_line, start_column);
            continue;
        }

        bool matched_operator = false;
        for (std::vector<std::string>::const_iterator it = MULTI_CHAR_OPERATORS.begin(); it != MULTI_CHAR_OPERATORS.end(); ++it) {
            const std::string& op = *it;
            if (source.compare(index, op.size(), op) == 0) {
                add_token(result.tokens, TOKEN_OPERATOR, op, line, column);
                index += op.size();
                column += static_cast<int>(op.size());
                matched_operator = true;
                break;
            }
        }
        if (matched_operator) {
            continue;
        }

        if (is_single_char_operator(ch)) {
            add_token(result.tokens, TOKEN_OPERATOR, std::string(1, ch), line, column);
            index++;
            column++;
            continue;
        }

        if (is_delimiter(ch)) {
            add_token(result.tokens, TOKEN_DELIMITER, std::string(1, ch), line, column);
            index++;
            column++;
            continue;
        }

        add_error(result.errors, line, column, std::string("Unexpected character '") + ch + "'.");
        index++;
        column++;
    }

    add_token(result.tokens, TOKEN_EOF, "", line, column);
    return result;
}
