#include "../include/parser.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <vector>

namespace {
std::string trim(const std::string& value) {
    std::size_t start = 0;
    while (start < value.size() && std::isspace(static_cast<unsigned char>(value[start]))) {
        start++;
    }

    std::size_t end = value.size();
    while (end > start && std::isspace(static_cast<unsigned char>(value[end - 1]))) {
        end--;
    }

    return value.substr(start, end - start);
}

bool starts_with(const std::string& value, const std::string& prefix) {
    return value.size() >= prefix.size() && value.compare(0, prefix.size(), prefix) == 0;
}

bool ends_with_char(const std::string& value, char ch) {
    return !value.empty() && value[value.size() - 1] == ch;
}

std::string strip_comments(const std::string& source) {
    std::string result;
    result.reserve(source.size());
    bool in_string = false;
    bool in_char = false;

    for (std::size_t index = 0; index < source.size();) {
        char ch = source[index];
        char next = index + 1 < source.size() ? source[index + 1] : '\0';

        if (!in_string && !in_char && ch == '/' && next == '/') {
            while (index < source.size() && source[index] != '\n') {
                result.push_back(' ');
                index++;
            }
            continue;
        }

        if (!in_string && !in_char && ch == '/' && next == '*') {
            result.push_back(' ');
            result.push_back(' ');
            index += 2;
            while (index < source.size()) {
                if (source[index] == '\n') {
                    result.push_back('\n');
                    index++;
                    continue;
                }
                if (source[index] == '*' && index + 1 < source.size() && source[index + 1] == '/') {
                    result.push_back(' ');
                    result.push_back(' ');
                    index += 2;
                    break;
                }
                result.push_back(' ');
                index++;
            }
            continue;
        }

        result.push_back(ch);
        if (ch == '"' && !in_char && (index == 0 || source[index - 1] != '\\')) {
            in_string = !in_string;
        } else if (ch == '\'' && !in_string && (index == 0 || source[index - 1] != '\\')) {
            in_char = !in_char;
        }
        index++;
    }

    return result;
}

std::vector<std::string> split_lines(const std::string& source) {
    std::vector<std::string> lines;
    std::stringstream stream(source);
    std::string line;
    while (std::getline(stream, line)) {
        lines.push_back(line);
    }

    if (!source.empty() && source[source.size() - 1] == '\n') {
        lines.push_back("");
    }

    return lines;
}

bool looks_like_method_header(const std::string& stripped) {
    static const std::regex method_pattern(
        R"(^(?:(?:public|private|protected|static|final|abstract|synchronized|native|default)\s+)*(?:void|int|long|float|double|char|boolean|byte|short|String|[A-Za-z_]\w*)\s+[A-Za-z_]\w*\s*\([^;]*\)\s*$)"
    );
    return std::regex_match(stripped, method_pattern);
}

bool looks_like_class_header(const std::string& stripped) {
    static const std::regex class_pattern(
        R"(^(?:(?:public|private|protected|abstract|final|static)\s+)*(?:class|interface|enum|record)\s+[A-Za-z_]\w*.*$)"
    );
    return std::regex_match(stripped, class_pattern);
}

bool needs_semicolon(const std::vector<std::string>& lines, std::size_t index) {
    std::string stripped = trim(lines[index]);
    if (stripped.empty()) {
        return false;
    }

    if (starts_with(stripped, "@") || starts_with(stripped, "//") || starts_with(stripped, "/*") || starts_with(stripped, "*")) {
        return false;
    }

    if (ends_with_char(stripped, ';') || ends_with_char(stripped, '{') || ends_with_char(stripped, '}') || ends_with_char(stripped, ':')) {
        return false;
    }

    if (stripped == "else" || stripped == "do" || stripped == "try" || stripped == "finally") {
        return false;
    }

    if (starts_with(stripped, "if") || starts_with(stripped, "for") || starts_with(stripped, "while") ||
        starts_with(stripped, "switch") || starts_with(stripped, "catch") || starts_with(stripped, "synchronized")) {
        return false;
    }

    if (starts_with(stripped, "else")) {
        return false;
    }

    if (looks_like_class_header(stripped)) {
        return false;
    }

    if (looks_like_method_header(stripped)) {
        for (std::size_t next_index = index + 1; next_index < lines.size(); ++next_index) {
            std::string next_line = trim(lines[next_index]);
            if (next_line.empty()) {
                continue;
            }
            return next_line != "{";
        }
        return false;
    }

    return true;
}

void add_error(std::vector<CompilerError>& errors, std::set<std::string>& seen, int line, int column, const std::string& message) {
    std::ostringstream key;
    key << line << ':' << message;
    if (seen.count(key.str())) {
        return;
    }
    seen.insert(key.str());
    errors.push_back({line, column, message});
}
}

ParserResult analyze_syntax(const std::string& source, const std::vector<Token>& tokens) {
    ParserResult result;
    result.ast_status = "Java analysis complete";

    std::set<std::string> seen;
    std::stack<Token> delimiter_stack;
    const std::string cleaned_source = strip_comments(source);
    const std::vector<std::string> lines = split_lines(cleaned_source);

    static const std::regex class_regex(R"(\b(?:public\s+)?class\s+[A-Za-z_]\w*\b)");
    if (!std::regex_search(cleaned_source, class_regex)) {
        add_error(result.errors, seen, 1, 0, "Expected a class declaration.");
    }

    for (std::vector<Token>::const_iterator it = tokens.begin(); it != tokens.end(); ++it) {
        if (it->type != TOKEN_DELIMITER) {
            continue;
        }

        if (it->value == "(" || it->value == "{" || it->value == "[") {
            delimiter_stack.push(*it);
            continue;
        }

        if (it->value == ")" || it->value == "}" || it->value == "]") {
            char expected = it->value == ")" ? '(' : (it->value == "}" ? '{' : '[');
            if (delimiter_stack.empty() || delimiter_stack.top().value[0] != expected) {
                add_error(result.errors, seen, it->line, it->column, std::string("Unexpected '") + it->value + "'.");
            } else {
                delimiter_stack.pop();
            }
        }
    }

    while (!delimiter_stack.empty()) {
        Token token = delimiter_stack.top();
        delimiter_stack.pop();
        char expected = token.value == "(" ? ')' : (token.value == "{" ? '}' : ']');
        add_error(
            result.errors,
            seen,
            token.line,
            token.column,
            std::string("Expected '") + expected + "' to close '" + token.value + "'."
        );
    }

    for (std::size_t index = 0; index < lines.size(); ++index) {
        if (needs_semicolon(lines, index)) {
            add_error(result.errors, seen, static_cast<int>(index + 1), 0, "Missing semicolon at the end of the statement.");
        }
    }

    return result;
}
