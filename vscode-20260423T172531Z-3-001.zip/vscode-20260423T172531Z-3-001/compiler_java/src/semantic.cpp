#include "../include/semantic.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace {
const std::unordered_set<std::string> JAVA_KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char",
    "class", "const", "continue", "default", "do", "double", "else", "enum",
    "extends", "final", "finally", "float", "for", "goto", "if", "implements",
    "import", "instanceof", "int", "interface", "long", "native", "new",
    "package", "private", "protected", "public", "return", "short", "static",
    "strictfp", "super", "switch", "synchronized", "this", "throw", "throws",
    "transient", "try", "void", "volatile", "while", "true", "false", "null",
    "record", "sealed", "permits", "non-sealed", "var"
};

const std::unordered_set<std::string> JAVA_TYPES = {
    "int", "long", "float", "double", "char", "boolean", "byte", "short", "String"
};

const std::unordered_set<std::string> JAVA_NUMERIC_TYPES = {
    "int", "long", "float", "double", "byte", "short"
};

const std::unordered_set<std::string> JAVA_BUILTINS = {
    "System", "out", "println", "print", "printf", "Scanner", "Math", "Integer",
    "Double", "Boolean", "Character", "Long", "Short", "Byte", "Float", "String",
    "args", "main"
};

struct SymbolInfo {
    std::string type;
    bool initialized;
    bool is_array;
    int array_size;
};

typedef std::unordered_map<std::string, SymbolInfo> Scope;

std::string trim(const std::string& value) {
    std::size_t start = 0;
    while (start < value.size() && std::isspace(static_cast<unsigned char>(value[start]))) {
        start++;
    }

    std::size_t end = value.size();
    while (end > start && std::isspace(static_cast<unsigned char>(value[end - 1]))) {
        end--;
    }

    return value.substr(start, end - start);
}

bool starts_with(const std::string& value, const std::string& prefix) {
    return value.size() >= prefix.size() && value.compare(0, prefix.size(), prefix) == 0;
}

bool ends_with(const std::string& value, char suffix) {
    return !value.empty() && value[value.size() - 1] == suffix;
}

std::string strip_comments(const std::string& source) {
    std::string result;
    result.reserve(source.size());
    bool in_string = false;
    bool in_char = false;

    for (std::size_t index = 0; index < source.size();) {
        char ch = source[index];
        char next = index + 1 < source.size() ? source[index + 1] : '\0';

        if (!in_string && !in_char && ch == '/' && next == '/') {
            while (index < source.size() && source[index] != '\n') {
                result.push_back(' ');
                index++;
            }
            continue;
        }

        if (!in_string && !in_char && ch == '/' && next == '*') {
            result.push_back(' ');
            result.push_back(' ');
            index += 2;
            while (index < source.size()) {
                if (source[index] == '\n') {
                    result.push_back('\n');
                    index++;
                    continue;
                }
                if (source[index] == '*' && index + 1 < source.size() && source[index + 1] == '/') {
                    result.push_back(' ');
                    result.push_back(' ');
                    index += 2;
                    break;
                }
                result.push_back(' ');
                index++;
            }
            continue;
        }

        result.push_back(ch);
        if (ch == '"' && !in_char && (index == 0 || source[index - 1] != '\\')) {
            in_string = !in_string;
        } else if (ch == '\'' && !in_string && (index == 0 || source[index - 1] != '\\')) {
            in_char = !in_char;
        }
        index++;
    }

    return result;
}

std::vector<std::string> split_lines(const std::string& source) {
    std::vector<std::string> lines;
    std::stringstream stream(source);
    std::string line;
    while (std::getline(stream, line)) {
        lines.push_back(line);
    }

    if (!source.empty() && source[source.size() - 1] == '\n') {
        lines.push_back("");
    }

    return lines;
}

void add_error(std::vector<CompilerError>& errors, std::set<std::string>& seen, int line, int column, const std::string& message) {
    std::ostringstream key;
    key << line << ':' << message;
    if (seen.count(key.str())) {
        return;
    }
    seen.insert(key.str());
    errors.push_back({line, column, message});
}

std::string scrub_literals(const std::string& text) {
    std::string result;
    result.reserve(text.size());
    bool in_string = false;
    bool in_char = false;
    bool escaped = false;

    for (std::size_t index = 0; index < text.size(); ++index) {
        char ch = text[index];
        if (in_string) {
            if (escaped) {
                escaped = false;
                result.push_back(' ');
                continue;
            }
            if (ch == '\\') {
                escaped = true;
                result.push_back(' ');
                continue;
            }
            if (ch == '"') {
                in_string = false;
                result.push_back('"');
                continue;
            }
            result.push_back(' ');
            continue;
        }

        if (in_char) {
            if (escaped) {
                escaped = false;
                result.push_back(' ');
                continue;
            }
            if (ch == '\\') {
                escaped = true;
                result.push_back(' ');
                continue;
            }
            if (ch == '\'') {
                in_char = false;
                result.push_back('\'');
                continue;
            }
            result.push_back(' ');
            continue;
        }

        if (ch == '"') {
            in_string = true;
            result.push_back('"');
            continue;
        }

        if (ch == '\'') {
            in_char = true;
            result.push_back('\'');
            continue;
        }

        result.push_back(ch);
    }

    return result;
}

bool is_identifier_start(char ch) {
    return std::isalpha(static_cast<unsigned char>(ch)) || ch == '_';
}

bool is_identifier_part(char ch) {
    return std::isalnum(static_cast<unsigned char>(ch)) || ch == '_';
}

std::vector<std::string> extract_identifiers(const std::string& text) {
    std::vector<std::string> identifiers;
    for (std::size_t index = 0; index < text.size();) {
        if (!is_identifier_start(text[index])) {
            index++;
            continue;
        }

        std::size_t start = index;
        while (index < text.size() && is_identifier_part(text[index])) {
            index++;
        }

        if (start > 0 && text[start - 1] == '.') {
            continue;
        }

        std::size_t look_ahead = index;
        while (look_ahead < text.size() && std::isspace(static_cast<unsigned char>(text[look_ahead]))) {
            look_ahead++;
        }
        if (look_ahead < text.size() && text[look_ahead] == '(') {
            continue;
        }

        identifiers.push_back(text.substr(start, index - start));
    }
    return identifiers;
}

SymbolInfo* find_symbol(std::vector<Scope>& scopes, const std::string& name) {
    for (std::vector<Scope>::reverse_iterator it = scopes.rbegin(); it != scopes.rend(); ++it) {
        Scope::iterator found = it->find(name);
        if (found != it->end()) {
            return &found->second;
        }
    }
    return 0;
}

std::string infer_literal_type(const std::string& value) {
    std::string text = trim(value);
    if (text.empty()) {
        return "";
    }

    static const std::regex new_array_pattern(R"(^new\s+(int|long|float|double|char|boolean|byte|short|String)\s*\[)");
    std::smatch new_array_match;
    if (std::regex_search(text, new_array_match, new_array_pattern)) {
        return new_array_match[1].str() + "[]";
    }

    if (text.size() >= 2 && text[0] == '"' && text[text.size() - 1] == '"') {
        return "String";
    }
    if (text.size() >= 2 && text[0] == '\'' && text[text.size() - 1] == '\'') {
        return "char";
    }
    if (text == "true" || text == "false") {
        return "boolean";
    }

    static const std::regex integer_pattern(R"(^-?\d+[lL]?$)");
    static const std::regex decimal_pattern(R"(^-?\d+\.\d+[fFdD]?$)");
    if (std::regex_match(text, integer_pattern)) {
        return "int";
    }
    if (std::regex_match(text, decimal_pattern)) {
        return "double";
    }

    return "";
}

std::string infer_expression_type(const std::string& expr, std::vector<Scope>& scopes) {
    std::string text = trim(expr);
    if (text.empty()) {
        return "";
    }

    std::string literal_type = infer_literal_type(text);
    if (!literal_type.empty()) {
        return literal_type;
    }

    std::string cleaned = scrub_literals(text);

    if (cleaned.find("==") != std::string::npos || cleaned.find("!=") != std::string::npos ||
        cleaned.find("<=") != std::string::npos || cleaned.find(">=") != std::string::npos ||
        cleaned.find("&&") != std::string::npos || cleaned.find("||") != std::string::npos ||
        cleaned.find('<') != std::string::npos || cleaned.find('>') != std::string::npos ||
        cleaned.find("true") != std::string::npos || cleaned.find("false") != std::string::npos) {
        return "boolean";
    }

    if (text.find('"') != std::string::npos) {
        return "String";
    }

    static const std::regex identifier_pattern(R"(^[A-Za-z_][A-Za-z0-9_]*$)");
    if (std::regex_match(text, identifier_pattern)) {
        SymbolInfo* symbol = find_symbol(scopes, text);
        if (symbol != 0) {
            return symbol->is_array ? symbol->type + "[]" : symbol->type;
        }
    }

    static const std::regex array_access_pattern(R"(^([A-Za-z_][A-Za-z0-9_]*)\s*\[[^\]]+\]$)");
    std::smatch array_match;
    if (std::regex_match(text, array_match, array_access_pattern)) {
        SymbolInfo* symbol = find_symbol(scopes, array_match[1].str());
        if (symbol != 0) {
            return symbol->type;
        }
    }

    std::vector<std::string> found_types;
    const std::vector<std::string> identifiers = extract_identifiers(cleaned);
    for (std::vector<std::string>::const_iterator it = identifiers.begin(); it != identifiers.end(); ++it) {
        SymbolInfo* symbol = find_symbol(scopes, *it);
        if (symbol != 0) {
            found_types.push_back(symbol->type);
        }
    }

    if (cleaned.find('+') != std::string::npos || cleaned.find('-') != std::string::npos ||
        cleaned.find('*') != std::string::npos || cleaned.find('/') != std::string::npos ||
        cleaned.find('%') != std::string::npos || std::regex_search(cleaned, std::regex(R"(\d)"))) {
        for (std::vector<std::string>::const_iterator it = found_types.begin(); it != found_types.end(); ++it) {
            if (*it == "double" || *it == "float") {
                return "double";
            }
        }

        if (!found_types.empty()) {
            bool all_numeric = true;
            for (std::vector<std::string>::const_iterator it = found_types.begin(); it != found_types.end(); ++it) {
                if (!JAVA_NUMERIC_TYPES.count(*it)) {
                    all_numeric = false;
                    break;
                }
            }
            if (all_numeric) {
                return "int";
            }
        }

        if (std::regex_search(cleaned, std::regex(R"(\d+\.\d+)"))) {
            return "double";
        }
        if (std::regex_search(cleaned, std::regex(R"(\d+)"))) {
            return "int";
        }
    }

    return found_types.empty() ? "" : found_types.front();
}

bool types_compatible(const std::string& expected, const std::string& actual, bool is_array) {
    if (actual.empty()) {
        return true;
    }

    if (is_array) {
        return actual == expected + "[]";
    }

    if (expected == actual) {
        return true;
    }

    return JAVA_NUMERIC_TYPES.count(expected) && JAVA_NUMERIC_TYPES.count(actual);
}

void inspect_array_usage(
    const std::string& text,
    int line_no,
    std::vector<Scope>& scopes,
    const std::unordered_set<std::string>& class_names,
    std::vector<CompilerError>& errors,
    std::set<std::string>& seen
) {
    static const std::regex array_usage_pattern(R"(\b([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([^\]]+)\s*\])");
    std::sregex_iterator begin(text.begin(), text.end(), array_usage_pattern);
    std::sregex_iterator end;

    for (std::sregex_iterator it = begin; it != end; ++it) {
        std::string name = (*it)[1].str();
        std::string index_value = trim((*it)[2].str());

        if (JAVA_TYPES.count(name) && text.find("new " + name + "[") != std::string::npos) {
            continue;
        }
        if (class_names.count(name)) {
            continue;
        }

        SymbolInfo* symbol = find_symbol(scopes, name);
        if (symbol == 0) {
            add_error(errors, seen, line_no, 0, "Array '" + name + "' undeclared.");
            continue;
        }

        if (!symbol->is_array) {
            add_error(errors, seen, line_no, 0, "'" + name + "' is not an array.");
            continue;
        }

        static const std::regex digits_pattern(R"(^\d+$)");
        if (symbol->array_size >= 0 && std::regex_match(index_value, digits_pattern)) {
            int index_number = std::atoi(index_value.c_str());
            if (index_number >= symbol->array_size) {
                add_error(errors, seen, line_no, 0, "Array index is out of bounds for '" + name + "'.");
            }
        }
    }
}

void inspect_expression(
    const std::string& expr,
    int line_no,
    std::vector<Scope>& scopes,
    const std::unordered_set<std::string>& class_names,
    std::vector<CompilerError>& errors,
    std::set<std::string>& seen
) {
    if (trim(expr).empty()) {
        return;
    }

    if (std::regex_search(expr, std::regex(R"(/\s*0+\b)"))) {
        add_error(errors, seen, line_no, 0, "Possible division by zero detected.");
    }

    inspect_array_usage(expr, line_no, scopes, class_names, errors, seen);

    std::string cleaned = scrub_literals(expr);
    const std::vector<std::string> identifiers = extract_identifiers(cleaned);
    for (std::vector<std::string>::const_iterator it = identifiers.begin(); it != identifiers.end(); ++it) {
        const std::string& name = *it;
        if (JAVA_KEYWORDS.count(name) || JAVA_TYPES.count(name) || JAVA_BUILTINS.count(name) || class_names.count(name)) {
            continue;
        }
        if (cleaned.find("new " + name) != std::string::npos || cleaned.find("class " + name) != std::string::npos) {
            continue;
        }

        SymbolInfo* symbol = find_symbol(scopes, name);
        if (symbol == 0) {
            add_error(errors, seen, line_no, 0, "Undeclared identifier '" + name + "'.");
            continue;
        }
        if (!symbol->initialized) {
            add_error(errors, seen, line_no, 0, "Variable '" + name + "' is used without initialization.");
        }
    }
}

void register_symbol(
    int line_no,
    const std::string& type,
    const std::string& name,
    const std::string& value,
    bool is_array,
    int array_size,
    std::vector<Scope>& scopes,
    const std::unordered_set<std::string>& class_names,
    std::vector<CompilerError>& errors,
    std::set<std::string>& seen
) {
    Scope& current_scope = scopes.back();
    if (current_scope.count(name)) {
        add_error(errors, seen, line_no, 0, "Redeclaration of '" + name + "' in the same scope.");
        return;
    }

    std::string expr_type = infer_expression_type(value, scopes);
    if (!value.empty() && !types_compatible(type, expr_type, is_array)) {
        std::string readable = expr_type.empty() ? "value" : expr_type;
        add_error(errors, seen, line_no, 0, "Type mismatch: cannot assign " + readable + " to " + type + " variable '" + name + "'.");
    }

    if (!value.empty() && std::regex_search(value, std::regex(R"(/\s*0+\b)"))) {
        add_error(errors, seen, line_no, 0, "Possible division by zero detected.");
    }

    current_scope[name] = {type, !value.empty(), is_array, array_size};

    if (!value.empty()) {
        inspect_expression(value, line_no, scopes, class_names, errors, seen);
    }
}

bool looks_like_class_header(const std::string& line) {
    static const std::regex class_pattern(
        R"(^(?:(?:public|private|protected|abstract|final|static)\s+)*(?:class|interface|enum|record)\s+[A-Za-z_]\w*.*$)"
    );
    return std::regex_match(trim(line), class_pattern);
}

bool looks_like_method_header(const std::string& line) {
    static const std::regex method_pattern(
        R"(^(?:(?:public|private|protected|static|final|abstract|synchronized|native|default)\s+)*(?:void|int|long|float|double|char|boolean|byte|short|String|[A-Za-z_]\w*)\s+[A-Za-z_]\w*\s*\([^;]*\)\s*\{?\s*$)"
    );
    return std::regex_match(trim(line), method_pattern);
}

std::string extract_parenthesized_expression(const std::string& line) {
    std::size_t start = line.find('(');
    std::size_t end = line.rfind(')');
    if (start == std::string::npos || end == std::string::npos || end <= start) {
        return "";
    }
    return line.substr(start + 1, end - start - 1);
}
}

SemanticResult analyze_semantics(const std::string& source) {
    SemanticResult result;
    std::set<std::string> seen;
    std::vector<Scope> scopes;
    scopes.push_back(Scope());

    const std::string cleaned_source = strip_comments(source);
    const std::vector<std::string> lines = split_lines(cleaned_source);

    std::unordered_set<std::string> class_names;
    static const std::regex class_regex(R"(\b(?:public\s+)?class\s+([A-Za-z_]\w*)\b)");
    std::sregex_iterator class_begin(cleaned_source.begin(), cleaned_source.end(), class_regex);
    std::sregex_iterator class_end;
    for (std::sregex_iterator it = class_begin; it != class_end; ++it) {
        class_names.insert((*it)[1].str());
    }

    static const std::regex declaration_pattern(
        R"(^\s*(?:(?:public|private|protected|static|final|abstract|synchronized|volatile|transient)\s+)*(int|long|float|double|char|boolean|byte|short|String)\s*(\[\s*\])?\s+([A-Za-z_]\w*)\s*(\[\s*(\d*)\s*\])?\s*(?:=\s*(.+))?;\s*$)"
    );
    static const std::regex partial_declaration_pattern(
        R"(^\s*(?:(?:public|private|protected|static|final|abstract|synchronized|volatile|transient)\s+)*(int|long|float|double|char|boolean|byte|short|String)\s*(\[\s*\])?\s+([A-Za-z_]\w*)\s*(\[\s*(\d*)\s*\])?\s*(?:=\s*(.+))?\s*$)"
    );
    static const std::regex for_declaration_pattern(
        R"(for\s*\(\s*(?:(?:final)\s+)?(int|long|float|double|char|boolean|byte|short|String)\s+([A-Za-z_]\w*)\s*=\s*([^;]+);)"
    );
    static const std::regex assignment_pattern(
        R"(^\s*([A-Za-z_]\w*)\s*(\[[^\]]+\])?\s*([-+*/%]?=)\s*(.+);\s*$)"
    );

    for (std::size_t index = 0; index < lines.size(); ++index) {
        const std::string& raw_line = lines[index];
        const std::string stripped = trim(raw_line);
        int line_no = static_cast<int>(index + 1);

        if (stripped.empty()) {
            continue;
        }

        int close_count = static_cast<int>(std::count(raw_line.begin(), raw_line.end(), '}'));
        for (int i = 0; i < close_count; ++i) {
            if (scopes.size() > 1) {
                scopes.pop_back();
            }
        }

        std::smatch match;
        if (std::regex_match(raw_line, match, declaration_pattern)) {
            std::string type = match[1].str();
            bool is_array = match[2].matched || match[4].matched;
            std::string name = match[3].str();
            std::string size_text = match[5].str();
            std::string value = trim(match[6].str());
            int array_size = size_text.empty() ? -1 : std::atoi(size_text.c_str());

            if (!value.empty() && array_size < 0) {
                std::smatch new_array_match;
                static const std::regex new_array_pattern(R"(new\s+\w+\s*\[\s*(\d+)\s*\])");
                if (std::regex_search(value, new_array_match, new_array_pattern)) {
                    array_size = std::atoi(new_array_match[1].str().c_str());
                }
            }

            register_symbol(line_no, type, name, value, is_array, array_size, scopes, class_names, result.errors, seen);
        } else if (std::regex_match(raw_line, match, partial_declaration_pattern) && !ends_with(stripped, ';')) {
            std::string type = match[1].str();
            bool is_array = match[2].matched || match[4].matched;
            std::string name = match[3].str();
            std::string size_text = match[5].str();
            std::string value = trim(match[6].str());
            int array_size = size_text.empty() ? -1 : std::atoi(size_text.c_str());

            if (!value.empty() && array_size < 0) {
                std::smatch new_array_match;
                static const std::regex new_array_pattern(R"(new\s+\w+\s*\[\s*(\d+)\s*\])");
                if (std::regex_search(value, new_array_match, new_array_pattern)) {
                    array_size = std::atoi(new_array_match[1].str().c_str());
                }
            }

            register_symbol(line_no, type, name, value, is_array, array_size, scopes, class_names, result.errors, seen);
        } else {
            if (std::regex_search(raw_line, match, for_declaration_pattern)) {
                const std::string type = match[1].str();
                const std::string name = match[2].str();
                const std::string value = trim(match[3].str());
                if (!scopes.back().count(name)) {
                    scopes.back()[name] = {type, true, false, -1};
                }
                inspect_expression(value, line_no, scopes, class_names, result.errors, seen);
            }

            if (std::regex_match(raw_line, match, assignment_pattern) &&
                !starts_with(stripped, "if ") && !starts_with(stripped, "while ") &&
                !starts_with(stripped, "for ") && !starts_with(stripped, "switch ")) {
                const std::string name = match[1].str();
                const std::string index_expr = match[2].str();
                const std::string value = trim(match[4].str());
                SymbolInfo* symbol = find_symbol(scopes, name);

                if (!index_expr.empty()) {
                    inspect_array_usage(name + index_expr, line_no, scopes, class_names, result.errors, seen);
                }

                if (symbol == 0) {
                    if (!index_expr.empty()) {
                        add_error(result.errors, seen, line_no, 0, "Array '" + name + "' undeclared.");
                    } else {
                        add_error(result.errors, seen, line_no, 0, "Undeclared identifier '" + name + "'.");
                    }
                } else {
                    std::string expr_type = infer_expression_type(value, scopes);
                    if (!types_compatible(symbol->type, expr_type, false)) {
                        std::string readable = expr_type.empty() ? "value" : expr_type;
                        add_error(result.errors, seen, line_no, 0, "Type mismatch: cannot assign " + readable + " to " + symbol->type + " variable '" + name + "'.");
                    }
                    symbol->initialized = true;
                }

                inspect_expression(value, line_no, scopes, class_names, result.errors, seen);
            } else if (starts_with(stripped, "if") || starts_with(stripped, "while") || starts_with(stripped, "switch")) {
                inspect_expression(extract_parenthesized_expression(stripped), line_no, scopes, class_names, result.errors, seen);
            } else if (starts_with(stripped, "return ")) {
                std::string return_expr = stripped.substr(7);
                if (!return_expr.empty() && return_expr[return_expr.size() - 1] == ';') {
                    return_expr.erase(return_expr.size() - 1);
                }
                inspect_expression(return_expr, line_no, scopes, class_names, result.errors, seen);
            } else if (!looks_like_class_header(stripped) && !looks_like_method_header(stripped)) {
                inspect_expression(raw_line, line_no, scopes, class_names, result.errors, seen);
            }
        }

        int open_count = static_cast<int>(std::count(raw_line.begin(), raw_line.end(), '{'));
        for (int i = 0; i < open_count; ++i) {
            scopes.push_back(Scope());
        }
    }

    return result;
}
