from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import subprocess
import json
import re
import shutil
import tempfile
from pathlib import Path

app = Flask(__name__)
CORS(app)


BASE_DIR = Path(__file__).resolve().parent.parent
COMPILER_DIRECTORIES = {
    'c': BASE_DIR / 'compiler_core',
    'cpp': BASE_DIR / 'compiler_cpp',
    'java': BASE_DIR / 'compiler_java'
}

COMPILER_CANDIDATES = {
    'c': [
        BASE_DIR / 'compiler_core' / 'compiler.exe',
        BASE_DIR / 'compiler_core' / 'compiler'
    ],
    'cpp': [
        BASE_DIR / 'compiler_cpp' / 'compiler_cpp.exe',
        BASE_DIR / 'compiler_cpp' / 'compiler_cpp'
    ],
    'java': [
        BASE_DIR / 'compiler_java' / 'compiler_java.exe',
        BASE_DIR / 'compiler_java' / 'compiler_java'
    ]
}

SYSTEM_TOOLS = {
    'c': {
        'compile': 'gcc'
    },
    'cpp': {
        'compile': 'g++'
    },
    'java': {
        'compile': 'javac',
        'run': 'java'
    }
}


def normalize_language(value):
    language = str(value or 'c').strip().lower()
    if language in {'cpp', 'c++'}:
        return 'cpp'
    if language == 'java':
        return 'java'
    return 'c'


def language_label(language):
    return {
        'c': 'C',
        'cpp': 'C++',
        'java': 'Java'
    }[normalize_language(language)]


def empty_compiler_data(message=''):
    syntax_errors = []
    if message:
        syntax_errors.append({'line': 0, 'message': message})
    return {
        'tokens': [],
        'syntax_errors': syntax_errors,
        'semantic_errors': [],
        'lex_errors': []
    }


def resolve_compiler_path(language):
    language = normalize_language(language)
    for path in COMPILER_CANDIDATES[language]:
        if path.exists():
            return path
    raise FileNotFoundError(
        f"{language_label(language)} compiler executable not found. Build or add the compiler in {COMPILER_DIRECTORIES[language]} first."
    )


def empty_execution_data(status='skipped', output='', message='Program output is available after successful compilation and analysis.'):
    return {
        'execution_status': status,
        'program_output': output,
        'execution_message': message
    }


def resolve_system_tool(language, purpose='compile'):
    language = normalize_language(language)
    tool_name = SYSTEM_TOOLS[language][purpose]
    tool_path = shutil.which(tool_name)
    if tool_path:
        return tool_path

    if language == 'java':
        raise FileNotFoundError(
            f"{tool_name} was not found in PATH. Install a JDK and make sure both javac and java are available in the terminal."
        )

    raise FileNotFoundError(
        f"{tool_name} was not found in PATH. Install MinGW and make sure {tool_name} is available in the terminal."
    )


def detect_java_main_class(code):
    public_class_match = re.search(r'\bpublic\s+class\s+([A-Za-z_]\w*)\b', code)
    if public_class_match:
        return public_class_match.group(1)

    main_class_match = re.search(
        r'\bclass\s+([A-Za-z_]\w*)\b[\s\S]*?\bpublic\s+static\s+void\s+main\s*\(',
        code
    )
    if main_class_match:
        return main_class_match.group(1)

    class_match = re.search(r'\bclass\s+([A-Za-z_]\w*)\b', code)
    if class_match:
        return class_match.group(1)

    return 'Main'


def execute_code(code, language='c', program_input=''):
    language = normalize_language(language)
    compiler_command = resolve_system_tool(language, 'compile')

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        source_path = None
        executable_path = None

        if language == 'java':
            class_name = detect_java_main_class(code)
            source_path = temp_path / f'{class_name}.java'
            source_path.write_text(code, encoding='utf-8')
            compile_args = [compiler_command, '-encoding', 'UTF-8', str(source_path)]
        else:
            file_suffix = '.cpp' if language == 'cpp' else '.c'
            source_name = f'program{file_suffix}'
            executable_path = temp_path / 'program.exe'
            source_path = temp_path / source_name
            source_path.write_text(code, encoding='utf-8')
            compile_args = [compiler_command]
            if language == 'cpp':
                compile_args.extend(['-std=c++11'])
            else:
                compile_args.extend(['-std=c11'])
            compile_args.extend([str(source_path), '-o', str(executable_path)])

        compile_result = subprocess.run(
            compile_args,
            capture_output=True,
            text=True,
            timeout=30,
            encoding='utf-8'
        )

        if compile_result.returncode != 0:
            compile_message = compile_result.stderr.strip() or compile_result.stdout.strip() or 'Compilation failed.'
            return empty_execution_data(
                status='compile_error',
                output=compile_message,
                message='The analyzer accepted the code, but the system compiler could not build it.'
            )

        try:
            if language == 'java':
                runtime_command = [
                    resolve_system_tool(language, 'run'),
                    '-cp',
                    str(temp_path),
                    detect_java_main_class(code)
                ]
            else:
                runtime_command = [str(executable_path)]

            run_result = subprocess.run(
                runtime_command,
                input=program_input,
                capture_output=True,
                text=True,
                timeout=5,
                encoding='utf-8'
            )
        except subprocess.TimeoutExpired:
            return empty_execution_data(
                status='timeout',
                output='',
                message='Program execution timed out. If your code expects input or has a long loop, provide input or simplify the test.'
            )

        combined_output = run_result.stdout
        if run_result.stderr.strip():
            combined_output = f"{combined_output}\n{run_result.stderr}".strip()

        if run_result.returncode != 0:
            if not combined_output.strip():
                combined_output = f'Program exited with code {run_result.returncode}.'
            return empty_execution_data(
                status='runtime_error',
                output=combined_output,
                message='The code compiled, but the program ended with a runtime error.'
            )

        if not combined_output.strip():
            return empty_execution_data(
                status='success',
                output='',
                message='Program ran successfully, but it did not print anything.'
            )

        return empty_execution_data(
            status='success',
            output=combined_output.strip(),
            message='Program ran successfully.'
        )

def create_fix_response(lines, line, wrong, correct, explanation, mode='replace_line'):
    updated_lines = list(lines)

    if mode == 'replace_full':
        updated_code = correct
    else:
        fix_lines = correct.split('\n')
        if mode == 'insert_before' and 1 <= line <= len(updated_lines):
            updated_lines[line - 1:line - 1] = fix_lines
        elif mode == 'delete_line' and 1 <= line <= len(updated_lines):
            del updated_lines[line - 1]
        elif mode == 'replace_line' and 1 <= line <= len(updated_lines):
            updated_lines[line - 1:line] = fix_lines
        else:
            updated_code = '\n'.join(updated_lines)
            return jsonify({
                'wrong': wrong,
                'correct': correct,
                'line': line,
                'en': explanation,
                'updated_code': updated_code
            })

        updated_code = '\n'.join(updated_lines)

    return jsonify({
        'wrong': wrong,
        'correct': correct,
        'line': line,
        'en': explanation,
        'updated_code': updated_code
    })


def get_line_indent(line):
    match = re.match(r'^\s*', line or '')
    return match.group(0) if match else ''

def detect_type_from_value(value, language='c'):
    """Detect variable type from its value"""
    language = normalize_language(language)
    if not value:
        return "int"

    value = value.strip().rstrip(';')

    # Check for char (single quotes)
    if value.startswith("'") and value.endswith("'"):
        return "char"

    # Check for string (double quotes)
    if value.startswith('"') and value.endswith('"'):
        return "String" if language == 'java' else "char*"

    # Check for boolean
    if value.lower() in {'true', 'false'}:
        return "boolean" if language == 'java' else "int"

    # Check for float (contains .)
    if '.' in value:
        parts = value.split('.')
        if len(parts) == 2 and parts[0].replace('-', '').isdigit() and parts[1].isdigit():
            return "float"

    # Check for integer (including negative)
    if value.lstrip('-').isdigit():
        return "int"

    return "int"


def default_value_for_type(var_type, language='c'):
    language = normalize_language(language)
    defaults = {
        'int': '0',
        'float': '0.0f',
        'double': '0.0',
        'char': "'a'",
        'char*': '""',
        'String': '""',
        'boolean': 'false',
        'bool': 'false',
        'long': '0L' if language == 'java' else '0',
        'short': '0',
        'byte': '0'
    }
    return defaults.get(var_type, '0')


def build_missing_variable_declaration(var_name, var_type, language='c', indent=''):
    language = normalize_language(language)
    if language == 'java':
        return f'{indent}{var_type} {var_name} = {default_value_for_type(var_type, language)};'

    return f'{indent}{var_type} {var_name} = {default_value_for_type(var_type, language)};'


def detect_declared_variable_type(lines, var_name, language='c'):
    language = normalize_language(language)
    type_pattern = r'(int|float|char|double|bool|boolean|string|String|long|short|byte|char\*)'

    for source_line in lines:
        match = re.search(
            rf'\b{type_pattern}\b\s*(?:\[\s*\])?\s+{re.escape(var_name)}\b',
            source_line
        )
        if match:
            return match.group(1)

    return 'int'

def run_compiler(code, language='c'):
    compiler_path = resolve_compiler_path(language)
    result = subprocess.run(
        [str(compiler_path)],
        input=code,
        capture_output=True,
        text=True,
        timeout=30,
        encoding='utf-8'
    )

    output = result.stdout.strip()
    stderr_output = result.stderr.strip()

    print(f"Output length: {len(output)}")
    print(f"Output first 200 chars: {output[:200]}")
    if stderr_output:
        print(f"Compiler stderr first 200 chars: {stderr_output[:200]}")

    if not output:
        return empty_compiler_data(stderr_output or 'No output')

    try:
        compiler_data = json.loads(output)
    except json.JSONDecodeError as exc:
        return empty_compiler_data(f'Invalid compiler output: {exc}')

    code_lines = code.split('\n')
    fixed_syntax = []
    seen = set()

    for err in compiler_data.get('syntax_errors', []):
        err_line = err.get('line', 0)
        err_msg = err.get('message', '')

        if 'unexpected' in err_msg.lower():
            continue

        if ';' in err_msg and err_line > 1:
            prev_line = err_line - 1
            if 1 <= prev_line <= len(code_lines):
                prev_text = code_lines[prev_line - 1].strip()
                if prev_text and not prev_text.endswith(';') and not prev_text.endswith('{') and not prev_text.endswith('}'):
                    err['line'] = prev_line

        if 1 <= err_line <= len(code_lines):
            key = f"{err['line']}_{err['message']}"
            if key not in seen:
                seen.add(key)
                fixed_syntax.append(err)

    compiler_data['syntax_errors'] = fixed_syntax
    return compiler_data

def detect_phase_request(message):
    text = message.lower()
    if any(term in text for term in ['lex', 'lexer', 'token']):
        return 'lexical'
    if any(term in text for term in ['syntax', 'parser', 'parse tree', 'grammar']):
        return 'syntax'
    if any(term in text for term in ['semantic', 'meaning', 'type check']):
        return 'semantic'
    if 'phase' in text or 'compiler' in text:
        return 'overview'
    return None

def group_tokens_by_line(tokens):
    grouped = {}
    for token in tokens:
        grouped.setdefault(token['line'], []).append(token)
    return grouped

def build_lexical_visualization(code, compiler_data, language='c'):
    tokens = compiler_data.get('tokens', [])
    grouped = group_tokens_by_line(tokens)
    steps = []
    for line_no, line_tokens in grouped.items():
        token_summary = ', '.join(f"{token['type']}:{token['value']}" for token in line_tokens)
        steps.append({
            'label': f'Line {line_no}',
            'detail': token_summary
        })

    return {
        'title': 'Lexical Phase',
        'answer': f"The lexical phase breaks your {language_label(language)} source code into tokens such as keywords, identifiers, literals, and symbols.",
        'cards': [
            {'title': 'Token Count', 'value': str(len(tokens))},
            {'title': 'Lex Errors', 'value': str(len(compiler_data.get('lex_errors', [])))},
            {'title': 'Status', 'value': 'Ready' if not compiler_data.get('lex_errors') else 'Needs attention'}
        ],
        'steps': steps or [{'label': 'No tokens', 'detail': 'Enter code to see lexical tokens.'}],
        'code_snippet': code
    }

def classify_line(line, language='c'):
    stripped = line.strip()
    language = normalize_language(language)
    if not stripped:
        return None
    if stripped.startswith('#'):
        return 'Preprocessor directive'
    if language == 'java' and (stripped.startswith('import ') or stripped.startswith('package ')):
        return 'Import/package statement'
    if language == 'java' and re.match(r'^(?:public\s+)?class\s+\w+', stripped):
        return 'Class declaration'

    type_pattern = r'(int|float|char|void|double|bool|boolean|string|String|long|short|byte)'
    if re.match(rf'^{type_pattern}\s+\w+\s*\(.*\)\s*\{{?$', stripped):
        return 'Function header'
    if language == 'java' and re.match(rf'^(?:public|private|protected|static|final|abstract|synchronized|\s)+\s*(?:{type_pattern})\s+\w+\s*\(.*\)\s*\{{?$', stripped):
        return 'Method header'
    if re.match(rf'^{type_pattern}\s*(\[\s*\])?\s+\w+(\[[^\]]+\])?(\s*=.*)?;$', stripped):
        return 'Declaration statement'
    if stripped.startswith('if'):
        return 'Conditional statement'
    if stripped.startswith('return'):
        return 'Return statement'
    if language == 'cpp' and ('cout <<' in stripped or 'cin >>' in stripped):
        return 'Stream statement'
    if language == 'java' and ('System.out.' in stripped or 'System.in' in stripped):
        return 'Stream statement'
    if '=' in stripped and stripped.endswith(';'):
        return 'Assignment statement'
    if stripped.endswith('{'):
        return 'Block start'
    if stripped == '}':
        return 'Block end'
    return 'Expression/statement'

def build_syntax_visualization(code, compiler_data, language='c'):
    lines = code.split('\n')
    steps = []
    for idx, line in enumerate(lines, start=1):
        kind = classify_line(line, language)
        if kind:
            steps.append({
                'label': f'Line {idx}',
                'detail': f'{kind}: {line.strip()}'
            })

    syntax_errors = compiler_data.get('syntax_errors', [])
    if syntax_errors:
        for err in syntax_errors:
            steps.append({
                'label': f"Syntax issue at line {err.get('line', 0)}",
                'detail': err.get('message', 'Unknown syntax error')
            })

    return {
        'title': 'Syntax Phase',
        'answer': f'The syntax phase checks whether tokens form valid {language_label(language)} statements and blocks according to the supported grammar rules.',
        'cards': [
            {'title': 'Statements Seen', 'value': str(len([step for step in steps if step['label'].startswith('Line ')]))},
            {'title': 'Syntax Errors', 'value': str(len(syntax_errors))},
            {'title': 'Status', 'value': 'Valid structure' if not syntax_errors else 'Structure issue found'}
        ],
        'steps': steps or [{'label': 'No syntax data', 'detail': 'Enter code to inspect syntax flow.'}],
        'code_snippet': code
    }

def build_semantic_visualization(code, compiler_data, language='c'):
    lines = code.split('\n')
    declarations = []
    for idx, line in enumerate(lines, start=1):
        match = re.match(
            r'^\s*(int|float|char|double|bool|boolean|string|String|long|short|byte)\s*(\[\s*\])?\s+(\w+)(\[[^\]]+\])?',
            line.strip()
        )
        if match:
            var_type, type_array_part, name, array_part = match.groups()
            declarations.append({
                'label': f'Line {idx}',
                'detail': f"Declared {name} as {var_type}{' array' if type_array_part or array_part else ''}"
            })

    semantic_errors = compiler_data.get('semantic_errors', [])
    for err in semantic_errors:
        declarations.append({
            'label': f"Semantic issue at line {err.get('line', 0)}",
            'detail': err.get('message', 'Unknown semantic error')
        })

    return {
        'title': 'Semantic Phase',
        'answer': f'The semantic phase checks meaning in {language_label(language)} code: declarations, array usage, initialization, and type correctness.',
        'cards': [
            {'title': 'Declarations', 'value': str(len([item for item in declarations if item['label'].startswith('Line ')]))},
            {'title': 'Semantic Errors', 'value': str(len(semantic_errors))},
            {'title': 'Status', 'value': 'Meaning is valid' if not semantic_errors else 'Semantic issue found'}
        ],
        'steps': declarations or [{'label': 'No semantic data', 'detail': 'Enter code to inspect declarations and meaning.'}],
        'code_snippet': code
    }

def parse_numbers_from_message(message):
    return [int(match) for match in re.findall(r'-?\d+', message)]

def build_algorithm_visualization(message):
    text = message.lower()
    numbers = parse_numbers_from_message(message)
    if not numbers:
        numbers = [7, 3, 9, 1, 5]

    if 'binary' in text and 'search' in text:
        target = numbers[-1]
        arr = sorted(numbers[:-1] or [1, 3, 5, 7, 9])
        steps = []
        low, high = 0, len(arr) - 1
        while low <= high:
            mid = (low + high) // 2
            steps.append({'label': f'low={low}, high={high}, mid={mid}', 'detail': f'Compare target {target} with {arr[mid]}'})
            if arr[mid] == target:
                steps.append({'label': 'Found', 'detail': f'Target {target} found at index {mid}'})
                break
            if arr[mid] < target:
                low = mid + 1
            else:
                high = mid - 1
        else:
            steps.append({'label': 'Not found', 'detail': f'Target {target} is not present in the sorted array'})
        code_snippet = """int binarySearch(int arr[], int n, int target) {
    int low = 0, high = n - 1;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (arr[mid] == target) return mid;
        if (arr[mid] < target) low = mid + 1;
        else high = mid - 1;
    }
    return -1;
}"""
        return {
            'title': 'Binary Search Visualization',
            'answer': 'Binary search works on a sorted array and repeatedly halves the search range.',
            'cards': [
                {'title': 'Algorithm', 'value': 'Binary Search'},
                {'title': 'Time', 'value': 'O(log n)'},
                {'title': 'Data', 'value': str(arr)}
            ],
            'steps': steps,
            'code_snippet': code_snippet
        }

    if 'linear' in text and 'search' in text or 'search' in text:
        target = numbers[-1]
        arr = numbers[:-1] or [4, 8, 1, 9, 3]
        steps = []
        for idx, value in enumerate(arr):
            steps.append({'label': f'Index {idx}', 'detail': f'Compare target {target} with {value}'})
            if value == target:
                steps.append({'label': 'Found', 'detail': f'Target {target} found at index {idx}'})
                break
        else:
            steps.append({'label': 'Not found', 'detail': f'Target {target} is not present in the array'})
        code_snippet = """int linearSearch(int arr[], int n, int target) {
    for (int i = 0; i < n; i++) {
        if (arr[i] == target) return i;
    }
    return -1;
}"""
        return {
            'title': 'Linear Search Visualization',
            'answer': 'Linear search checks each element from left to right until it finds the target.',
            'cards': [
                {'title': 'Algorithm', 'value': 'Linear Search'},
                {'title': 'Time', 'value': 'O(n)'},
                {'title': 'Data', 'value': str(arr)}
            ],
            'steps': steps,
            'code_snippet': code_snippet
        }

    if 'bubble' in text and 'sort' in text:
        arr = list(numbers)
        steps = []
        for i in range(len(arr)):
            swapped = False
            for j in range(0, len(arr) - i - 1):
                before = arr[:]
                if arr[j] > arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
                    swapped = True
                    steps.append({'label': f'Pass {i + 1}, compare {j} and {j + 1}', 'detail': f'{before} -> {arr[:]}'})
            if not swapped:
                break
        code_snippet = """void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}"""
        return {
            'title': 'Bubble Sort Visualization',
            'answer': 'Bubble sort repeatedly swaps adjacent out-of-order values until the array is sorted.',
            'cards': [
                {'title': 'Algorithm', 'value': 'Bubble Sort'},
                {'title': 'Time', 'value': 'O(n^2)'},
                {'title': 'Sorted Result', 'value': str(arr)}
            ],
            'steps': steps or [{'label': 'No swaps', 'detail': f'Array is already sorted: {arr}'}],
            'code_snippet': code_snippet
        }

    if 'insertion' in text and 'sort' in text:
        arr = list(numbers)
        steps = []
        for i in range(1, len(arr)):
            key = arr[i]
            j = i - 1
            before = arr[:]
            while j >= 0 and arr[j] > key:
                arr[j + 1] = arr[j]
                j -= 1
            arr[j + 1] = key
            steps.append({'label': f'Insert value {key}', 'detail': f'{before} -> {arr[:]}'})
        code_snippet = """void insertionSort(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}"""
        return {
            'title': 'Insertion Sort Visualization',
            'answer': 'Insertion sort grows a sorted portion and inserts each new value into its correct position.',
            'cards': [
                {'title': 'Algorithm', 'value': 'Insertion Sort'},
                {'title': 'Time', 'value': 'O(n^2)'},
                {'title': 'Sorted Result', 'value': str(arr)}
            ],
            'steps': steps,
            'code_snippet': code_snippet
        }

    if 'selection' in text and 'sort' in text:
        arr = list(numbers)
        steps = []
        for i in range(len(arr)):
            min_idx = i
            for j in range(i + 1, len(arr)):
                if arr[j] < arr[min_idx]:
                    min_idx = j
            before = arr[:]
            arr[i], arr[min_idx] = arr[min_idx], arr[i]
            steps.append({'label': f'Place smallest at index {i}', 'detail': f'{before} -> {arr[:]}'})
        code_snippet = """void selectionSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx]) minIdx = j;
        }
        int temp = arr[i];
        arr[i] = arr[minIdx];
        arr[minIdx] = temp;
    }
}"""
        return {
            'title': 'Selection Sort Visualization',
            'answer': 'Selection sort repeatedly picks the smallest remaining element and places it in front.',
            'cards': [
                {'title': 'Algorithm', 'value': 'Selection Sort'},
                {'title': 'Time', 'value': 'O(n^2)'},
                {'title': 'Sorted Result', 'value': str(arr)}
            ],
            'steps': steps,
            'code_snippet': code_snippet
        }

    if 'hash' in text:
        size = 7
        keys = numbers or [12, 19, 26, 13]
        table = ['-' for _ in range(size)]
        steps = []
        for key in keys:
            index = key % size
            start = index
            while table[index] != '-':
                index = (index + 1) % size
            table[index] = key
            steps.append({'label': f'Insert {key}', 'detail': f'hash({key}) = {start}, placed at slot {index}, table = {table[:]}'})
        code_snippet = """void insertHash(int table[], int size, int key) {
    int index = key % size;
    while (table[index] != -1) {
        index = (index + 1) % size;
    }
    table[index] = key;
}"""
        return {
            'title': 'Hashing Visualization',
            'answer': 'This shows open addressing with linear probing in a hash table.',
            'cards': [
                {'title': 'Algorithm', 'value': 'Hashing'},
                {'title': 'Table Size', 'value': str(size)},
                {'title': 'Final Table', 'value': str(table)}
            ],
            'steps': steps,
            'code_snippet': code_snippet
        }

    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/suggest-fix', methods=['POST'])
def suggest_fix():
    data = request.json
    error = data.get('error', '')
    line = data.get('line', 0)
    full_code = data.get('full_code', '')
    language = normalize_language(data.get('language', 'c'))

    lines = full_code.split('\n')
    print(f"Suggest fix for line {line}: {error}")

    if 'uninitialized' in error.lower() or 'without initialization' in error.lower():
        var_match = re.search(r"'([^']+)'", error)
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            current_indent = get_line_indent(current_line)
            if var_match:
                var_name = var_match.group(1)
                var_type = detect_declared_variable_type(lines, var_name, language)
                return create_fix_response(
                    lines,
                    line,
                    current_line.strip(),
                    f'{current_indent}{var_name} = {default_value_for_type(var_type, language)};  // Initialize before use',
                    f"Variable '{var_name}' is used without initialization. Initialize it first.",
                    mode='insert_before'
                )
            return create_fix_response(
                lines,
                line,
                current_line.strip(),
                f'{current_indent}// Initialize variable before use',
                'Initialize variable before using it',
                mode='insert_before'
            )

    if 'division by zero' in error.lower() or 'divide by zero' in error.lower():
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            fixed_line = re.sub(r'/\s*0+\b', '/ 1', current_line, count=1)
            if fixed_line != current_line:
                return create_fix_response(
                    lines,
                    line,
                    current_line.strip(),
                    fixed_line,
                    'Avoid division by zero. Replace the zero divisor with a non-zero value such as 1.'
                )
            return create_fix_response(
                lines,
                line,
                current_line.strip(),
                current_line,
                'Avoid division by zero. Always use a non-zero divisor.'
            )

    if 'redeclaration' in error.lower():
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            return create_fix_response(
                lines,
                line,
                current_line.strip(),
                '// Duplicate declaration removed',
                'This variable is declared more than once in the same scope. Remove the duplicate declaration.',
                mode='delete_line'
            )

    if "array '" in error.lower() and 'undeclared' in error.lower():
        var_match = re.search(r"'([^']+)'", error)
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            array_name = var_match.group(1) if var_match else 'arr'
            declaration = (
                f'int[] {array_name} = new int[10];'
                if language == 'java'
                else f'int {array_name}[10];'
            )
            return create_fix_response(
                lines,
                line,
                current_line.strip(),
                declaration,
                f"Declare array '{array_name}' before using it.",
                mode='insert_before'
            )

    if 'is not an array' in error.lower():
        var_match = re.search(r"'([^']+)'", error)
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            array_name = var_match.group(1) if var_match else 'value'
            updated_lines = list(lines)
            decl_pattern = re.compile(rf'^(\s*)(int|float|char|double|bool|boolean|string|String|long|short|byte)\s+{re.escape(array_name)}\s*=\s*.*;\s*$')

            for i, source_line in enumerate(updated_lines):
                match = decl_pattern.match(source_line)
                if match:
                    indent, var_type = match.groups()
                    if language == 'java':
                        updated_lines[i] = f'{indent}{var_type}[] {array_name} = new {var_type}[10];'
                    else:
                        updated_lines[i] = f'{indent}{var_type} {array_name}[10] = {{0}};'
                    break
            else:
                insert_index = max(0, line - 1)
                updated_lines.insert(
                    insert_index,
                    f'int[] {array_name} = new int[10];' if language == 'java' else f'int {array_name}[10] = {{0}};'
                )

            return create_fix_response(
                lines,
                line,
                current_line.strip(),
                '\n'.join(updated_lines),
                f"'{array_name}' is declared as a normal variable, not an array. Declare it with brackets if you want indexed access.",
                mode='replace_full'
            )

    if 'empty statement' in error.lower() or 'double semicolon' in error.lower():
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            fixed_line = current_line.replace(';;', ';')
            return create_fix_response(lines, line, current_line.strip(), fixed_line, 'Remove extra semicolon')

    if 'array index is out of bounds' in error.lower():
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            access_match = re.search(r'(\w+)\s*\[\s*(\d+)\s*\]', current_line)
            if access_match:
                array_name = access_match.group(1)
                safe_index = '0'
                for source_line in lines:
                    decl_match = re.search(
                        rf'\b(?:int|float|char|double|bool|boolean|string|String|long|short|byte)\s+{re.escape(array_name)}\s*\[\s*(\d+)\s*\]',
                        source_line
                    )
                    if not decl_match and language == 'java':
                        decl_match = re.search(
                            rf'\b(?:int|float|char|double|boolean|String|long|short|byte)\s*\[\s*\]\s+{re.escape(array_name)}\s*=\s*new\s+\w+\s*\[\s*(\d+)\s*\]',
                            source_line
                        )
                    if decl_match:
                        safe_index = str(max(int(decl_match.group(1)) - 1, 0))
                        break

                fixed_line = re.sub(
                    rf'({re.escape(array_name)}\s*\[\s*)\d+(\s*\])',
                    rf'\g<1>{safe_index}\2',
                    current_line,
                    count=1
                )
                return create_fix_response(
                    lines,
                    line,
                    current_line.strip(),
                    fixed_line,
                    f"Use an index inside the declared array size. A safe index here is {safe_index}."
                )

    if ';' in error or 'semicolon' in error.lower():
        if line > 1:
            prev_line = lines[line - 2].strip()
            if prev_line and not prev_line.endswith(';') and not prev_line.endswith('{') and not prev_line.endswith('}'):
                fixed_line_number = line - 1
                current_line = lines[fixed_line_number - 1]
                fixed_line = current_line.rstrip() + ';'
                return create_fix_response(lines, fixed_line_number, current_line.strip(), fixed_line, 'Add semicolon at the end of line')

    if "Expected '}'" in error:
        if len(lines) > 0:
            return create_fix_response(
                lines,
                len(lines),
                lines[-1].strip(),
                full_code.rstrip() + '\n}',
                'Add a closing brace } to finish the current block.',
                mode='replace_full'
            )

    if 'unterminated string literal' in error.lower():
        if 1 <= line <= len(lines):
            current_line = lines[line - 1].rstrip()
            fixed_line = current_line if current_line.count('"') % 2 == 0 else current_line + '"'
            return create_fix_response(lines, line, current_line.strip(), fixed_line, 'This string is missing a closing double quote.')

    if 'unterminated character literal' in error.lower():
        if 1 <= line <= len(lines):
            current_line = lines[line - 1].rstrip()
            fixed_line = current_line if current_line.count("'") % 2 == 0 else current_line + "'"
            return create_fix_response(lines, line, current_line.strip(), fixed_line, 'This character literal is missing a closing single quote.')

    if "invalid '&' operator" in error.lower():
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            return create_fix_response(lines, line, current_line.strip(), current_line.replace('&', '&&', 1).strip(), 'Use && for logical AND in conditions.')

    if "invalid '|' operator" in error.lower():
        if 1 <= line <= len(lines):
            current_line = lines[line - 1]
            return create_fix_response(lines, line, current_line.strip(), current_line.replace('|', '||', 1).strip(), 'Use || for logical OR in conditions.')

    if 1 <= line <= len(lines):
        current_line = lines[line - 1]
        current_indent = get_line_indent(current_line)

        if ';' in error or 'semicolon' in error.lower():
            if not current_line.strip().endswith(';'):
                fixed_line = current_line.rstrip() + ';'
                return create_fix_response(lines, line, current_line.strip(), fixed_line, 'Add semicolon at the end')

        elif 'missing return value' in error.lower():
            fixed_line = f'{current_indent}return 0;'
            return create_fix_response(
                lines,
                line,
                current_line.strip(),
                fixed_line,
                'This function returns int, so return a value such as 0.'
            )

        elif 'cin expects variables as input targets' in error.lower():
            stream_name = 'std::cin' if 'std::cin' in current_line else 'cin'
            variable_name = 'inputValue'
            fixed_line = f'{current_indent}int {variable_name};\n{current_indent}{stream_name} >> {variable_name};'
            return create_fix_response(
                lines,
                line,
                current_line.strip(),
                fixed_line,
                'cin should store input into a variable, not a constant value.'
            )

        elif 'type mismatch' in error.lower():
            stripped_line = current_line.strip()
            string_decl_match = re.match(r'^(\s*)string\s+(\w+)\s*=\s*(.+);\s*$', current_line)
            java_string_decl_match = re.match(r'^(\s*)String\s+(\w+)\s*=\s*(.+);\s*$', current_line)
            if language == 'cpp' and string_decl_match:
                indent, var_name, assigned_value = string_decl_match.groups()
                cleaned_value = assigned_value.strip().strip('"')
                fixed_line = f'{indent}string {var_name} = "{cleaned_value}";'
                return create_fix_response(
                    lines,
                    line,
                    stripped_line,
                    fixed_line,
                    'A string variable should be initialized with text in double quotes.'
                )
            if language == 'java' and java_string_decl_match:
                indent, var_name, assigned_value = java_string_decl_match.groups()
                cleaned_value = assigned_value.strip().strip('"')
                fixed_line = f'{indent}String {var_name} = "{cleaned_value}";'
                return create_fix_response(
                    lines,
                    line,
                    stripped_line,
                    fixed_line,
                    'A Java String variable should be initialized with text in double quotes.'
                )

        elif 'undeclared' in error.lower():
            var_match = re.search(r"'([^']+)'", error)
            if var_match:
                var_name = var_match.group(1)
                raw_line = lines[line - 1]
                current_line = raw_line.strip()
                current_indent = get_line_indent(raw_line)

                value = None
                assignment_match = re.match(rf'^\s*{re.escape(var_name)}\s*=\s*(.+);\s*$', raw_line)
                if assignment_match:
                    value = assignment_match.group(1).strip()

                var_type = detect_type_from_value(value, language) if value else "int"
                declaration_pattern = (
                    r'\b(?:int|float|char|double|bool|boolean|string|String|long|short|byte|char\*)\b'
                )
                inline_declaration_match = bool(assignment_match) and not re.search(declaration_pattern, current_line)

                if inline_declaration_match:
                    fixed_line = f"{current_indent}{var_type} {current_line}"
                    explanation = f"Declare '{var_name}' on this assignment line as {var_type} before using it."
                else:
                    fixed_line = build_missing_variable_declaration(var_name, var_type, language, current_indent)
                    explanation = f"'{var_name}' is used before declaration. Declare it before this line."

                type_names = {
                    'int': 'integer number',
                    'float': 'decimal number',
                    'char': 'single character',
                    'char*': 'string',
                    'String': 'text string',
                    'boolean': 'true/false value'
                }
                en_type = type_names.get(var_type, 'variable')

                print(f"Detected type: {var_type} for value: {value}")

                return create_fix_response(
                    lines,
                    line,
                    current_line,
                    fixed_line,
                    f"{explanation} Suggested type: {var_type} ({en_type}).",
                    mode='replace_line' if inline_declaration_match else 'insert_before'
                )

        elif 'parenthesis' in error.lower() or 'expected )' in error.lower() or "expected ')'" in error.lower():
            if '(' in current_line and not current_line.strip().endswith(')'):
                if current_line.strip().endswith(';'):
                    fixed_line = current_line.rstrip()[:-1] + ');'
                else:
                    fixed_line = current_line.rstrip() + ');'
                return create_fix_response(lines, line, current_line.strip(), fixed_line, 'Add closing parenthesis ) and semicolon ;')

        elif 'if' in error.lower() and '=' in error:
            if 'if' in current_line and '=' in current_line and '==' not in current_line:
                fixed_line = current_line.replace('=', '==', 1)
                return create_fix_response(lines, line, current_line.strip(), fixed_line, 'Use == for comparison, not =')

        elif 'return type mismatch' in error.lower():
            fixed_line = 'return 0;'
            return create_fix_response(lines, line, current_line.strip(), fixed_line, 'This function currently expects an int return value, so return an integer like 0.')

    return jsonify({
        'wrong': lines[line - 1].strip() if 1 <= line <= len(lines) else '',
        'correct': 'Fix not available',
        'line': line,
        'en': 'Could not suggest fix for this error',
        'updated_code': full_code
    })

@app.route('/chatbot-query', methods=['POST'])
def chatbot_query():
    data = request.json or {}
    message = data.get('message', '').strip()
    code = data.get('code', '')
    language = normalize_language(data.get('language', 'c'))

    if not message:
        return jsonify({
            'title': 'Compiler Assistant',
            'answer': 'Ask me to visualize lexical, syntax, or semantic phases for C, C++, or Java, or request algorithms like bubble sort, binary search, or hashing.',
            'cards': [],
            'steps': [],
            'code_snippet': ''
        })

    phase = detect_phase_request(message)
    if phase:
        compiler_data = run_compiler(code, language) if code.strip() else empty_compiler_data()
        if phase == 'lexical':
            return jsonify(build_lexical_visualization(code, compiler_data, language))
        if phase == 'syntax':
            return jsonify(build_syntax_visualization(code, compiler_data, language))
        if phase == 'semantic':
            return jsonify(build_semantic_visualization(code, compiler_data, language))

        return jsonify({
            'title': 'Compiler Phase Overview',
            'answer': f'Here is a compact overview of the three compiler phases for the current {language_label(language)} code.',
            'cards': [
                {'title': 'Lexical', 'value': f"{len(compiler_data.get('tokens', []))} tokens"},
                {'title': 'Syntax', 'value': f"{len(compiler_data.get('syntax_errors', []))} syntax errors"},
                {'title': 'Semantic', 'value': f"{len(compiler_data.get('semantic_errors', []))} semantic errors"}
            ],
            'steps': [
                {'label': 'Lexical phase', 'detail': 'Converts source code into tokens.'},
                {'label': 'Syntax phase', 'detail': f"Checks whether token order matches the supported {language_label(language)} grammar."},
                {'label': 'Semantic phase', 'detail': 'Checks declarations, types, initialization, and meaning.'}
            ],
            'code_snippet': code
        })

    algorithm_response = build_algorithm_visualization(message)
    if algorithm_response:
        return jsonify(algorithm_response)

    return jsonify({
        'title': 'Compiler Assistant',
        'answer': 'I can visualize lexical, syntax, and semantic phases for C, C++, or Java code in the editor, and I can also show step-by-step algorithm visualizations for sorting, searching, and hashing.',
        'cards': [
            {'title': 'Try', 'value': 'visualize lexical phase'},
            {'title': 'Try', 'value': 'show bubble sort for 7 3 9 1 5'},
            {'title': 'Try', 'value': 'binary search 1 3 5 7 9 7'}
        ],
        'steps': [],
        'code_snippet': ''
    })

@app.route('/compile', methods=['POST'])
def compile_code():
    data = request.json
    code = data.get('code', '')
    language = normalize_language(data.get('language', 'c'))
    program_input = data.get('program_input', '')

    print("="*50)
    print(f"Received {language_label(language)} code:")
    print(code)
    print("="*50)

    try:
        compiler_data = run_compiler(code, language)
        execution_data = empty_execution_data()

        has_errors = any([
            compiler_data.get('lex_errors'),
            compiler_data.get('syntax_errors'),
            compiler_data.get('semantic_errors')
        ])
        if not has_errors and code.strip():
            execution_data = execute_code(code, language, program_input)

        compiler_data.update(execution_data)
        print(f"Final errors: {len(compiler_data.get('syntax_errors', []))} syntax, {len(compiler_data.get('lex_errors', []))} lexical, {len(compiler_data.get('semantic_errors', []))} semantic")
        return jsonify(compiler_data)

    except Exception as e:
        print(f"Exception: {e}")
        compiler_data = empty_compiler_data(str(e))
        compiler_data.update(empty_execution_data(status='compile_error', output=str(e), message='Program output could not be generated.'))
        return jsonify(compiler_data)

if __name__ == '__main__':
    print("="*50)
    for lang in ('c', 'cpp', 'java'):
        candidates = [str(path) for path in COMPILER_CANDIDATES[lang]]
        print(f"{language_label(lang)} compiler candidates:", candidates)
    print("="*50)
    app.run(debug=True, port=5000)
