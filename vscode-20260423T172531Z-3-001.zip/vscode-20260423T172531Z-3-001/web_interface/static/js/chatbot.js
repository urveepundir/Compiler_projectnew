﻿document.addEventListener('DOMContentLoaded', function() {
    const messages = document.getElementById('chatbot-messages');
    const input = document.getElementById('chatbot-input');
    const sendBtn = document.getElementById('chatbot-send');
    const editor = document.getElementById('code-editor');
    const languageSelect = document.getElementById('language-select');
    const toggleBtn = document.getElementById('chatbot-toggle');
    const closeBtn = document.getElementById('chatbot-close');
    const drawer = document.getElementById('chatbot-drawer');
    const suggestions = document.getElementById('chatbot-suggestions');
    const contextNote = document.getElementById('chatbot-context-note');

    if (!messages || !input || !sendBtn || !editor || !toggleBtn || !closeBtn || !drawer || !suggestions || !contextNote) {
        return;
    }

    let compilerContext = {
        language: languageSelect ? languageSelect.value : 'c',
        languageLabel: 'C',
        activePhase: 'lexical',
        activePhaseLabel: 'Lexical Analysis',
        mainIssue: null,
        hasErrors: false,
        compileReady: false
    };

    function openDrawer() {
        drawer.classList.remove('chatbot-closed');
        drawer.classList.add('chatbot-open');
        input.focus();
    }

    function closeDrawer() {
        drawer.classList.remove('chatbot-open');
        drawer.classList.add('chatbot-closed');
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function extractNumbers(text) {
        const matches = String(text || '').match(/-?\d+/g);
        return matches ? matches.map(Number) : [];
    }

    function getSeriesFromPayload(payload) {
        const cardValues = (payload.cards || []).flatMap(card => extractNumbers(card.value || ''));
        if (cardValues.length) {
            return cardValues.slice(0, 8);
        }
        return extractNumbers(payload.answer || '').slice(0, 8);
    }

    function renderPhaseVisual(title) {
        const phaseNodes = [
            { icon: 'LX', heading: 'Lexical', text: 'Split source into tokens and symbols.' },
            { icon: 'SX', heading: 'Syntax', text: 'Check grammar and statement structure.' },
            { icon: 'SM', heading: 'Semantic', text: 'Check meaning, types, and declarations.' }
        ];

        return `
            <div class="chatbot-visual">
                <div class="visual-overlay-title">${escapeHtml(title)} Visual</div>
                <div class="visual-phase-track">
                    ${phaseNodes.map(node => `
                        <div class="visual-node">
                            <div class="visual-node-icon">${escapeHtml(node.icon)}</div>
                            <h4>${escapeHtml(node.heading)}</h4>
                            <p>${escapeHtml(node.text)}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    function renderBarsVisual(title, payload) {
        const series = getSeriesFromPayload(payload);
        const values = series.length ? series : [7, 3, 9, 1, 5];
        const max = Math.max(...values.map(value => Math.abs(value)), 1);

        return `
            <div class="chatbot-visual">
                <div class="visual-overlay-title">${escapeHtml(title)} Visual</div>
                <div class="visual-bars">
                    ${values.map((value, index) => {
                        const height = Math.max(20, Math.round((Math.abs(value) / max) * 150));
                        return `
                            <div class="visual-bar" style="height:${height}px; animation-delay:${index * 0.08}s;">
                                <span>${escapeHtml(value)}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    }

    function renderHashVisual(title, payload) {
        const series = getSeriesFromPayload(payload);
        const values = series.length ? series : [12, 19, 26, 13];
        return `
            <div class="chatbot-visual">
                <div class="visual-overlay-title">${escapeHtml(title)} Visual</div>
                <div class="visual-hash-grid">
                    ${values.map((value, index) => `
                        <div class="visual-hash-cell" style="animation-delay:${index * 0.08}s;">
                            <div>
                                <strong>Slot ${index}</strong>
                                <div>${escapeHtml(value)}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    function renderVisualPanel(payload) {
        const title = String(payload.title || '');
        const lower = title.toLowerCase();

        if (!title) {
            return '';
        }
        if (lower.includes('lexical') || lower.includes('syntax') || lower.includes('semantic') || lower.includes('phase')) {
            return renderPhaseVisual(title);
        }
        return '';
    }

    function addMessage(role, payload) {
        const wrapper = document.createElement('div');
        wrapper.className = `chatbot-message ${role}`;

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';

        let html = '';
        if (payload.title) {
            html += `<h3>${escapeHtml(payload.title)}</h3>`;
        }
        if (payload.answer) {
            html += `<p>${escapeHtml(payload.answer)}</p>`;
        }
        if (role === 'bot') {
            html += renderVisualPanel(payload);
        }
        if (payload.cards && payload.cards.length) {
            html += '<div class="chatbot-grid">';
            payload.cards.forEach(card => {
                html += `
                    <div class="chatbot-card">
                        <div class="chatbot-card-title">${escapeHtml(card.title || '')}</div>
                        <div class="chatbot-card-value">${escapeHtml(card.value || '')}</div>
                    </div>
                `;
            });
            html += '</div>';
        }
        if (payload.steps && payload.steps.length) {
            html += '<div class="chatbot-steps">';
            payload.steps.forEach(step => {
                html += `
                    <div class="chatbot-step">
                        <div class="chatbot-step-label">${escapeHtml(step.label || '')}</div>
                        <div>${escapeHtml(step.detail || '')}</div>
                    </div>
                `;
            });
            html += '</div>';
        }
        if (payload.code_snippet) {
            html += `<pre class="chatbot-code">${escapeHtml(payload.code_snippet)}</pre>`;
        }

        bubble.innerHTML = html || `<p>${escapeHtml(payload.text || '')}</p>`;
        wrapper.appendChild(bubble);
        messages.appendChild(wrapper);
        messages.scrollTop = messages.scrollHeight;
    }

    function buildSuggestionSet() {
        const phase = compilerContext.activePhase || 'lexical';
        const phasePrompt = `Visualize ${phase} phase for my current code`;

        if (compilerContext.mainIssue) {
            return [
                { label: 'Current Phase', prompt: phasePrompt },
                { label: 'Explain Error', prompt: 'Explain the current compiler error in simple words' },
                { label: 'Lexical', prompt: 'Visualize lexical phase for my current code' },
                { label: 'Syntax', prompt: 'Visualize syntax phase for my current code' },
                { label: 'Semantic', prompt: 'Visualize semantic phase for my current code' }
            ];
        }

        return [
            { label: 'Overview', prompt: 'Give me a compiler phase overview for my current code' },
            { label: 'Lexical', prompt: 'Visualize lexical phase for my current code' },
            { label: 'Syntax', prompt: 'Visualize syntax phase for my current code' },
            { label: 'Semantic', prompt: 'Visualize semantic phase for my current code' },
            { label: 'Run Stage', prompt: 'Explain what the run stage would do for my current code' }
        ];
    }

    function updateTutorContext(detail) {
        compilerContext = Object.assign({}, compilerContext, detail || {});
        if (!compilerContext.compileReady) {
            contextNote.textContent = 'Ask about the current phase or use a prompt below.';
            input.placeholder = 'Ask about the compiler phases or program behavior';
        } else if (compilerContext.mainIssue) {
            contextNote.textContent = `Current focus: ${compilerContext.activePhaseLabel} - ${compilerContext.mainIssue.message}`;
            input.placeholder = `Ask about ${compilerContext.activePhaseLabel.toLowerCase()} or the selected issue`;
        } else {
            contextNote.textContent = `Pipeline clear for ${compilerContext.languageLabel}. Ask how the compiler understood the code or why the output looks this way.`;
            input.placeholder = 'Ask how the compiler interpreted this program';
        }

        suggestions.innerHTML = buildSuggestionSet().map(item => `
            <button class="chip" data-chat-prompt="${escapeHtml(item.prompt)}">${escapeHtml(item.label)}</button>
        `).join('');
    }

    async function sendMessage(promptText) {
        const prompt = (promptText || input.value).trim();
        if (!prompt) {
            return;
        }

        openDrawer();
        addMessage('user', { title: 'You', answer: prompt });
        input.value = '';

        addMessage('bot', { title: 'Compiler Tutor', answer: 'Preparing explanation...' });
        const loadingNode = messages.lastElementChild;

        try {
            const response = await fetch('/chatbot-query', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: prompt,
                    code: editor.value,
                    language: languageSelect ? languageSelect.value : 'c'
                })
            });

            const data = await response.json();
            if (loadingNode) {
                loadingNode.remove();
            }
            addMessage('bot', data);
        } catch (error) {
            if (loadingNode) {
                loadingNode.remove();
            }
            addMessage('bot', {
                title: 'Compiler Tutor',
                answer: `I could not load the explanation: ${error.message}`
            });
        }
    }

    sendBtn.addEventListener('click', () => sendMessage());
    toggleBtn.addEventListener('click', openDrawer);
    closeBtn.addEventListener('click', closeDrawer);
    input.addEventListener('keydown', event => {
        if (event.key === 'Enter') {
            event.preventDefault();
            sendMessage();
        } else if (event.key === 'Escape') {
            closeDrawer();
        }
    });

    suggestions.addEventListener('click', event => {
        const chip = event.target.closest('[data-chat-prompt]');
        if (chip) {
            sendMessage(chip.getAttribute('data-chat-prompt') || '');
        }
    });

    window.addEventListener('compiler-ui-context', event => {
        updateTutorContext(event.detail || {});
    });

    updateTutorContext();
});
