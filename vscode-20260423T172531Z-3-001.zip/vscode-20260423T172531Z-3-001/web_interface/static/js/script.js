﻿document.addEventListener('DOMContentLoaded', function() {
    const codeEditor = document.getElementById('code-editor');
    const languageSelect = document.getElementById('language-select');
    const programInput = document.getElementById('program-input');
    const compileBtn = document.getElementById('compile-btn');
    const clearBtn = document.getElementById('clear-btn');
    const overallStatusBadge = document.getElementById('overall-status-badge');
    const languagePill = document.getElementById('language-pill');
    const summaryMessage = document.getElementById('summary-message');
    const problemOverview = document.getElementById('problem-overview');
    const problemList = document.getElementById('problem-list');
    const explanationContent = document.getElementById('explanation-content');
    const phaseFocusNote = document.getElementById('phase-focus-note');
    const runtimeStatus = document.getElementById('runtime-status');
    const runtimeOutput = document.getElementById('runtime-output');
    const runErrors = document.getElementById('run-errors');
    const lexicalInput = document.getElementById('lexical-input');
    const lexicalProcess = document.getElementById('lexical-process');
    const lexicalOutput = document.getElementById('lexical-output');
    const lexicalErrors = document.getElementById('lexical-errors');
    const syntaxInput = document.getElementById('syntax-input');
    const syntaxProcess = document.getElementById('syntax-process');
    const syntaxOutput = document.getElementById('syntax-output');
    const syntaxErrors = document.getElementById('syntax-errors');
    const semanticInput = document.getElementById('semantic-input');
    const semanticProcess = document.getElementById('semantic-process');
    const semanticOutput = document.getElementById('semantic-output');
    const semanticErrors = document.getElementById('semantic-errors');
    const runInput = document.getElementById('run-input');
    const runProcess = document.getElementById('run-process');
    const phaseTabs = Array.from(document.querySelectorAll('.phase-tab'));
    const phasePanels = Array.from(document.querySelectorAll('.phase-panel'));
    const phaseChips = Array.from(document.querySelectorAll('.phase-chip'));

    const chipCountNodes = {
        lexical: document.getElementById('lexical-chip-count'),
        syntax: document.getElementById('syntax-chip-count'),
        semantic: document.getElementById('semantic-chip-count'),
        run: document.getElementById('runtime-chip-count')
    };

    const state = {
        compileData: null,
        issueCatalog: [],
        selectedIssueKey: null,
        selectedIssue: null,
        activePhase: 'lexical',
        pendingFix: null
    };

    const PHASE_LABELS = {
        lexical: 'Lexical Analysis',
        syntax: 'Syntax Analysis',
        semantic: 'Semantic Analysis',
        run: 'Run Result'
    };

    const PROCESS_COPY = {
        lexical: [
            'Input: raw source code characters from the editor.',
            'Work: split text into keywords, identifiers, literals, operators, and punctuation.',
            'Output: a token stream that later phases can inspect line by line.'
        ],
        syntax: [
            'Input: the token stream created by lexical analysis.',
            'Work: check statement order, braces, semicolons, and grammar structure.',
            'Output: recognized declarations, method headers, blocks, and statements.'
        ],
        semantic: [
            'Input: structured statements plus the declarations discovered so far.',
            'Work: check meaning, scope, initialization, types, and array rules.',
            'Output: a symbol table view and semantic issue list.'
        ],
        run: [
            'Input: source code that cleared lexical, syntax, and semantic checks.',
            'Work: send the program to the system compiler or runtime for execution.',
            'Output: runtime status, program output, and any run-time notes.'
        ]
    };

    function getDefaultSnippet(language) {
        if (language === 'cpp') {
            return '#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    int x = 10\n    cout << "Hello, World!" << endl;\n    return 0;\n}';
        }
        if (language === 'java') {
            return 'public class Main {\n    public static void main(String[] args) {\n        int x = 10\n        System.out.println("Hello, World!");\n    }\n}';
        }
        return '#include <stdio.h>\n\nint main() {\n    int x = 10\n    printf("Hello, World!");\n    return 0;\n}';
    }

    function currentLanguage() {
        return languageSelect ? languageSelect.value : 'c';
    }

    function languageLabel(language) {
        return language === 'cpp' ? 'C++' : (language === 'java' ? 'Java' : 'C');
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function pluralize(count, word) {
        return `${count} ${word}${count === 1 ? '' : 's'}`;
    }

    function issueKey(issue) {
        return issue ? `${issue.phase}:${issue.line}:${issue.message}` : '';
    }

    function getCodeLines(code) {
        return String(code || '').split('\n');
    }

    function getCodeLineFromSource(code, lineNumber) {
        const lines = getCodeLines(code);
        return lineNumber > 0 && lineNumber <= lines.length ? lines[lineNumber - 1] : '';
    }

    function currentCode() {
        return codeEditor ? codeEditor.value : '';
    }

    function phaseShortLabel(phase) {
        return phase === 'run' ? 'run' : phase;
    }

    function groupTokensByLine(tokens) {
        const grouped = {};
        (tokens || []).forEach(token => {
            if (!token || token.type === 'EOF') {
                return;
            }
            const line = token.line || 0;
            if (!grouped[line]) {
                grouped[line] = [];
            }
            grouped[line].push(token);
        });
        return grouped;
    }

    function renderEmptyState(message) {
        return `<div class="phase-empty">${escapeHtml(message)}</div>`;
    }

    function renderList(items, className) {
        if (!items || !items.length) {
            return renderEmptyState('No items to display for this phase yet.');
        }
        return `<ul class="${className}">${items.map(item => `<li>${item}</li>`).join('')}</ul>`;
    }

    function renderTokenGroups(tokens, emptyMessage) {
        const visibleTokens = (tokens || []).filter(token => token.type !== 'EOF');
        if (!visibleTokens.length) {
            return renderEmptyState(emptyMessage || 'No tokens generated yet.');
        }
        const grouped = groupTokensByLine(visibleTokens);
        return `
            <div class="token-lines">
                ${Object.keys(grouped).sort((a, b) => Number(a) - Number(b)).map(line => {
                    const rowTokens = grouped[line];
                    return `
                        <div class="token-line-card">
                            <div class="token-line-header">
                                <strong>Line ${escapeHtml(line)}</strong>
                                <span>${pluralize(rowTokens.length, 'token')}</span>
                            </div>
                            <div class="token-chip-row">
                                ${rowTokens.map(token => `
                                    <div class="token-chip">
                                        <span class="token-value">${escapeHtml(token.value)}</span>
                                        <span class="token-kind">${escapeHtml(token.type)}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    }

    function classifyLine(line, language) {
        const stripped = String(line || '').trim();
        if (!stripped) {
            return null;
        }
        if (stripped.startsWith('#')) {
            return 'Preprocessor directive';
        }
        if (language === 'java' && (stripped.startsWith('import ') || stripped.startsWith('package '))) {
            return 'Import or package statement';
        }
        if (language === 'java' && /^(?:public\s+)?class\s+\w+/.test(stripped)) {
            return 'Class declaration';
        }
        const typePattern = '(int|float|char|void|double|bool|boolean|string|String|long|short|byte)';
        if (new RegExp(`^(?:public|private|protected|static|final|abstract|synchronized|native|default|\\s)*${typePattern}\\s+\\w+\\s*\\(.*\\)\\s*\\{?$`).test(stripped)) {
            return language === 'java' ? 'Method header' : 'Function header';
        }
        if (new RegExp(`^${typePattern}\\s*(\\[\\s*\\])?\\s+\\w+(\\[[^\\]]+\\])?(\\s*=.*)?;$`).test(stripped)) {
            return 'Declaration statement';
        }
        if (/^if\b/.test(stripped)) {
            return 'Conditional statement';
        }
        if (/^return\b/.test(stripped)) {
            return 'Return statement';
        }
        if (language === 'cpp' && (stripped.includes('cout <<') || stripped.includes('cin >>'))) {
            return 'Stream statement';
        }
        if (language === 'java' && (stripped.includes('System.out.') || stripped.includes('System.in'))) {
            return 'Stream statement';
        }
        if (stripped.includes('=') && stripped.endsWith(';')) {
            return 'Assignment statement';
        }
        if (stripped.endsWith('{')) {
            return 'Block start';
        }
        if (stripped === '}') {
            return 'Block end';
        }
        return 'Expression or statement';
    }

    function buildSyntaxStructures(code, language) {
        return getCodeLines(code).map((line, index) => {
            const label = classifyLine(line, language);
            return label ? { line: index + 1, label, detail: line.trim() } : null;
        }).filter(Boolean);
    }

    function extractSymbolTable(code) {
        const lines = getCodeLines(code);
        const symbols = [];
        const declarationPattern = /^\s*(int|float|char|double|bool|boolean|string|String|long|short|byte)\s*(\[\s*\])?\s+(\w+)(\[[^\]]+\])?\s*(=\s*.+)?;\s*$/;
        lines.forEach((line, index) => {
            const match = line.match(declarationPattern);
            if (!match) {
                return;
            }
            symbols.push({
                line: index + 1,
                type: match[1],
                name: match[3],
                isArray: Boolean(match[2] || match[4]),
                initialized: Boolean(match[5])
            });
        });
        return symbols;
    }

    function buildFriendlyExplanation(issue) {
        if (!issue) {
            return 'Compile your code to receive a guided explanation for the current phase.';
        }
        const message = issue.message.toLowerCase();
        if (message.includes('semicolon')) {
            return 'The parser expected the statement to end cleanly, but the semicolon is missing, so the syntax phase stops here.';
        }
        if (message.includes('undeclared identifier')) {
            return 'The syntax is valid, but the semantic phase cannot resolve this name because it has not been declared yet.';
        }
        if (message.includes('type mismatch')) {
            return 'The declaration exists, but the value assigned to it does not match the declared type, so semantic analysis flags it.';
        }
        if (message.includes('without initialization') || message.includes('uninitialized')) {
            return 'The variable name is known, but semantic analysis sees that no value was stored before the variable was used.';
        }
        if (message.includes('division by zero')) {
            return 'The meaning of the expression is unsafe because dividing by zero would break program execution.';
        }
        if (message.includes('not an array')) {
            return 'The syntax is fine, but semantic analysis knows this symbol was declared as a normal variable, not an array.';
        }
        if (message.includes('out of bounds')) {
            return 'The array exists, yet the chosen index is outside the declared size, so semantic analysis marks it as unsafe.';
        }
        if (message.includes('redeclaration')) {
            return 'The variable is being declared again in the same scope, which breaks the semantic rules for unique names.';
        }
        return `The ${phaseShortLabel(issue.phase)} phase raised this issue while checking your current code.`;
    }

    function collectIssues(data, code) {
        const issues = [];
        const mappings = [
            { key: 'lex_errors', phase: 'lexical', label: 'Lexical Error' },
            { key: 'syntax_errors', phase: 'syntax', label: 'Syntax Error' },
            { key: 'semantic_errors', phase: 'semantic', label: 'Semantic Error' }
        ];
        mappings.forEach(mapping => {
            (data[mapping.key] || []).forEach(err => {
                issues.push({
                    phase: mapping.phase,
                    label: mapping.label,
                    line: err.line || 0,
                    message: err.message || String(err),
                    codeLine: getCodeLineFromSource(code, err.line || 0),
                    canFix: Boolean((err.line || 0) > 0)
                });
            });
        });
        if (!issues.length && data.execution_status && ['compile_error', 'runtime_error', 'timeout'].includes(data.execution_status)) {
            issues.push({ phase: 'run', label: 'Run Issue', line: 0, message: data.execution_message || 'Program execution reported an issue.', codeLine: '', canFix: false });
        }
        return issues;
    }
    function statusCounts(data) {
        return {
            lexical: (data.lex_errors || []).length,
            syntax: (data.syntax_errors || []).length,
            semantic: (data.semantic_errors || []).length
        };
    }

    function setStatusBadge(mode, text) {
        overallStatusBadge.className = `status-badge status-${mode}`;
        overallStatusBadge.textContent = text;
    }

    function setChipState(phase, status, metaText) {
        const chip = phaseChips.find(node => node.dataset.phaseTarget === phase);
        if (!chip) {
            return;
        }
        chip.className = `phase-chip chip-${status}`;
        if (chipCountNodes[phase]) {
            chipCountNodes[phase].textContent = metaText;
        }
    }

    function activePhaseStatus(phase) {
        if (!state.compileData) {
            return 'idle';
        }
        const counts = statusCounts(state.compileData);
        if (phase === 'lexical') {
            return counts.lexical ? 'fail' : 'pass';
        }
        if (phase === 'syntax') {
            if (counts.lexical) {
                return 'blocked';
            }
            return counts.syntax ? 'fail' : 'pass';
        }
        if (phase === 'semantic') {
            if (counts.lexical || counts.syntax) {
                return 'blocked';
            }
            return counts.semantic ? 'fail' : 'pass';
        }
        if (counts.lexical || counts.syntax || counts.semantic) {
            return 'blocked';
        }
        const runStatus = state.compileData.execution_status || 'skipped';
        if (runStatus === 'success') {
            return 'pass';
        }
        if (runStatus === 'skipped' || runStatus === 'pending') {
            return 'idle';
        }
        return 'fail';
    }

    function updateSummary(data) {
        const issues = state.issueCatalog;
        const counts = statusCounts(data);
        languagePill.textContent = languageLabel(currentLanguage());

        if (!issues.length) {
            if (data.execution_status === 'success' || data.execution_status === 'skipped') {
                setStatusBadge('success', 'All Phases Passed');
                summaryMessage.textContent = 'Your code cleared lexical, syntax, and semantic checks. Use the phase tabs to review how the compiler understood it, or open Run Result to inspect execution.';
            } else {
                setStatusBadge('runtime', 'Run Feedback Ready');
                summaryMessage.textContent = data.execution_message || 'The compiler analysis finished. Review Run Result for the execution outcome.';
            }
        } else {
            setStatusBadge('attention', 'Needs Attention');
            summaryMessage.textContent = `The ${phaseShortLabel(state.selectedIssue.phase)} phase is the current teaching focus. Review the highlighted problem and apply the suggested fix below.`;
        }

        setChipState('lexical', activePhaseStatus('lexical'), counts.lexical ? pluralize(counts.lexical, 'issue') : (state.compileData ? 'Pass' : 'Pending'));
        setChipState('syntax', activePhaseStatus('syntax'), counts.syntax ? pluralize(counts.syntax, 'issue') : (state.compileData && !counts.lexical ? 'Pass' : (state.compileData ? 'Blocked' : 'Pending')));
        setChipState('semantic', activePhaseStatus('semantic'), counts.semantic ? pluralize(counts.semantic, 'issue') : (state.compileData && !counts.lexical && !counts.syntax ? 'Pass' : (state.compileData ? 'Blocked' : 'Pending')));

        const runChipStatus = activePhaseStatus('run');
        let runMeta = 'Pending';
        if (state.compileData) {
            if (runChipStatus === 'blocked') {
                runMeta = 'Blocked';
            } else if (state.compileData.execution_status === 'success') {
                runMeta = 'Output Ready';
            } else if (state.compileData.execution_status === 'skipped') {
                runMeta = 'Waiting';
            } else if (state.compileData.execution_status) {
                runMeta = state.compileData.execution_status.replace('_', ' ');
            }
        }
        setChipState('run', runChipStatus, runMeta);
    }

    function renderProblems() {
        const issues = state.issueCatalog;
        const selectedKey = state.selectedIssue ? issueKey(state.selectedIssue) : '';

        if (!issues.length) {
            problemOverview.className = 'problem-overview';
            problemOverview.innerHTML = `
                <div class="problem-highlight">
                    <div class="problem-badge-row">
                        <span class="phase-pill run">Pipeline Ready</span>
                    </div>
                    <div class="problem-title">No compiler-phase problems found.</div>
                    <p>${escapeHtml(state.compileData && state.compileData.execution_status === 'success'
                        ? 'The code passed lexical, syntax, and semantic checks. Open Run Result to inspect the program output or use the phase tabs to review how the compiler processed your code.'
                        : 'Compile your code to see the first problem card here.')}</p>
                </div>
            `;
            problemList.innerHTML = renderEmptyState('When issues exist, each one will appear here as a clickable teaching card.');
            return;
        }

        const mainIndex = issues.findIndex(issue => issueKey(issue) === selectedKey);
        const activeIndex = mainIndex >= 0 ? mainIndex : 0;
        const activeIssue = issues[activeIndex];
        state.selectedIssue = activeIssue;
        state.selectedIssueKey = issueKey(activeIssue);
        problemOverview.className = 'problem-overview';
        problemOverview.innerHTML = `
            <div class="problem-highlight">
                <div class="problem-badge-row">
                    <span class="phase-pill ${escapeHtml(activeIssue.phase)}">${escapeHtml(PHASE_LABELS[activeIssue.phase] || activeIssue.label)}</span>
                    <span class="line-pill">${activeIssue.line > 0 ? `Line ${escapeHtml(activeIssue.line)}` : 'General issue'}</span>
                </div>
                <div class="problem-title">${escapeHtml(activeIssue.message)}</div>
                <p>${escapeHtml(buildFriendlyExplanation(activeIssue))}</p>
                ${activeIssue.codeLine ? `<div class="problem-code-line">${escapeHtml(activeIssue.codeLine)}</div>` : ''}
                <div class="fix-actions">
                    <button class="fix-jump" data-issue-index="${activeIndex}" type="button">Load Suggested Fix</button>
                    <button class="fix-jump" data-phase-target="${escapeHtml(activeIssue.phase)}" type="button">Open ${escapeHtml(PHASE_LABELS[activeIssue.phase] || activeIssue.phase)} Tab</button>
                </div>
            </div>
        `;

        problemList.innerHTML = issues.map((issue, index) => `
            <button class="issue-card ${index === activeIndex ? 'active' : ''}" data-issue-index="${index}" type="button">
                <div class="issue-card-header">
                    <span class="issue-phase-badge ${escapeHtml(issue.phase)}">${escapeHtml(issue.label)}</span>
                    <span class="line-pill">${issue.line > 0 ? `Line ${escapeHtml(issue.line)}` : 'General'}</span>
                </div>
                <div class="issue-message">${escapeHtml(issue.message)}</div>
                ${issue.codeLine ? `<div class="problem-code-line">${escapeHtml(issue.codeLine)}</div>` : ''}
            </button>
        `).join('');
    }

    function renderFixLoading() {
        explanationContent.innerHTML = '<div class="empty-state-card">Finding the best automatic fix for the selected problem...</div>';
    }

    function renderFixEmpty(message) {
        explanationContent.innerHTML = `<div class="empty-state-card">${escapeHtml(message)}</div>`;
    }

    function renderFixCard(fix) {
        explanationContent.innerHTML = `
            <div class="fix-compare">
                <div class="fix-note">${escapeHtml(fix.en || 'Review the suggested correction below.')}</div>
                <div class="fix-code-block">
                    <h3>Wrong Code${fix.line ? ` (Line ${escapeHtml(fix.line)})` : ''}</h3>
                    <pre class="fix-code wrong">${escapeHtml(fix.wrong || 'Not available')}</pre>
                </div>
                <div class="fix-code-block">
                    <h3>Correct Code</h3>
                    <pre class="fix-code correct">${escapeHtml(fix.correct || 'Fix not available')}</pre>
                </div>
                <div class="fix-actions">
                    <button class="fix-apply" data-action="apply-fix" type="button">Apply Fix</button>
                    ${state.selectedIssue ? `<button class="fix-jump" data-phase-target="${escapeHtml(state.selectedIssue.phase)}" type="button">Review ${escapeHtml(PHASE_LABELS[state.selectedIssue.phase])}</button>` : ''}
                </div>
            </div>
        `;
    }

    async function showFix(line, message) {
        if (!(line > 0)) {
            renderFixEmpty('This item does not support an automatic code fix. Review the phase tab for guidance.');
            return;
        }

        renderFixLoading();
        try {
            const response = await fetch('/suggest-fix', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ error: message, line: line, full_code: currentCode(), language: currentLanguage() })
            });
            const fix = await response.json();
            state.pendingFix = fix;
            window.pendingFix = fix;
            if (fix.correct && fix.correct !== 'Fix not available') {
                renderFixCard(fix);
            } else {
                renderFixEmpty('No automatic fix is available for this issue yet. Use the explanation above and inspect the relevant compiler phase tab.');
            }
        } catch (error) {
            console.error('ShowFix error:', error);
            renderFixEmpty(`Could not load the suggested fix: ${error.message}`);
        }
    }

    function applyFix() {
        if (state.pendingFix && typeof state.pendingFix.updated_code === 'string') {
            codeEditor.value = state.pendingFix.updated_code;
            renderFixEmpty('Fix applied in the editor. Compile again to refresh the compiler phases and confirm the issue is gone.');
            emitCompilerContext();
            return;
        }
        renderFixEmpty('This fix could not be applied automatically.');
    }

    function renderPhaseErrors(errors, phase) {
        if (!errors || !errors.length) {
            return renderEmptyState(`No ${phaseShortLabel(phase)} issues were reported for this compile.`);
        }
        return `<ul class="phase-errors-list">${errors.map(err => `<li><strong>${err.line ? `Line ${escapeHtml(err.line)}:` : 'Issue:'}</strong> ${escapeHtml(err.message || err)}</li>`).join('')}</ul>`;
    }

    function renderStructures(structures, emptyMessage) {
        if (!structures.length) {
            return renderEmptyState(emptyMessage);
        }
        return `<div class="structure-lines">${structures.map(item => `
            <div class="structure-card">
                <h4><span>Line ${escapeHtml(item.line)}</span><span>${escapeHtml(item.label)}</span></h4>
                <p>${escapeHtml(item.detail || 'Statement recognized in this phase.')}</p>
            </div>
        `).join('')}</div>`;
    }
    function renderSemanticInput(structures, symbols) {
        if (!structures.length && !symbols.length) {
            return renderEmptyState('Compile code to show the declarations and structured statements entering semantic analysis.');
        }
        const declarationSummary = symbols.length
            ? `${pluralize(symbols.length, 'symbol')} declared before meaning checks begin.`
            : 'No declarations were detected in the current source.';
        return `
            <div class="semantic-cards">
                <div class="semantic-card">
                    <h4><span>Declarations</span><span>${pluralize(symbols.length, 'item')}</span></h4>
                    <p>${escapeHtml(declarationSummary)}</p>
                </div>
                <div class="semantic-card">
                    <h4><span>Structured Statements</span><span>${pluralize(structures.length, 'item')}</span></h4>
                    <p>Semantic analysis receives the parsed declarations, assignments, method calls, and blocks produced by syntax analysis.</p>
                </div>
            </div>
        `;
    }

    function renderSymbolTable(symbols) {
        if (!symbols.length) {
            return renderEmptyState('No declarations were found to populate the semantic symbol table.');
        }
        return `
            <table class="symbol-table">
                <thead>
                    <tr>
                        <th>Line</th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Array</th>
                        <th>Initialized</th>
                    </tr>
                </thead>
                <tbody>
                    ${symbols.map(symbol => `
                        <tr>
                            <td>${escapeHtml(symbol.line)}</td>
                            <td>${escapeHtml(symbol.name)}</td>
                            <td>${escapeHtml(symbol.type)}</td>
                            <td>${symbol.isArray ? 'Yes' : 'No'}</td>
                            <td class="${symbol.initialized ? 'symbol-yes' : 'symbol-no'}">${symbol.initialized ? 'Yes' : 'No'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    function renderPhasePanels(data) {
        const code = currentCode();
        const language = currentLanguage();
        const tokens = (data.tokens || []).filter(token => token.type !== 'EOF');
        const structures = buildSyntaxStructures(code, language);
        const symbols = extractSymbolTable(code);
        const lexicalIssueCount = (data.lex_errors || []).length;
        const syntaxIssueCount = (data.syntax_errors || []).length;
        const semanticIssueCount = (data.semantic_errors || []).length;

        lexicalInput.textContent = code || 'Compile code to preview the raw source entering lexical analysis.';
        lexicalProcess.innerHTML = renderList(PROCESS_COPY.lexical.map(item => escapeHtml(item)), 'phase-copy-list');
        lexicalOutput.innerHTML = renderTokenGroups(tokens, 'No token stream is available yet.');
        lexicalErrors.innerHTML = renderPhaseErrors(data.lex_errors || [], 'lexical');

        syntaxInput.innerHTML = renderTokenGroups(tokens, 'Syntax analysis needs tokens from lexical analysis first.');
        syntaxProcess.innerHTML = renderList(PROCESS_COPY.syntax.map(item => escapeHtml(item)), 'phase-copy-list');
        syntaxOutput.innerHTML = renderStructures(structures, 'No statements have been classified for syntax analysis yet.');
        syntaxErrors.innerHTML = renderPhaseErrors(data.syntax_errors || [], 'syntax');

        semanticInput.innerHTML = renderSemanticInput(structures, symbols);
        semanticProcess.innerHTML = renderList(PROCESS_COPY.semantic.map(item => escapeHtml(item)), 'phase-copy-list');
        semanticOutput.innerHTML = renderSymbolTable(symbols);
        semanticErrors.innerHTML = renderPhaseErrors(data.semantic_errors || [], 'semantic');

        runInput.textContent = code || 'Compile code to see what enters the execution stage.';
        runProcess.innerHTML = renderList(PROCESS_COPY.run.map(item => escapeHtml(item)), 'phase-copy-list');
        runtimeStatus.textContent = data.execution_message || 'Program output is available after successful compilation and analysis.';
        runtimeStatus.className = `runtime-status runtime-${data.execution_status || 'skipped'}`;
        runtimeOutput.textContent = data.program_output && data.program_output.length
            ? data.program_output
            : (data.execution_status === 'success' ? '(Program finished without printing anything)' : 'No output yet...');

        if (lexicalIssueCount || syntaxIssueCount || semanticIssueCount) {
            runtimeOutput.textContent = 'Run output stays locked until lexical, syntax, and semantic issues are cleared.';
            runErrors.innerHTML = renderList([
                `${pluralize(lexicalIssueCount, 'lexical issue')}`,
                `${pluralize(syntaxIssueCount, 'syntax issue')}`,
                `${pluralize(semanticIssueCount, 'semantic issue')}`,
                'Resolve the compiler-phase issues above, then recompile to unlock program execution.'
            ], 'note-list');
        } else if (['compile_error', 'runtime_error', 'timeout'].includes(data.execution_status)) {
            runErrors.innerHTML = renderList([
                escapeHtml(data.execution_message || 'Program execution reported an issue.'),
                escapeHtml(data.program_output || 'No extra run output was captured.')
            ], 'note-list');
        } else {
            runErrors.innerHTML = renderList([
                'The compile pipeline is clear, so the execution stage can run the program.',
                programInput.value.trim().length ? `Program input used: ${escapeHtml(programInput.value.trim())}` : 'No program input was supplied for this run.'
            ], 'note-list');
        }
    }

    function emitCompilerContext() {
        const detail = {
            language: currentLanguage(),
            languageLabel: languageLabel(currentLanguage()),
            activePhase: state.activePhase,
            activePhaseLabel: PHASE_LABELS[state.activePhase],
            mainIssue: state.selectedIssue,
            hasErrors: Boolean(state.issueCatalog.length),
            compileReady: Boolean(state.compileData)
        };
        window.dispatchEvent(new CustomEvent('compiler-ui-context', { detail }));
    }

    function updatePhaseFocusNote() {
        if (!state.compileData) {
            phaseFocusNote.textContent = 'Compile your code to activate the guided compiler-phase explorer.';
        } else if (state.selectedIssue) {
            phaseFocusNote.textContent = `Current focus: ${PHASE_LABELS[state.activePhase]} - ${state.selectedIssue.message}`;
        } else {
            phaseFocusNote.textContent = `Current focus: ${PHASE_LABELS[state.activePhase]} - the pipeline is clear, so you can review any phase or inspect the run result.`;
        }
    }

    function setActivePhase(phase) {
        state.activePhase = phase;
        phaseTabs.forEach(button => {
            const isActive = button.dataset.phase === phase;
            button.classList.toggle('active', isActive);
            button.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
        phasePanels.forEach(panel => {
            const isActive = panel.id === `phase-panel-${phase}`;
            panel.classList.toggle('active', isActive);
            panel.hidden = !isActive;
        });
        phaseChips.forEach(chip => {
            chip.classList.toggle('active-phase', chip.dataset.phaseTarget === phase);
        });
        updatePhaseFocusNote();
        emitCompilerContext();
    }

    function focusIssueByIndex(index) {
        const issue = state.issueCatalog[index];
        if (!issue) {
            return;
        }
        state.selectedIssue = issue;
        state.selectedIssueKey = issueKey(issue);
        renderProblems();
        setActivePhase(issue.phase);
        if (issue.canFix) {
            showFix(issue.line, issue.message);
        } else {
            renderFixEmpty('This issue is best understood from the active compiler phase tab. There is no direct automatic code fix for it yet.');
        }
    }

    function resetTeachingView() {
        state.compileData = null;
        state.issueCatalog = [];
        state.selectedIssue = null;
        state.selectedIssueKey = null;
        state.pendingFix = null;
        window.pendingFix = null;

        setStatusBadge('idle', 'Waiting For Compile');
        languagePill.textContent = languageLabel(currentLanguage());
        summaryMessage.textContent = 'Compile your code to turn this panel into a guided explanation of the compiler flow.';
        ['lexical', 'syntax', 'semantic', 'run'].forEach(phase => setChipState(phase, 'idle', 'Pending'));
        problemOverview.className = 'problem-overview empty-state-card';
        problemOverview.textContent = 'Compile your code to see the current compiler-phase issue and why it was raised.';
        problemList.innerHTML = renderEmptyState('When issues exist, each one will appear here as a clickable teaching card.');
        renderFixEmpty('Choose a problem card to load the best automatic fix.');
        lexicalInput.textContent = 'Compile code to preview the raw source entering lexical analysis.';
        lexicalProcess.innerHTML = renderList(PROCESS_COPY.lexical.map(item => escapeHtml(item)), 'phase-copy-list');
        lexicalOutput.innerHTML = renderEmptyState('No tokens generated yet.');
        lexicalErrors.innerHTML = renderEmptyState('No lexical issues to display yet.');
        syntaxInput.innerHTML = renderEmptyState('Syntax analysis needs tokens from lexical analysis first.');
        syntaxProcess.innerHTML = renderList(PROCESS_COPY.syntax.map(item => escapeHtml(item)), 'phase-copy-list');
        syntaxOutput.innerHTML = renderEmptyState('No syntax structure has been built yet.');
        syntaxErrors.innerHTML = renderEmptyState('No syntax issues to display yet.');
        semanticInput.innerHTML = renderEmptyState('Compile code to show what semantic analysis receives from the parser.');
        semanticProcess.innerHTML = renderList(PROCESS_COPY.semantic.map(item => escapeHtml(item)), 'phase-copy-list');
        semanticOutput.innerHTML = renderEmptyState('No symbol table is available yet.');
        semanticErrors.innerHTML = renderEmptyState('No semantic issues to display yet.');
        runInput.textContent = 'Compile code to see what enters the execution stage.';
        runProcess.innerHTML = renderList(PROCESS_COPY.run.map(item => escapeHtml(item)), 'phase-copy-list');
        runtimeStatus.textContent = 'Compile correct code to see program output.';
        runtimeStatus.className = 'runtime-status';
        runtimeOutput.textContent = 'No output yet...';
        runErrors.innerHTML = renderEmptyState('Run notes will appear here once the compile pipeline finishes.');
        setActivePhase('lexical');
    }
    async function compileCurrentCode() {
        const code = currentCode();
        state.pendingFix = null;
        window.pendingFix = null;

        setStatusBadge('runtime', 'Analyzing');
        summaryMessage.textContent = 'Lexical, syntax, semantic, and run checks are being refreshed for the current code.';
        problemOverview.className = 'problem-overview empty-state-card';
        problemOverview.textContent = 'Analyzing the current code and selecting the most useful teaching focus...';
        problemList.innerHTML = renderEmptyState('Please wait while the compiler pipeline is running.');
        renderFixLoading();
        ['lexical', 'syntax', 'semantic', 'run'].forEach(phase => setChipState(phase, 'idle', 'Working'));
        runtimeStatus.textContent = 'Analyzing code and preparing run feedback...';
        runtimeStatus.className = 'runtime-status runtime-pending';
        runtimeOutput.textContent = 'Waiting for execution...';

        try {
            const response = await fetch('/compile', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    code: code,
                    language: currentLanguage(),
                    program_input: programInput ? programInput.value : ''
                })
            });

            const data = await response.json();
            state.compileData = data;
            state.issueCatalog = collectIssues(data, code);

            const previousKey = state.selectedIssueKey;
            const nextIssue = state.issueCatalog.find(issue => issueKey(issue) === previousKey) || state.issueCatalog[0] || null;
            state.selectedIssue = nextIssue;
            state.selectedIssueKey = issueKey(nextIssue);

            updateSummary(data);
            renderProblems();
            renderPhasePanels(data);

            if (state.selectedIssue) {
                setActivePhase(state.selectedIssue.phase);
                if (state.selectedIssue.canFix) {
                    await showFix(state.selectedIssue.line, state.selectedIssue.message);
                } else {
                    renderFixEmpty('This issue does not have an automatic code fix yet. Use the active phase tab and tutor to understand the next step.');
                }
            } else {
                setActivePhase('run');
                renderFixEmpty('No fix is needed right now. Your code cleared the compiler phases, so inspect Run Result or explore the tabs to understand what the compiler produced.');
            }
        } catch (error) {
            console.error('Compile error:', error);
            state.compileData = null;
            state.issueCatalog = [];
            state.selectedIssue = null;
            setStatusBadge('attention', 'Compile Request Failed');
            summaryMessage.textContent = `The web interface could not reach the compile endpoint: ${error.message}`;
            problemOverview.className = 'problem-overview empty-state-card';
            problemOverview.textContent = `Could not compile the current code: ${error.message}`;
            problemList.innerHTML = renderEmptyState('Try compiling again after checking that the Flask backend is running.');
            renderFixEmpty('No fix is available because the compile request itself failed.');
            runtimeStatus.textContent = `Could not run the program: ${error.message}`;
            runtimeStatus.className = 'runtime-status runtime-runtime_error';
            runtimeOutput.textContent = 'No output';
        }

        emitCompilerContext();
    }

    problemList.addEventListener('click', function(event) {
        const button = event.target.closest('[data-issue-index]');
        if (button) {
            focusIssueByIndex(Number(button.dataset.issueIndex));
        }
    });

    problemOverview.addEventListener('click', function(event) {
        const issueButton = event.target.closest('[data-issue-index]');
        if (issueButton) {
            focusIssueByIndex(Number(issueButton.dataset.issueIndex));
            return;
        }
        const phaseButton = event.target.closest('[data-phase-target]');
        if (phaseButton) {
            setActivePhase(phaseButton.dataset.phaseTarget);
        }
    });

    explanationContent.addEventListener('click', function(event) {
        const applyButton = event.target.closest('[data-action="apply-fix"]');
        if (applyButton) {
            applyFix();
            return;
        }
        const phaseButton = event.target.closest('[data-phase-target]');
        if (phaseButton) {
            setActivePhase(phaseButton.dataset.phaseTarget);
        }
    });

    phaseTabs.forEach(button => {
        button.addEventListener('click', function() {
            setActivePhase(button.dataset.phase);
        });
    });

    phaseChips.forEach(button => {
        button.addEventListener('click', function() {
            setActivePhase(button.dataset.phaseTarget);
        });
    });

    compileBtn.addEventListener('click', compileCurrentCode);

    clearBtn.addEventListener('click', function() {
        codeEditor.value = getDefaultSnippet(currentLanguage());
        if (programInput) {
            programInput.value = '';
        }
        resetTeachingView();
    });

    if (languageSelect) {
        languageSelect.addEventListener('change', function() {
            const cSnippet = getDefaultSnippet('c');
            const cppSnippet = getDefaultSnippet('cpp');
            const javaSnippet = getDefaultSnippet('java');
            if (!codeEditor.value.trim() || codeEditor.value === cSnippet || codeEditor.value === cppSnippet || codeEditor.value === javaSnippet) {
                codeEditor.value = getDefaultSnippet(currentLanguage());
            }
            resetTeachingView();
        });
    }

    codeEditor.addEventListener('input', emitCompilerContext);
    programInput.addEventListener('input', emitCompilerContext);

    window.applyFix = applyFix;
    window.getCodeLine = function(lineNumber) {
        return getCodeLineFromSource(currentCode(), lineNumber);
    };

    resetTeachingView();
});
